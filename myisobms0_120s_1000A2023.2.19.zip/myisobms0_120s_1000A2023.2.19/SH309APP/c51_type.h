#ifndef __C51_TYPE_H
#define __C51_TYPE_H

#ifndef I8
typedef	signed char		I8;		//signed 8 bit
#endif

#ifndef I16
typedef	signed short	I16;	//signed 16 bit
#endif

#ifndef I32
typedef	signed long		I32;	//signed 32 bit
#endif

#ifndef U8
typedef	unsigned char	U8;		//unsigned 8 bit
#endif

#ifndef U16
typedef	unsigned short	U16;	//unsigned 16 bit
#endif

#ifndef U32
typedef	unsigned long	U32;	//unsigned 32 bit
#endif

#ifndef U64
typedef	double	U64;	//unsigned 64 bit
#endif

#ifndef BOOL
typedef unsigned int	BOOL;
#endif



#ifndef NULL
#define NULL	(0)
#endif

#define RET_OK	(0)
#define RET_NG	(1)

#define FLG_ON	(1)
#define FLG_OFF	(0)

/*MAX/MIN Value*/
#define VALUE_MAX(a,b)	((a)>(b)? (a):(b))
#define VALUE_MIN(a,b)	((a)<(b)? (a):(b))
#define VALUE_ABS(a)		((a<0)? (-a):(a))

/*CAN Message Convert Value*/
#define BBVAL(b0, b1)           (U16)((b0 << 8) |(b1&0xFF))
#define FBVAL(b0, b1, b2, b3) (U32)((b0 << 24) |(b1<<16) | (b2<<8) |(b3&0xFF))
#define  hextoasc(x) ((x)<=9)? ((x) +0x30) : ((x)-10+0x41)

#define  hextodbc(x)   ((x/10)*16+(x%10))
#define  dbctohex(x)   ((x/16)*10+(x%16))	
#define _nop_()		   __NOP()  //USART_Cmd(USART2, ENABLE);

#endif
