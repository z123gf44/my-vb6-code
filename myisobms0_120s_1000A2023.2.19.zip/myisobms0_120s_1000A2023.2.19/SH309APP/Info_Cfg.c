
#define  _Global_Info_Cfg_
#include "Include.h"
 
tdsPackInfo  PackInfo;
U8  CellNum = 0;
 
tdsSystemConfig2   SystemConfig2;

U8 flgSyscfgEnd;		//1=system configure complete
/*
     ����ȫ�ֱ��� ��ʼ��

*/
void GlobalVariable_Init ( void )
{	
	 
 
	
	PackInfo.Current = 0;								//After the program is reset, the current default is "0",update after 1'seconds
	if ( PowerStatu != PowerOn_e )
	{
		PowerStatu = PowerOnPre_e;
	}
	PowerOn_UpdateSoc_flag = 0;
	CellVolt_UpdateSoc_flag = 0;
	
	NoComTime = 0;
	NoCurrentTime = 0;
}

/*
    
  MCUϵͳ���� ��ʼ��

*/
void Syscfg_Init ( void )
{
	U16    checksum;
	
	MemorySet((U8 *) &SystemConfig2, 0, sizeof(SystemConfig2) );
	GetFromIap( SYSTEMCONFIG_ADDR, sizeof(SystemConfig2), (U8 *) &SystemConfig2 );
	checksum = GetCheckSum( (U8*) &SystemConfig2.val, sizeof(SystemConfig2.val) );
	if ( ( SystemConfig2.CheckSum == checksum ) && ( SystemConfig2.CheckSum != 0 ) && ( SystemConfig2.CheckSum != 0xffff ) )
	{
		flgSyscfgEnd = 1;
		BQ_V82_Sysconfig_ChangF=1;
		if ( PowerStatu != PowerOnPre_e )
		{
			PowerStatu = PowerOnPre_e;
		}
	}
	else
	{
		flgSyscfgEnd = 0;
		MemorySet( (void *)&SystemConfig2, 0x0, sizeof( SystemConfig2 ) );
	}

	
//	PackInfo.PackConfig = SystemConfig2.val.PackConfigMap;
	if ( PackInfo.FCC == 0 )
	{
		PackInfo.FCC = SystemConfig2.val.S2FCC ;
		PackInfo.FCC = PackInfo.FCC *100 ;// ת1mah 
		PackInfo.SOH = SystemConfig2.val.S2SOH ;
	}
	
	if ( PackInfo.CycleCount == 0 )
	{
		PackInfo.CycleCount = SystemConfig2.val.CycleCount;
	}	
	//  SystemConfig2.val.SWVersion =100;  //Ӳ���汾 �ţ�ÿ�θĳ���ʱ �޸����
	//	SystemConfig2.val.HWVersion =100;  //Ӳ���汾 �ţ�ÿ�θĳ���ʱ �޸����
}



