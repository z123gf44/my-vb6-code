#include "Include.h"
 #include "com.h"
  #include "rtc.h"
 //  1	 1	 1	 1	      1     	2   LENID/2	     2	   1
// SOI	VER	ADR	CID1 	CID2	LENGTH	INFO	  CHKSUM	EOI

#define UPS_IDLE_TIME		(10) //10S �� ���
#define UPS_RECV_MAX  		(512)
#define UPS_SEND_MAX  		(512)

#define UPS_CID1_BAT   		(0x46)	  //﮵������ 

#define UPS_CID2_GEI_TIME   	(0x4D)//��λ����ȡʱ��		
#define UPS_CID2_SET_TIME   	(0x4E)//��λ���趨ʱ��		
#define UPS_CID2_GET_VER	   	(0x4F)//��λ����ȡЭ��汾��		
#define UPS_CID2_GET_FACTORY   	(0x51)//��λ����ȡ�豸������Ϣ		
#define UPS_CID2_SET_BAND   	(0x91)//��λ���趨ͨѶ����		
#define UPS_CID2_GET_PACKS   	(0x90)//��λ����ȡPACK����	
#define UPS_CID2_GET_NMLS   	(0x42)//��ȡģ�������������ݣ���������		
#define UPS_CID2_GET_WARN   	(0x44)//��ȡ�澯��Ϣ	
#define UPS_CID2_GET_SYSCONFIG   	(0x47)//��ȡϵͳ��������������		
#define UPS_CID2_SET_SYSCONFIG   	(0x49)//�趨ϵͳ��������������		
#define UPS_CID2_GET_HISTORYWARN   	(0x4C)//��ȡ��ʷ�澯��¼			
#define UPS_CID2_GET_POWERONOFF		(0x71)//�����ػ�����
#define UPS_CID2_GET_HISTORYRECORD   	(0x4B)//��ȡ��ʷ���ݼ�¼
#define UPS_CID2_GET_CAPACITY   	(0x7B)//��λ����ȡ �¶� SOC ��ѹ ���Ƴ�ŵ������ı���
#define UPS_CID2_SET_CAPACITY   	(0x7A)//��λ����ȡ �¶� SOC ��ѹ ���Ƴ�ŵ������ı���
#define UPS_CID2_READ_CAPACITY   	(0x7C)//��λ�� ��ʱ��ȡ ��ת�������
#define UPS_CID2_READ_WORKSTATS   	(0x7F)//��λ�� ��ʱ��ȡ mcu ����״̬ 
#define UPS_CID2_SET_DFET		   	(0x72)//���� FET 
#define UPS_CID2_PCSET_DFET		   	(0x73)//���� FET 
   //  00 ��?1? 11 ��??a  01 �䨰?a��?��?  10 �䨰?a3?��?    8x �䨰?a????   0X 1?��?��??��????

#define UPS_CID2_BACKE_NOR		(0x00)		//����		
#define	UPS_CID2_ERROR_VER		(0x01)		//VER ��		
#define	UPS_CID2_ERROR_CHKSUM	(0x02)		//CHKSUM ��		
#define	UPS_CID2_ERROR_LCHKSUM	(0x03)		//CHKSUM ��	
#define	UPS_CID2_ERROR_CID2		(0x04)		//CID2 ��Ч		
#define	UPS_CID2_ERROR_CMD		(0x05)		//�����ʽ����		
#define	UPS_CID2_ERROR_INFO		(0x06)		//��Ч����		 INFO  ������Ч
#define	UPS_CID2_ERROR_ADR		(0x90)		//ADR ����		�Զ���
#define	UPS_CID2_ERROR_TXRX		(0x91)		//ͨ�Ŵ���		�Զ���
#define	UPS_CID2_ERROR_SENT		(0xA0)	//���ݴ���ʧ�ܻ����		�Զ���

#define	UPS_CID2_ACK_OK			(0x00)	//;�ɹ�
#define	UPS_CID2_ACK_FAIL		(0xA0)	//;ʧ��

#define UPS_CID1  		(0x46)
#define UPS_VER  		(0x21)

#define UPSUART_HEADER_SOI		(0x7E)
#define UPSUART_HEADER_EOI		(0x0D)

#define REBACK_DELAYMS 		(2000)

#define SENTING_FLAG		(1)
#define GETING_FLAG		(0)
 U16  sent_back_dealy =0;
 
static U8  back_errorcrc_flag = 0; 

static U8  sent_flag = SENTING_FLAG;
extern V82Realdata_COMM     V82Realdata;
extern U8 asctohex(U8 aChar);
static U16  lijai_checksum;
static U8  sc_cns = 0;// ��·���� �������� �����ϵ�� ++
extern U8  FET_manual_vaule ;	// PC �·� MOSFET ��������	 
typedef struct
{
	U8 SOI;
	U8 VER;
	U8 ADR;
	U8 CID1;
	U8 CID2;
	stLENGTH LENdata;
	U8 COMMAND_INFO[UPS_RECV_MAX /2];
	U16 CHKSUM;
	U8 EOI;
}UPS_COMM;



UPS_COMM ups_data_getsent;

#define RET_OK	(0)
#define RET_NG	(1)

/*MAX/MIN Value*/
#define VALUE_MAX(a,b)	((a)>(b)? (a):(b))
#define VALUE_MIN(a,b)	((a)<(b)? (a):(b))
#define VALUE_ABS(a)		((a<0)? (-a):(a))

/*CAN Message Convert Value*/
#define BBVAL(b0, b1)           (U16)((b0 << 8) |(b1&0xFF))
#define FBVAL(b0, b1, b2, b3) (U32)((b0 << 24) |(b1<<16) | (b2<<8) |(b3&0xFF))
extern  U8  delay_sent_ms;
void sc_cns_add(void)
{
	sc_cns++;
}
void  sent_ups_uart(void)
{
	static U16 pos =0;
	static U8 dataL,asciitow =1;
	static U16 lijai_checksum ,temp_check =0;
	U8 SentData =0;
	
	if(SENTING_FLAG != sent_flag)	
	{
		return ;
	}
	if(UPSUART_HEADER_EOI != ups_data_getsent.EOI  )	
	{
		sent_flag =  GETING_FLAG ;
		return ;
	}
	if(0 == pos)
	{
		SentData = ups_data_getsent.SOI;
		lijai_checksum =0;
		asciitow =1;
	}
	if(1==asciitow)
	{

		if(1 == pos)
		{
			SentData = ups_data_getsent.VER;
		}
		if(2 == pos)
		{
			SentData = ups_data_getsent.ADR;
		}
		if(3 == pos)
		{
			SentData = ups_data_getsent.CID1;
		}
		if(4 == pos)
		{
			SentData = ups_data_getsent.CID2;
		}
		if(5 == pos)
		{
			SentData = ups_data_getsent.LENdata.LENGTH >>8;
		}
		if(6 == pos)
		{
			SentData = ups_data_getsent.LENdata.LENGTH;
		}
		if(6 < pos)
		{
			if( pos < ((ups_data_getsent.LENdata.towbyte.LENID/2) +7) ) // have not get EOI  give up 
			{
				SentData = ups_data_getsent.COMMAND_INFO[pos-7] ;
			}
			else
			{
				if( pos == ((ups_data_getsent.LENdata.towbyte.LENID/2) +7) ) // have not get EOI  give up 
				{
					temp_check = ~lijai_checksum +1;
					SentData = temp_check >>8 ;
				}
				if( pos == ((ups_data_getsent.LENdata.towbyte.LENID/2) +8) ) // have not get EOI  give up 
				{
					SentData = temp_check;
				}
				if( pos == ((ups_data_getsent.LENdata.towbyte.LENID/2) +9) ) // have not get EOI  give up 
				{
					SentData = ups_data_getsent.EOI;
					ups_data_getsent.EOI = 0x00;
					asciitow =1;
					pos = 0;
					sent_flag = GETING_FLAG;
				}
			}	
		}	
	}

	
	if(0!= pos)
	{
			if(asciitow )
			{
				dataL = hextoasc(SentData&0x0f);
				SentData  = hextoasc((SentData>>4)&0x0f);;
				asciitow =0;
			}
			else
			{
				asciitow =1;
				SentData= dataL;
				pos++;
			}
			lijai_checksum += SentData; // ���ۼ�ʱ ���ü���
	}
	else
	{
		if(UPSUART_HEADER_EOI  == ups_data_getsent.EOI )
		{
			pos++;
		}
	}
	sent_open(SentData);
}
U8 length_sum_check(U16 llcsum )
{
  llcsum = (llcsum >>8 &0x0f) + (llcsum >>4 &0x0f) + (llcsum &0x0f) ;
  llcsum =	llcsum  & 0x0f ;
  llcsum =	~llcsum +1;
	return (llcsum  & 0x0f);
}


// CHKSUM�ļ����ǳ�SOI��EOI��CHKSUM�⣬�����ַ���ASCII��ֵ�ۼ���ͣ����ý��ģ65536 ����ȡ����1��
// 7E 32 31 30 31 34 36 34 32 45 30 30 32 30 31 46 44 33 34 0D
// ~21014642E00201FD34CR
void  get_ups_uart(U8 RecvData)
{
	static U16 	pos;
	static U8 	datal,asciitow =0;
	if( 0 != sent_back_dealy)
	{
		return;
	}
	if(SENTING_FLAG == sent_flag)
	{
		return ;
	}
	if(UPSUART_HEADER_EOI == ups_data_getsent.EOI)
	{
		return ;
	}
	
	if(UPSUART_HEADER_SOI == RecvData)
	{
		ups_data_getsent.SOI = UPSUART_HEADER_SOI;
		ups_data_getsent.EOI = 0x00;
		ups_data_getsent.LENdata.towbyte.LENID =0;
		pos =0;
		asciitow =1;
		lijai_checksum =0;
		return ;
	}
	
	if(UPSUART_HEADER_SOI != ups_data_getsent.SOI)
	{
		ups_data_getsent.SOI = 0X00;
		ups_data_getsent.EOI = 0x00;
		pos =0;
		asciitow =1;
		lijai_checksum =0;
		return ;
	}
	
	if(UPSUART_HEADER_EOI == RecvData  )// once all  data 
	{
		if(pos >6)
		{
			ups_data_getsent.EOI = UPSUART_HEADER_EOI;
			lijai_checksum = ~lijai_checksum +1;
			return ;
		}
		else
		{
			ups_data_getsent.SOI = 0x00; // �����˳�
			ups_data_getsent.EOI = 0x00;
			return ;
		}
	}

	 if((5 + ups_data_getsent.LENdata.towbyte.LENID/2)>= pos )//=0 ʱ 0-5 
	 {
		lijai_checksum += RecvData; // ���ۼ�ʱ ���ü���
	 }


	if( asciitow )
	{
		datal = RecvData;
		asciitow =0;
		return ;
	}
	else
	{
		asciitow =1;
		RecvData= (asctohex(datal)<<4) + asctohex(RecvData);
		pos++;
	}
	

	if( 1==pos)
	{
		ups_data_getsent.VER = RecvData;
	}
	if(2==pos  )
	{
		ups_data_getsent.ADR = RecvData;
	}	
	if(3==pos)
	{
		if(UPS_CID1 == RecvData)
		{
			ups_data_getsent.CID1 = RecvData;
		}
		else
		{
			ups_data_getsent.SOI = 0x00; // �����˳�
			ups_data_getsent.EOI = 0x00;
		}
	}
	if(4==pos)
	{
		ups_data_getsent.CID2 = RecvData;
	}		
	if(5==pos)
	{
		ups_data_getsent.LENdata.LENGTH  = RecvData;
	}
	if(6==pos)
	{
		ups_data_getsent.LENdata.LENGTH = ((ups_data_getsent.LENdata.LENGTH  <<8) & 0x0FF00)  | RecvData;
		
		if((ups_data_getsent.LENdata.towbyte.LLCSUM != length_sum_check (ups_data_getsent.LENdata.towbyte.LENID ) ) || ( COM_RECV_MAX <ups_data_getsent.LENdata.towbyte.LENID ))
		{
			ups_data_getsent.CID2 = UPS_CID2_ERROR_LCHKSUM;
			back_errorcrc_flag = 1;
			ups_data_getsent.SOI = 0x00;
			ups_data_getsent.EOI = 0x00; // ����У�� ����
			
		}
		
	}
	if(6<pos)
	{
		if( pos < (ups_data_getsent.LENdata.towbyte.LENID/2 +7) ) // have not get EOI  give up 
		{
			ups_data_getsent.COMMAND_INFO[pos-7] =  RecvData;
		}
		else
		{
			if( pos == (ups_data_getsent.LENdata.towbyte.LENID/2 +7) ) // have not get EOI  give up 
			{
				ups_data_getsent.CHKSUM =  RecvData;
			}
			if( pos == (ups_data_getsent.LENdata.towbyte.LENID/2 +8) ) // have not get EOI  give up 
			{
				ups_data_getsent.CHKSUM = (ups_data_getsent.CHKSUM<<8 &0xff00)  + RecvData;
			}
		}
	}
	
}


//�ֽ���	1	 1	  1	      1  	1	 2	     LENID/2	 2	    1
//��ʽ	  SOI	VER	 ADR	46H	   RTN	LENGTH	  INFO	  CHKSUM	EOI
U8  check_crc(void)
{
	//U16 i;
	U8 ret = RET_NG;

	if( ups_data_getsent.CHKSUM != lijai_checksum )
	{
		ups_data_getsent.CID2 = UPS_CID2_ERROR_CHKSUM;
		return RET_NG;
	}
	if(	ups_data_getsent.ADR != V82system.Addr)
	{
		ups_data_getsent.CID2 = UPS_CID2_ERROR_ADR;
		return RET_NG;
	}

	if(	UPS_VER != ups_data_getsent.VER)
	{
		ups_data_getsent.CID2 = UPS_CID2_ERROR_VER; // ��ѯ �汾ʱ ���ظ�����
		return RET_NG;
	}
	ret = RET_OK;
	return ret;
}
/*
#define UPS_CID2_BACKE_NOR		(0x00)		//����		
#define	UPS_CID2_ERROR_CID2		(0x04)		//CID2 ��Ч		
#define	UPS_CID2_ERROR_CMD		(0x05)		//�����ʽ����		
#define	UPS_CID2_ERROR_INFO		(0x06)		//��Ч����		 INFO  ������Ч
#define	UPS_CID2_ERROR_TXRX		(0x91)		//ͨ�Ŵ���		�Զ���
#define	UPS_CID2_ERROR_SENT		(0xA0)		//���ݴ���ʧ�ܻ����		�Զ���

#define UPS_CID1  		(0x46)
#define UPS_VER  		(0x21)

#define UPSUART_HEADER_SOI		(0x7E)
#define UPSUART_HEADER_EOI		(0x0D)
*/

void ups_handle(void)
{
	U16 temp1,pos;
	I16 temp_16; 
	U8 i ;
	U8 *p ;
	U16 maxiv,maxia,maxoa;
	U8 charge_onoff,discharge_onoff;
 	if( 2< sent_back_dealy)
	{
		return;
	}
	
	if(SENTING_FLAG == sent_flag)
	{
		return;
	}
	
	if(back_errorcrc_flag)
	{	
		sent_flag = SENTING_FLAG;
		back_errorcrc_flag = 0;
		ups_data_getsent.SOI  = UPSUART_HEADER_SOI;	
		ups_data_getsent.EOI  = UPSUART_HEADER_EOI;
		ups_data_getsent.VER  = UPS_VER;
		ups_data_getsent.ADR  = V82system.Addr;  
		ups_data_getsent.CID1 = UPS_CID1;
		ups_data_getsent.CID2 = UPS_CID2_ERROR_LCHKSUM;
		ups_data_getsent.LENdata.towbyte.LENID = 0x00 *2;
		ups_data_getsent.LENdata.towbyte.LLCSUM = length_sum_check(ups_data_getsent.LENdata.towbyte.LENID);
		return;
	}	
	
	if(UPSUART_HEADER_EOI != ups_data_getsent.EOI)
	{
		return;
	}
	sent_flag = SENTING_FLAG;
			
	/*       ������ȷ ��Ҫ�ظ�                 */
	ups_data_getsent.SOI  = UPSUART_HEADER_SOI;	
	ups_data_getsent.EOI  = UPSUART_HEADER_EOI;
	ups_data_getsent.VER  = UPS_VER;
	ups_data_getsent.ADR  = V82system.Addr;  
	ups_data_getsent.CID1 = UPS_CID1;
	
	if(RET_NG == check_crc())
	{// ���� �ظ�
		ups_data_getsent.CID2 = UPS_CID2_ERROR_CHKSUM;
		ups_data_getsent.LENdata.towbyte.LENID = 0x00 *2;
		ups_data_getsent.LENdata.towbyte.LLCSUM = length_sum_check(ups_data_getsent.LENdata.towbyte.LENID);
		return;
	}	
/*******************************************��ʼ�ְ� CID2���� CMD ����**********************************/ 
	
	switch (ups_data_getsent.CID2)
	{
	case UPS_CID2_GEI_TIME://��λ����ȡʱ��	
		if(0 != ups_data_getsent.LENdata.towbyte.LENID)
		{
			ups_data_getsent.CID2 = UPS_CID2_ERROR_INFO;
		}
		else
		{
			ups_data_getsent.CID2 = UPS_CID2_BACKE_NOR;
		}
		temp1 = (RtcTime.Year/16)*10+RtcTime.Year%16;
		temp1 = 2000+ temp1;
		ups_data_getsent.COMMAND_INFO[0] = temp1>>8; 
		ups_data_getsent.COMMAND_INFO[1] = temp1 & 0x00ff; 
		ups_data_getsent.COMMAND_INFO[2] = (RtcTime.Month/16)*10+RtcTime.Month%16;
		ups_data_getsent.COMMAND_INFO[3] = (RtcTime.Date/16)*10+RtcTime.Date%16;
		ups_data_getsent.COMMAND_INFO[4] = (RtcTime.Hour/16)*10+RtcTime.Hour%16;
		ups_data_getsent.COMMAND_INFO[5] = (RtcTime.Minute/16)*10+RtcTime.Minute%16;
		ups_data_getsent.COMMAND_INFO[6] = (RtcTime.Second/16)*10+RtcTime.Second%16;
		ups_data_getsent.LENdata.towbyte.LENID = 0x07 *2;
		ups_data_getsent.LENdata.towbyte.LLCSUM = length_sum_check(ups_data_getsent.LENdata.towbyte.LENID);
		break;
	case UPS_CID2_SET_TIME://��λ���趨ʱ��	
		if(0x0E != ups_data_getsent.LENdata.towbyte.LENID)
		{
			ups_data_getsent.CID2 = UPS_CID2_ERROR_INFO;
		}
		else
		{
			ups_data_getsent.CID2 = UPS_CID2_BACKE_NOR;
		}//210627175532
		temp1 = ups_data_getsent.COMMAND_INFO[0];
		temp1 =temp1*256 + ups_data_getsent.COMMAND_INFO[1];
		temp1 = temp1 -2000;
		
		RTC_Set(hextodbc(temp1),hextodbc(ups_data_getsent.COMMAND_INFO[2]),
		hextodbc(ups_data_getsent.COMMAND_INFO[3]),hextodbc(ups_data_getsent.COMMAND_INFO[4]),
		hextodbc(ups_data_getsent.COMMAND_INFO[5]),hextodbc(ups_data_getsent.COMMAND_INFO[6]));  //����ʱ��	
		ups_data_getsent.LENdata.towbyte.LENID = 0x00 *2;
		ups_data_getsent.LENdata.towbyte.LLCSUM = length_sum_check(ups_data_getsent.LENdata.towbyte.LENID);
		break;
	case UPS_CID2_GET_VER://��λ����ȡЭ��汾��
		if(0 != ups_data_getsent.LENdata.towbyte.LENID)
		{
			ups_data_getsent.CID2 = UPS_CID2_ERROR_INFO;
		}
		else
		{
			ups_data_getsent.CID2 = UPS_CID2_BACKE_NOR;
		}
		ups_data_getsent.LENdata.towbyte.LENID = 0x00 *2;
		ups_data_getsent.LENdata.towbyte.LLCSUM = length_sum_check(ups_data_getsent.LENdata.towbyte.LENID);
		break;
	case UPS_CID2_GET_FACTORY://��λ����ȡ�豸������Ϣ	
		if(0 != ups_data_getsent.LENdata.towbyte.LENID)
		{
			ups_data_getsent.CID2 = UPS_CID2_ERROR_INFO;
		}
		else
		{
			ups_data_getsent.CID2 = UPS_CID2_BACKE_NOR;
		}
 		MemoryCopy( (U8 *)&ups_data_getsent.COMMAND_INFO[0], (U8*) &SystemConfig2.val.DeviceName[0], 10 );
		ups_data_getsent.COMMAND_INFO[10] = SystemConfig2.val.SWVersion >>8; 
		ups_data_getsent.COMMAND_INFO[11] = SystemConfig2.val.SWVersion; 
 		MemoryCopy( (U8 *)&ups_data_getsent.COMMAND_INFO[12], (U8*) &SystemConfig2.val.MNFName[0], 16 );
		ups_data_getsent.COMMAND_INFO[39] = 0x00;
		ups_data_getsent.COMMAND_INFO[38] = 0x00;
		ups_data_getsent.COMMAND_INFO[37] = 0x00;
		ups_data_getsent.COMMAND_INFO[36] = 0x00;
		ups_data_getsent.LENdata.towbyte.LENID = 0x40;
		ups_data_getsent.LENdata.towbyte.LLCSUM = length_sum_check(ups_data_getsent.LENdata.towbyte.LENID);
		break;
	case UPS_CID2_SET_BAND://��λ���趨ͨѶ���� ��ʱ�������Ĳ�����
		if(0x02 != ups_data_getsent.LENdata.towbyte.LENID)
		{
			ups_data_getsent.CID2 = UPS_CID2_ERROR_INFO;
		}
		else
		{
			ups_data_getsent.CID2 = UPS_CID2_BACKE_NOR;
		}
		ups_data_getsent.COMMAND_INFO[0] = 0x01;
		ups_data_getsent.LENdata.towbyte.LENID = 0x01 *2;
		ups_data_getsent.LENdata.towbyte.LLCSUM = length_sum_check(ups_data_getsent.LENdata.towbyte.LENID);
		break;
	case UPS_CID2_GET_PACKS://��λ����ȡPACK����	
		if(0x00 != ups_data_getsent.LENdata.towbyte.LENID)
		{
			ups_data_getsent.CID2 = UPS_CID2_ERROR_INFO;
		}
		else
		{
			ups_data_getsent.CID2 = UPS_CID2_BACKE_NOR;
		}
		ups_data_getsent.COMMAND_INFO[0] = 0x00;
		ups_data_getsent.COMMAND_INFO[1] = 0x01;
		ups_data_getsent.LENdata.towbyte.LENID = 0x02 *2;
		ups_data_getsent.LENdata.towbyte.LLCSUM = length_sum_check(ups_data_getsent.LENdata.towbyte.LENID);
		break;
	case UPS_CID2_GET_NMLS://��ȡģ�������������ݣ���������
		if(0x02 != ups_data_getsent.LENdata.towbyte.LENID)
		{
			ups_data_getsent.CID2 = UPS_CID2_ERROR_INFO;
		}
		else
		{
			ups_data_getsent.CID2 = UPS_CID2_BACKE_NOR;
		}

		if(0xFF == ups_data_getsent.COMMAND_INFO[0])
		{
			ups_data_getsent.COMMAND_INFO[0] = 0x01;
		}
		else
		{
			if(0x01 == ups_data_getsent.COMMAND_INFO[0])  
			{
				ups_data_getsent.COMMAND_INFO[0] = 0x01;
			}	
			else
			{
					sent_flag = GETING_FLAG; // ��Ŀ�� ��ַ ���ظ�
					ups_data_getsent.EOI  = 0;
					return ;
			}
		}

		pos = 1;
	//	ups_data_getsent.COMMAND_INFO[pos++] = CellNum;	
	//	for(i=0;i<CellNum;i++)
		{
	//		ups_data_getsent.COMMAND_INFO[pos++] = PackInfo.CellVol[i]>>8;
	//		ups_data_getsent.COMMAND_INFO[pos++] = PackInfo.CellVol[i];
		}

		ups_data_getsent.COMMAND_INFO[pos++] = 6;
    
//		ups_data_getsent.COMMAND_INFO[pos++] = 0;
//		ups_data_getsent.COMMAND_INFO[pos++] = V82Realdata.Temp[0][0] ;
//		ups_data_getsent.COMMAND_INFO[pos++] = 0;
//		ups_data_getsent.COMMAND_INFO[pos++] = V82Realdata.Temp[1] ;
//		ups_data_getsent.COMMAND_INFO[pos++] = 0;
//		ups_data_getsent.COMMAND_INFO[pos++] = V82Realdata.Temp[2] ;
//		ups_data_getsent.COMMAND_INFO[pos++] = 0;
//		ups_data_getsent.COMMAND_INFO[pos++] = V82Realdata.Temp[3] ;
//		ups_data_getsent.COMMAND_INFO[pos++] = 0;
//		ups_data_getsent.COMMAND_INFO[pos++] = V82Realdata.Temp[4] ;	//: ÿ���¶ȵ����ݣ�65 ��ʾ 25�棬��ƫ�� 40�� ;
//		ups_data_getsent.COMMAND_INFO[pos++] = 0;
//		ups_data_getsent.COMMAND_INFO[pos++] = V82Realdata.Temp[5];

		ups_data_getsent.COMMAND_INFO[pos++] = 0;
		ups_data_getsent.COMMAND_INFO[pos++] = PackInfo.PackStatus.unit.Chgfet; //��翪��״̬��1 Ϊ��
		ups_data_getsent.COMMAND_INFO[pos++] = 0;
		ups_data_getsent.COMMAND_INFO[pos++] = PackInfo.PackStatus.unit.Dsgfet;	//  //��ѹ����,ѹ���,���߱���//�ŵ翪��״̬��1 Ϊ�򿪣�0 λ�ر� 
		
		temp_16 = (I16)(PackInfo.Current/10);
		ups_data_getsent.COMMAND_INFO[pos++] =  (U8)(temp_16>>8);
		ups_data_getsent.COMMAND_INFO[pos++] =  (U8)(temp_16 & 0x00FF);
		temp_16 = PackInfo.PackVol/10;
		ups_data_getsent.COMMAND_INFO[pos++] =  (U8)(temp_16>>8);
		ups_data_getsent.COMMAND_INFO[pos++] =  (U8)(temp_16 & 0x00FF);
		
		ups_data_getsent.COMMAND_INFO[pos++] =  (U8)((PackInfo.RC/10)>>8);
		ups_data_getsent.COMMAND_INFO[pos++] =  (U8)((PackInfo.RC/10) & 0x00FF);
		//for(i=0;i<6;i++)
			ups_data_getsent.COMMAND_INFO[pos++] = 0;
		ups_data_getsent.COMMAND_INFO[pos++] =  (U8)((PackInfo.FCC/10)>>8);
		ups_data_getsent.COMMAND_INFO[pos++] =  (U8)((PackInfo.FCC/10) & 0x00FF);
		
		ups_data_getsent.COMMAND_INFO[pos++] =  (U8)((PackInfo.CycleCount/10)>>8);
		ups_data_getsent.COMMAND_INFO[pos++] =  (U8)((PackInfo.CycleCount/10) & 0x00FF);
		
		ups_data_getsent.COMMAND_INFO[pos++] =  (U8)(PackInfo.RSOC/10);
		ups_data_getsent.COMMAND_INFO[pos++] =  (U8)(PackInfo.SOH/10);
		
		ups_data_getsent.COMMAND_INFO[pos++] =  (U8)((V82Realdata.BlanceState/10)>>8);
		ups_data_getsent.COMMAND_INFO[pos++] =  (U8)((V82Realdata.BlanceState/10) & 0x00FF);
		
		for(i=0;i<1;i++)
		{
			ups_data_getsent.COMMAND_INFO[pos++] = 0;
			ups_data_getsent.COMMAND_INFO[pos++] = 0;
		}

		ups_data_getsent.LENdata.towbyte.LENID = pos *2;
		ups_data_getsent.LENdata.towbyte.LLCSUM = length_sum_check(ups_data_getsent.LENdata.towbyte.LENID);
		break;
	case UPS_CID2_GET_WARN:////��ȡ�澯��Ϣ
		if(0x02 != ups_data_getsent.LENdata.towbyte.LENID)
		{
			ups_data_getsent.CID2 = UPS_CID2_ERROR_INFO;
		}
		else
		{
			ups_data_getsent.CID2 = UPS_CID2_BACKE_NOR;
		}
		
		if(0xFF == ups_data_getsent.COMMAND_INFO[0])
		{
			ups_data_getsent.COMMAND_INFO[0] = 0x01;
		}
		else
		{
			if(0x01 == ups_data_getsent.COMMAND_INFO[0])  
			{
				ups_data_getsent.COMMAND_INFO[0] = 0x01;
			}	
			else
			{
					sent_flag = GETING_FLAG; // ��Ŀ�� ��ַ ���ظ�
					ups_data_getsent.EOI  = 0;
					return ;
			}
		}
		pos = 1;
//״ָ̬ʾ  1
/*
0	�����ѹ�澯	1:�澯   0:����
1	����Ƿѹ�澯	1:�澯   0:����
2	��ѹ��ѹ�澯	1:�澯   0:����
3	��ѹǷѹ�澯	1:�澯   0:����
4	�������澯	1:�澯   0:����
5	�ŵ����1�澯	1:�澯   0:����
6	ѹ���	1:�澯   0:����
7	ѹ���	1: ����   0:����
*/
	 ups_data_getsent.COMMAND_INFO[pos++] =  
	 ((V82Realdata.Vstate.unit.wVOV)<<0)
	 +((V82Realdata.Vstate.unit.wVUV)<<1)
	 +((V82Realdata.Vstate.unit.wBVOV)<<2)
	 +((V82Realdata.Vstate.unit.wBVUV)<<3)
	 +((V82Realdata.Cstate.unit.wOCCSG)<<4)	 
	 +((V82Realdata.Cstate.unit.wOCDSG)<<5)	 
	 +((0)<<6)
	 +((V82Realdata.Vstate.unit.VDIFF)<<7);

/*
0	�����ѹ����	1: ����   0:����
1	����Ƿѹ����	1: ����   0:����
2	��ѹ��ѹ����	1: ����   0:����
3	��ѹǷѹ����	1: ����   0:����
4	����������	1: ����   0:����
5	�ŵ����1����	1: ����   0:����
6	�ŵ����2����	1: ����   0:����
7	��·����		1: ����   0:����
*/
	 ups_data_getsent.COMMAND_INFO[pos++] =  
	 ((V82Realdata.Vstate.unit.VOV)<<0)+
	 ((V82Realdata.Vstate.unit.VUV)<<1)+
	 ((V82Realdata.Vstate.unit.BVOV)<<2)+
	 ((V82Realdata.Vstate.unit.BVUV)<<3)+
	 ((V82Realdata.Cstate.unit.OCCSG)<<4)+	  
	 ((V82Realdata.Cstate.unit.OCDSG1)<<5)+	 
	 ((V82Realdata.Cstate.unit.OCDSG2)<<6)+	 
	 ((V82Realdata.Cstate.unit.SHORT)<<7);
/*
0	�����¸澯	1:�澯   0:����
1	�����¸澯	1:�澯   0:����
2	�ŵ���¸澯	1:�澯   0:����
3	�ŵ���¸澯	1:�澯   0:����
4	�������¸澯	1:�澯   0:����
5	�������¸澯	1:�澯   0:����
6	MOSFET���¸澯	1:�澯   0:����
7	MOSFET���¸澯	1:�澯   0:����
*/
	 ups_data_getsent.COMMAND_INFO[pos++] =  
	 ((0)<<0)+
	 ((0)<<1)+
	 ((0)<<2)+
	 ((0)<<3)+
	 ((V82Realdata.Tstate.unit.wTENV_H)<<4)+	  
	 ((V82Realdata.Tstate.unit.wTENV_L)<<5)+	 
	 ((V82Realdata.Tstate.unit.wTFET_H)<<6)+	 
	 ((V82Realdata.Tstate.unit.wTFET_L)<<7);
/*
0	�����±���	1: ����   0:����
1	�����±���	1: ����   0:����
2	�ŵ���±���	1: ����   0:����
3	�ŵ���±���	1: ����   0:����
4	�������±���	1: ����   0:����
5	�������±���	1: ����   0:����
6	MOSFET���±���	1: ����   0:����
7	MOSFET���±���	1: ����   0:����
*/
	 ups_data_getsent.COMMAND_INFO[pos++] =  
	 ((V82Realdata.Tstate.unit.TCELL_CSGH)<<0)+
	 ((V82Realdata.Tstate.unit.TCELL_CSGL)<<1)+
	 ((V82Realdata.Tstate.unit.TCELL_DSGH)<<2)+
	 ((V82Realdata.Tstate.unit.TCELL_DSGL)<<3)+
	 ((V82Realdata.Tstate.unit.TENV_H)<<4)+	  
	 ((V82Realdata.Tstate.unit.TENV_L)<<5)+	 
	 ((V82Realdata.Tstate.unit.TFET_H)<<6)+	 
	 ((V82Realdata.Tstate.unit.TFET_L)<<7);
/*
0	���Ӹ澯	1:�澯   0:����
1	SOC�͸澯	1:�澯   0:����
2	CFET ����澯	1:�澯   0:����
3	DFET ����澯	1:�澯   0:����
4	��о�¶ȸ߸澯	1:�澯   0:����
5	��о�¶ȵ͸澯	1:�澯   0:����
6	��Ч������ָʾ	1:��Ч������ 0:�޳�����
7	��Ч�ŵ����ָʾ	1:��Ч�ŵ���� 0:�޷ŵ����
*/
	 ups_data_getsent.COMMAND_INFO[pos++] =  
	 ((0)<<0)+
	 ((0)<<1)+
	 ((V82Realdata.FETState.unit.CFET_DAMAGE)<<2)+
	 ((V82Realdata.FETState.unit.DFET_DAMAGE)<<3)+
	 ((V82Realdata.Tstate.unit.wTCELL_H)<<4)+	  
	 ((V82Realdata.Tstate.unit.wTCELL_L)<<5)+	 
	 ((CHGING)<<6)+	 
	 ((DSGING)<<7);
/*
0	DFET ָʾ	1:ON   0:OFF
1	CFET ָʾ	1:ON   0:OFF
2	PreFET ָʾ	1:ON   0:OFF
3	HaveAC	1:ON   0:OFF
4	Fully charged	1:����״̬   0:������
5	�����������ʹ��	1:ʹ��   0:��ֹ
6	��������	
7	�����	
*/
	 ups_data_getsent.COMMAND_INFO[pos++] =  
	 ((V82Realdata.FETState.unit.DFET)<<0)+
	 ((V82Realdata.FETState.unit.CFET)<<1)+
	 ((V82Realdata.FETState.unit.Pchgfet)<<2)+
	 ((0)<<3)+
	 ((FC_p)<<4)+	  
	 ((0)<<5)+	 
	 ((0)<<6)+	 
	 ((0)<<7);

/*
0	���ȹ���ʹ��	1:ʹ��   0:��ֹ
1	����״̬	1:ON   0:OFF
2	ɢ�ȹ���ʹ��	1:ʹ��   0:��ֹ
3	ɢ��״̬	1:ON   0:OFF
4	����������ʹ��	1:ʹ��   0:��ֹ
5	������״̬	1:ON   0:OFF
6	LED����ʹ��	1:ʹ��   0:��ֹ
7	GPRS����ʹ��	1:ʹ��   0:��ֹ
*/
		ups_data_getsent.COMMAND_INFO[pos++] = 0;	//7
		ups_data_getsent.COMMAND_INFO[pos++] = 0;	
		ups_data_getsent.COMMAND_INFO[pos++] = 0;
		ups_data_getsent.COMMAND_INFO[pos++] = 0;
		ups_data_getsent.COMMAND_INFO[pos++] = 0;	
		ups_data_getsent.COMMAND_INFO[pos++] = 0;
		ups_data_getsent.COMMAND_INFO[pos++] = 0;
		ups_data_getsent.COMMAND_INFO[pos++] = 0;
		ups_data_getsent.COMMAND_INFO[pos++] = 0;//16
		
		ups_data_getsent.COMMAND_INFO[pos++] = 0;
		ups_data_getsent.COMMAND_INFO[pos++] = 0;
		ups_data_getsent.CID2 = UPS_CID2_BACKE_NOR;
		ups_data_getsent.LENdata.towbyte.LENID = pos *2;
		ups_data_getsent.LENdata.towbyte.LLCSUM = length_sum_check(ups_data_getsent.LENdata.towbyte.LENID);
		break;
	
	case UPS_CID2_GET_SYSCONFIG:// ��ȡ��1�� ϵͳ����
		if(2 != ups_data_getsent.LENdata.towbyte.LENID)
		{
			ups_data_getsent.CID2 = UPS_CID2_ERROR_INFO;
		}
		else
		{
			ups_data_getsent.CID2 = UPS_CID2_BACKE_NOR;
		}
		if(0xFF == ups_data_getsent.COMMAND_INFO[0])
		{
			ups_data_getsent.COMMAND_INFO[0] = 0x01;
		}
		else
		{
			if(0x01 == ups_data_getsent.COMMAND_INFO[0])  
			{
				ups_data_getsent.COMMAND_INFO[0] = 0x01;
			}	
			else
			{
					sent_flag = GETING_FLAG; // ��Ŀ�� ��ַ ���ظ�
					ups_data_getsent.EOI  = 0;
					return ;
			}
		}
		pos = 0;
		p = (U8 *) & V82system ;
		for(i=0;i<39;i++)
		{
			ups_data_getsent.COMMAND_INFO[i*2] = p[i*2+1];
			ups_data_getsent.COMMAND_INFO[i*2+1] = p[i*2];
		}
		for(i=78;i<110;i++)
		{
			ups_data_getsent.COMMAND_INFO[i] = p[i];
		}
	//	MemoryCopy((U8  *)&ups_data_getsent.COMMAND_INFO[1], (U8 *) & V82system, sizeof(V82system)-2 );	// ?��3?V82SYS 2?��y ��?tempData
		ups_data_getsent.LENdata.towbyte.LENID =  (110) *2;
		ups_data_getsent.LENdata.towbyte.LLCSUM = length_sum_check(ups_data_getsent.LENdata.towbyte.LENID);
		break;
	
	case UPS_CID2_SET_SYSCONFIG://�趨ϵͳ��������������
	
		if(2 != ups_data_getsent.LENdata.towbyte.LENID)
		{
			ups_data_getsent.CID2 = UPS_CID2_ERROR_INFO;
		}
		else
		{
			ups_data_getsent.CID2 = UPS_CID2_BACKE_NOR;
		}
		if(0xFF == ups_data_getsent.COMMAND_INFO[0])
		{
			ups_data_getsent.COMMAND_INFO[0] = 0x01;
		}
		else
		{
			if(0x01 == ups_data_getsent.COMMAND_INFO[0])  
			{
				ups_data_getsent.COMMAND_INFO[0] = 0x01;
			}	
			else
			{
					sent_flag = GETING_FLAG; // ��Ŀ�� ��ַ ���ظ�
					ups_data_getsent.EOI  = 0;
					return ;
			}
		}		
		/*
		p = (U8 *) & V82system ;
		for(i=0;i<39;i++)
		{
			p[i*2+1] = ups_data_getsent.COMMAND_INFO[i*2];
			p[i*2] = ups_data_getsent.COMMAND_INFO[i*2+1];
		}
		for(i=78;i<110;i++)
		{
			p[i] = ups_data_getsent.COMMAND_INFO[i];
		}
		if(Savev82SystemToIap())  
			{
				ups_data_getsent.CID2 = UPS_CID2_ACK_OK; //�ɹ�
			}
			else
			{
				ups_data_getsent.CID2 = UPS_CID2_ACK_FAIL; //ʧ��
			}	
		*/
		ups_data_getsent.LENdata.towbyte.LENID =1*2;
		ups_data_getsent.LENdata.towbyte.LLCSUM = length_sum_check(ups_data_getsent.LENdata.towbyte.LENID);
		break;
	case UPS_CID2_GET_HISTORYWARN://��ȡ��ʷ�澯��¼	
		ups_data_getsent.CID2 = UPS_CID2_ERROR_INFO;
		ups_data_getsent.LENdata.towbyte.LENID = 0x00 *2;
		ups_data_getsent.LENdata.towbyte.LLCSUM = length_sum_check(ups_data_getsent.LENdata.towbyte.LENID);
		break;
	
	case UPS_CID2_GET_HISTORYRECORD://��ȡ��ʷ���ݼ�¼	
		ups_data_getsent.CID2 = UPS_CID2_ERROR_INFO;
		ups_data_getsent.LENdata.towbyte.LENID = 0x00 *2;		
		ups_data_getsent.LENdata.towbyte.LLCSUM = length_sum_check(ups_data_getsent.LENdata.towbyte.LENID);

		break;
	case UPS_CID2_GET_POWERONOFF://���ػ�����
		if(2 != ups_data_getsent.LENdata.towbyte.LENID)
		{
			ups_data_getsent.CID2 = UPS_CID2_ERROR_INFO;
		}
		else
		{
			ups_data_getsent.CID2 = UPS_CID2_BACKE_NOR;
		}
		if(0x01==ups_data_getsent.COMMAND_INFO[0])
		{
			set_poweron();
			ComPowerOffFlag = 0;
		}
		if(0x02==ups_data_getsent.COMMAND_INFO[0])
		{
			set_poweroff();
			ComPowerOffFlag = 1;
		}
		
		ups_data_getsent.LENdata.towbyte.LENID = 0x01 *2;		
		ups_data_getsent.LENdata.towbyte.LLCSUM = length_sum_check(ups_data_getsent.LENdata.towbyte.LENID);
		break;	

	case UPS_CID2_SET_DFET://�ֶ����� FET ����	
		if(2 != ups_data_getsent.LENdata.towbyte.LENID)
		{
			ups_data_getsent.CID2 = UPS_CID2_ERROR_INFO;
		}
		else
		{
			ups_data_getsent.CID2 = UPS_CID2_BACKE_NOR;
		}
		FET_manual_vaule = ups_data_getsent.COMMAND_INFO[0];
		ups_data_getsent.LENdata.towbyte.LENID = 0x01*2;		
		ups_data_getsent.LENdata.towbyte.LLCSUM = length_sum_check(ups_data_getsent.LENdata.towbyte.LENID);
		break;
	case UPS_CID2_PCSET_DFET://�ֶ����� FET ����2	
		if(2 != ups_data_getsent.LENdata.towbyte.LENID)
		{
			ups_data_getsent.CID2 = UPS_CID2_ERROR_INFO;
		}
		else
		{
			ups_data_getsent.CID2 = UPS_CID2_BACKE_NOR;
		}
		if(0!=sent_back_dealy)
		{
			sent_back_dealy =0;
			ups_data_getsent.COMMAND_INFO[0] = 0;
			if(1==PackInfo.PackStatus.unit.Dsgfet)
			{
				ups_data_getsent.COMMAND_INFO[0] |=0x01;
			}
			if(1==PackInfo.PackStatus.unit.Chgfet)
			{
				ups_data_getsent.COMMAND_INFO[0] |=0x02;
			}
		}
		else
		{
			ups_data_getsent.CID2 = UPS_CID2_PCSET_DFET;
			sent_back_dealy = REBACK_DELAYMS ;
			FET_manual_vaule = ups_data_getsent.COMMAND_INFO[0];
			sent_flag = GETING_FLAG;
		}
		
		ups_data_getsent.LENdata.towbyte.LENID = 0x01 *2;		
		ups_data_getsent.LENdata.towbyte.LLCSUM = length_sum_check(ups_data_getsent.LENdata.towbyte.LENID);
		break;
		
		case UPS_CID2_GET_CAPACITY:// ��ȡ ��������
			if(0 != ups_data_getsent.LENdata.towbyte.LENID)
			{
				ups_data_getsent.CID2 = UPS_CID2_ERROR_INFO;
			}
			else
			{
				ups_data_getsent.CID2 = UPS_CID2_BACKE_NOR;
			}
			MemoryCopy( (U8 *)&ups_data_getsent.COMMAND_INFO[0], (U8*) &TempSocVolt_capacity, sizeof(TempSocVolt_capacity) );
			ups_data_getsent.LENdata.towbyte.LENID = sizeof(TempSocVolt_capacity) *2;
			ups_data_getsent.LENdata.towbyte.LLCSUM = length_sum_check(ups_data_getsent.LENdata.towbyte.LENID);
		break;
			
		case UPS_CID2_SET_CAPACITY:// ������������
			if(0 != ups_data_getsent.LENdata.towbyte.LENID)
			{
				ups_data_getsent.CID2 = UPS_CID2_ERROR_INFO;
			}
			else
			{
				ups_data_getsent.CID2 = UPS_CID2_BACKE_NOR;
			}
			MemoryCopy( (U8   *) & TempSocVolt_capacity,(U8  *)&ups_data_getsent.COMMAND_INFO[0], sizeof(TempSocVolt_capacity) );	// ����V82SYS ���� ��tempData
			if ( SaveSystemAndOffsetToIap() )
			{
				ups_data_getsent.COMMAND_INFO[0] = UPS_CID2_ACK_OK; //�ɹ�
			}
			else
			{
				ups_data_getsent.COMMAND_INFO[0] = UPS_CID2_ACK_FAIL; //ʧ��
			}	
			ups_data_getsent.LENdata.towbyte.LENID = 1 *2;
			ups_data_getsent.LENdata.towbyte.LLCSUM = length_sum_check(ups_data_getsent.LENdata.towbyte.LENID);
		break;	
		case UPS_CID2_READ_CAPACITY://  ��������� ���� ��ѹ  ���� ����
			if(0 != ups_data_getsent.LENdata.towbyte.LENID)
			{
				ups_data_getsent.CID2 = UPS_CID2_ERROR_INFO;
			}
			else
			{
				ups_data_getsent.CID2 = UPS_CID2_BACKE_NOR;
			}
			Capcaity_Calcu ((U16  *)&maxiv,(U16  *)&maxia,(U16  *)&maxoa , (U8  *)&charge_onoff,(U8  *)&discharge_onoff );
			pos =0;
			ups_data_getsent.COMMAND_INFO[pos++] = maxiv>>8;
			ups_data_getsent.COMMAND_INFO[pos++] = maxiv;
			ups_data_getsent.COMMAND_INFO[pos++] = maxia>>8;
			ups_data_getsent.COMMAND_INFO[pos++] = maxia;
			ups_data_getsent.COMMAND_INFO[pos++] = maxoa>>8;
			ups_data_getsent.COMMAND_INFO[pos++] = maxoa;
			ups_data_getsent.COMMAND_INFO[pos++] = charge_onoff;
			ups_data_getsent.COMMAND_INFO[pos++] = discharge_onoff;
			ups_data_getsent.LENdata.towbyte.LENID = pos *2;
			ups_data_getsent.LENdata.towbyte.LLCSUM = length_sum_check(ups_data_getsent.LENdata.towbyte.LENID);
		break;	
		case UPS_CID2_READ_WORKSTATS://  ��������� ���� ��ѹ  ���� ����
			if(0 != ups_data_getsent.LENdata.towbyte.LENID)
			{
				ups_data_getsent.CID2 = UPS_CID2_ERROR_INFO;
			}
			else
			{
				ups_data_getsent.CID2 = UPS_CID2_BACKE_NOR;
			}
			pos =0;
			ups_data_getsent.COMMAND_INFO[pos++] = PowerStatu;

			ups_data_getsent.LENdata.towbyte.LENID = pos *2;
			ups_data_getsent.LENdata.towbyte.LLCSUM = length_sum_check(ups_data_getsent.LENdata.towbyte.LENID);
		break;				
	default:
		
		break;
	}
 		
 	
}




