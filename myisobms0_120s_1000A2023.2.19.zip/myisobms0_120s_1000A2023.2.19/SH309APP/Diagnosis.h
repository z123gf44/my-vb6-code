
#ifndef	__DIAGNOSIS_H__
#define __DIAGNOSIS_H__
#include "C51_TYPE.h"

typedef struct 
{
	I8 OTD;
	I8 OTDR;
	I8 UTD;
	I8 UTDR;
	I8 OTC;
	I8 OTCR;
	I8 UTC;
	I8 UTCR;	
}tdsTempProt;

typedef struct
{
	unsigned char OTD		:1;
	unsigned char UTD		:1;
	unsigned char OTC		:1;
	unsigned char UTC		:1;
	unsigned char PWR1		:1;
	unsigned char AMB		:1;
	unsigned char Reserved	:2;
}tdsDiagTemp;

typedef struct
{
	unsigned char OTD;
	unsigned char UTD;
	unsigned char OTC;
	unsigned char UTC;
	unsigned char PWR1;
	unsigned char AMB;
}tdsDiagTempCnt;


typedef enum
{
	PowerOnPre_e = 0, //���ϵ�
	PowerOn_e,
	PowerSleepPre_e,
	PowerSleep_e,
	PowerOffPre_e,
	PowerOff_e,	
}tdePowerStatu;

#ifndef _GLOBAL_DIAG_
//	extern tdsTempProt  TempProt;
//	extern tdsDiagTemp  DiagTemp;
	extern tdePowerStatu  PowerStatu;
	extern U8 ComConnect_flag;
	extern unsigned char  NoComTime;		//û�д���ͨѶ��ʱ�䣬��λ���룬����255��
	extern U16   NoCurrentTime;	//û�е�����ʱ�䣬 ��λ����
	extern U8 ComPowerOffFlag;
//	extern U8 OC_LockFlag;		//���������������Զ��ָ�
	extern U8 	CycleChgDsgStatu;		//1:���״̬��0���ŵ�״̬  ���ڼ�¼ѭ������
	
	extern U8 flgMcuPowerOn;
  extern U8 flgMcujuston;
#endif

void TempJudge ( void );
//void OC_Recovery_Judge ( void );	//1S event
void MosJudge ( void );
void UpdatePackState ( void );
//void KeyJudge ( void );
void VolJudge ( void );
void ShutdownJudge ( void );		//1S event
void PowerJudge ( void );
void CheckCharger ( void );		//1s event
//void CheckChargeCom ( void );		//1S event

#endif
