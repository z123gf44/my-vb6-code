#ifndef __CALCULATE_H__
#define __CALCULATE_H__
#include "C51_TYPE.h"
 
typedef volatile struct
{
	I8		tVal;
	U32	tRes;	
}tdsTres_table;

 

U16 CalcuTemp(U16 getdata);
void CalculateAfeTemperature(void);

U8 TableCheck_Temp ( U32 *pTad );
void CalculateTemperature ( void );
void CalculatePackVoltage ( void );

void CalculateAfeCellVol ( void );
void CalculateAfeCurrent( void );

#endif
