
#define _GLOBAL_EEPROM_
#include "Include.h"
#include "TwiIO.h"
#include "Eeprom.h"
U8  ack_485;  // = 5A ��ʾ �ɹ�
extern U16  Protect_state;				        // ���� �ж� ����״̬ // U8  code E2PROM_RECORD_LEN = 128 / (128/sizeof(tdsRecordVar));	//�ܿ�24C512ҳ������⣬PAGE = 128BYTE
// U16  code RecordQuantity = ( E2PROM_RECORD_END_ADDR - E2PROM_RECORD_STA_ADDR ) / (128 / (128/sizeof(tdsRecordVar)));	//����¼����

#define E2PROM_RECORD_LEN   E2PROM_PAGESIZE 	//�ܿ�24C512ҳ������⣬PAGE = 128BYTE
#define RecordQuantity   (( E2PROM_RECORD_END_ADDR - E2PROM_RECORD_STA_ADDR ) / (E2PROM_PAGESIZE)) 	//����¼����
U8   restult_read03=0;
U8   WriteRecord;
U8   WriteRecordzgf;
 
#define  RECORD_BUF_LEN		3
tdsRecordVar  RecordVar[RECORD_BUF_LEN];
ptdsRecordVar  pRecordVarIn, pRecordVarOut;
tdsRecordOutline  RcdOutline;
U8   V82_PC_TO_mcuCode ;  //  PC ���� =1 =2 -3 
U8   V82_BackCode ;  // �ظ�PC ���� =1 =2 -3 
static U16   CurRdRecordNum = 0;
static U16   CurRdRecordAddr;
static tdsRecordOutlineTemp  RcdOutlineTemp;
tdsRecordVar  RecordVarCheck;

U8  RecordWriting_flag;	//0=��д�ꣻ1=д������
extern U8   not_use_and_use;
void EepStatusJudge ( void )
{
	if ( TwiRwBuf_pOut.status.state == TWI_RW_SUCCESS )
	{
		PackInfo.EepromState = 1;
	}
	else
	{
		PackInfo.EepromState = 0;
		if(not_use_and_use==0)
		{
		  EepRecord_Init();		
		}
	}
}
 
void RecordOutlineToEeprom (void)
{
	MemoryCopy(  (U8 *)&RcdOutlineTemp.Outline,  (U8 *)&RcdOutline, sizeof(RcdOutline) );
	RcdOutlineTemp.checkcode = 0x72;
	RcdOutlineTemp.CheckSum = GetCheckSum((U8  *)&RcdOutlineTemp, sizeof(RcdOutlineTemp) -4 );
	
	TwiDeal( EEPROM_ID, TWI_DEAL_WRITE, E2PROM_RECORD_OUTLINE_1_ADDR, sizeof(RcdOutlineTemp), (U8  *)&RcdOutlineTemp, EepStatusJudge );
	TwiDeal( EEPROM_ID, TWI_DEAL_WRITE, E2PROM_RECORD_OUTLINE_2_ADDR, sizeof(RcdOutlineTemp), (U8  *)&RcdOutlineTemp, EepStatusJudge );
}// void TwiDeal ( U8  sla_id,  tdeTwiRwState rw, U16  data_addr, U8  length, U8  *pbuf, void (*pFun)() )

void EepRecord_Erase_Check ( void )
{
	EepStatusJudge();
	if ( (PackInfo.EepromState == 1)
	 && (RcdOutlineTemp.Outline.CurRecordAddr == E2PROM_RECORD_STA_ADDR)
	 && (RcdOutlineTemp.Outline.RecodeNum == 0)
	 && (RcdOutlineTemp.checkcode == 0x72)
	 && (RcdOutlineTemp.CheckSum == GetCheckSum((U8  *)&RcdOutlineTemp, sizeof(RcdOutlineTemp) -4) )
	  )
	{
		EepromRecordWrite(rtEepromErase_e);
		ack_485 = CMD_VALID_ACK; 
	}
	else
	{
			ack_485 =CMD_INVALID_ACK; 
	}
}

void EepRecord_Erase ( void )
{
  if(SystemConfig2.val.PackConfigMap.unit.EnEEPRomBK ==1 )
	{
	   return;
	}
	if ( PackInfo.EepromState == 1 )//1:EEPROMͨѶ����	0��EEPROMͨѶ�쳣  
	{
		RcdOutline.CurRecordAddr = E2PROM_RECORD_STA_ADDR; // ���� ADDR1 ADDR2 �ٶ�ADDR1 �жϲ����Ƿ�� 
		RcdOutline.RecodeNum = 0;
		RecordOutlineToEeprom();
		TwiDeal( EEPROM_ID, TWI_DEAL_READ, E2PROM_RECORD_OUTLINE_1_ADDR, sizeof(RcdOutlineTemp), (U8  *)&RcdOutlineTemp, EepRecord_Erase_Check );
	}
	else
	{
			ack_485 =CMD_INVALID_ACK; 
	}
}

void EepRecord_Init_2 ( void )
{
	EepStatusJudge();
	if ( (PackInfo.EepromState == 0) || (RcdOutlineTemp.checkcode != 0x72) || (RcdOutlineTemp.CheckSum != GetCheckSum((U8  *)&RcdOutlineTemp, sizeof(RcdOutlineTemp) -4) ) )
	{
		EepRecord_Erase();
	}
	else
	{
		RcdOutline.CurRecordAddr = RcdOutlineTemp.Outline.CurRecordAddr;
		RcdOutline.RecodeNum = RcdOutlineTemp.Outline.RecodeNum;
	}
}

void EepRecord_Init_1 ( void )
{
	EepStatusJudge();
	if ( (PackInfo.EepromState == 0) || (RcdOutlineTemp.checkcode != 0x72) || (RcdOutlineTemp.CheckSum != GetCheckSum((U8  *)&RcdOutlineTemp, sizeof(RcdOutlineTemp) -4) ) )
	{
		TwiDeal( EEPROM_ID, TWI_DEAL_READ, E2PROM_RECORD_OUTLINE_2_ADDR, sizeof(RcdOutline), (U8  *)&RcdOutline, EepRecord_Init_2 );
	}
	else
	{
		RcdOutline.CurRecordAddr = RcdOutlineTemp.Outline.CurRecordAddr;
		RcdOutline.RecodeNum = RcdOutlineTemp.Outline.RecodeNum;
	}
}

 
U8   not_use_and_use ;	// ���ظ�  
void EepRecord_Init ( void )// ���� ���ã� �ȶ�ADDR1 ������� ADDR2 �����ADDR2�����ǲ���ADDR1 ADDR2 
{
  if(SystemConfig2.val.PackConfigMap.unit.EnEEPRomBK ==1 )
	{
	   return;
	}
	not_use_and_use=1;
	pRecordVarIn  = 	RecordVar;
	pRecordVarOut =   RecordVar;
	RecordWriting_flag = 0;
	TwiDeal( EEPROM_ID, TWI_DEAL_READ, E2PROM_RECORD_OUTLINE_1_ADDR, sizeof(RcdOutlineTemp), (U8  *)&RcdOutlineTemp, EepRecord_Init_1 );
		not_use_and_use=0;
} // ִ������ �� EepRecord_Init_1 -> 	EepStatusJudge() -> EepRecord_Init Ȼ�� ���ҵ��� ��ѭ��
  //  TwiRwBuf_pOut.status.state == TWI_RW_WORKING ʱ  

void EepWriteCheck_1 ( void )
{
	static U8  failcnt = 0;
	
	EepStatusJudge();
	if ( PackInfo.EepromState == 1 )
	{                                                               //         ���� �ֹ������ڴ濴����4B������SIZEOF 4C��zgf
 		if ( RecordVarCheck.CheckSum != GetCheckSum_Byte( (U8  *)&RecordVarCheck, sizeof(tdsRecordVar) -1 ) )//  ����  1 д ���� �������ж�
		{
			if ( failcnt < 3)
			{
				failcnt ++;
				TwiDeal( EEPROM_ID, TWI_DEAL_WRITE, RcdOutline.CurRecordAddr, sizeof(tdsRecordVar), (U8  *)pRecordVarOut, EepWriteCheck );
			} 
			else
			{
				//д��ʧ�ܣ�����
				RecordWriting_flag = 0;
				((pRecordVarOut + 1) - RecordVar) >= RECORD_BUF_LEN ? (pRecordVarOut = RecordVar) : (pRecordVarOut++) ;
			}
		}
		else
		{
			failcnt = 0;
			(RcdOutline.CurRecordAddr + E2PROM_RECORD_LEN)  < E2PROM_RECORD_END_ADDR ? (RcdOutline.CurRecordAddr += E2PROM_RECORD_LEN) : (RcdOutline.CurRecordAddr = E2PROM_RECORD_STA_ADDR);
			RcdOutline.RecodeNum +1 >= RecordQuantity ? (RcdOutline.RecodeNum = RecordQuantity) : (RcdOutline.RecodeNum++);
			RecordOutlineToEeprom();
			
			RecordWriting_flag = 0;
			((pRecordVarOut + 1) - RecordVar) >= RECORD_BUF_LEN ? (pRecordVarOut = RecordVar) : (pRecordVarOut++) ;
		}
	}
}

void EepWriteCheck ( void )// ���������� ѭ������  
{
	EepStatusJudge();
	if ( PackInfo.EepromState == 1 )
	{
		TwiDeal( EEPROM_ID, TWI_DEAL_READ, RcdOutline.CurRecordAddr, sizeof(tdsRecordVar), (U8  *)&RecordVarCheck, EepWriteCheck_1 );	// �ڶ�
	}
}

void EepromRecordWrite ( tduRecordType recordtype )
{
  if(SystemConfig2.val.PackConfigMap.unit.EnEEPRomBK ==1 )
	{
	   return;
	}
  static tduRecordType last_recordtype = rt_Max; // 2021.3.13 ���ֶ�μ�¼�� �� ÿ�ּ�¼ֻ����һ�� ��ʱ��¼����
	if((last_recordtype != recordtype) ||(rtOneHour == recordtype))
	{
		last_recordtype  = recordtype ;
		pRecordVarIn->Rtc = RtcTime;
		pRecordVarIn->RecordType = recordtype;
		pRecordVarIn->PackStatus = PackInfo.PackStatus;
	
		pRecordVarIn->FCC =   PackInfo.FCC;
		pRecordVarIn->RC  = PackInfo.RC;
		pRecordVarIn->RSOC = PackInfo.RSOC;
		pRecordVarIn->Protect_state = Protect_state;
	//	MemoryCopy(  (U8 *)&(pRecordVarIn->CellVol[0]), (U8 *) &PackInfo.CellVol[0], 32 );
		
		pRecordVarIn->PackVol = V82Realdata.PackVol;
		pRecordVarIn->Current   = 5000+PackInfo.Current/100; ;
	//	pRecordVarIn->AmbientTemp = V82Realdata.heat_Temp;
	//	pRecordVarIn->PowerTemp = V82Realdata.tongpai_Temp;
//		MemoryCopy(  (U8 *)&(pRecordVarIn->CellTemp[0]),  (U8 *)&(PackInfo.CellTemp[0]), 5 );
		pRecordVarIn->CheckSum = GetCheckSum_Byte( (U8  *)pRecordVarIn, sizeof(tdsRecordVar) -1 );
		((pRecordVarIn + 1) - RecordVar) >= RECORD_BUF_LEN ? (pRecordVarIn = RecordVar) : (pRecordVarIn++) ;
	}
}

void RecordWriteProcess ( void )	//500ms event
{
	static U8   cnt = 0;
	
	  if(SystemConfig2.val.PackConfigMap.unit.EnEEPRomBK ==1 )
	{
	   return;
	}
	if ( RecordWriting_flag == 0 )//0=��д�ꣻ1=д������
	{
		cnt = 0;
		if ( pRecordVarOut != pRecordVarIn )
		{
			RecordWriting_flag = 1;
			TwiDeal( EEPROM_ID, TWI_DEAL_WRITE, RcdOutline.CurRecordAddr, sizeof(tdsRecordVar), (U8  *)pRecordVarOut, EepWriteCheck );	///��һ
		}
	}
	else
	{
		if ( cnt < 3 )
		{
			cnt ++;
		}
		else
		{
			RecordWriting_flag = 0;
		}
	}
}
 
void UartReadRecord_1( void)
{
	static U8  failcnt = 0;
	static U8  failcnt1 = 0;
	
	EepStatusJudge(); 
	if ( PackInfo.EepromState == 1 )
	{
		if ( RecordVarCheck.CheckSum != GetCheckSum_Byte( (U8  *)&RecordVarCheck, sizeof(RecordVarCheck) -1 ) )
		{
			if ( failcnt < 3)
			{
				failcnt++;
				TwiDeal( EEPROM_ID, TWI_DEAL_READ, CurRdRecordAddr, sizeof(RecordVarCheck), (U8  *)&RecordVarCheck, UartReadRecord_1 );	// ���������ҵ��� 
			}
			else
			{
				if ( (CurRdRecordNum < RcdOutline.RecodeNum) && (failcnt1 < 10) )  // ��� EEPROM��ȡ����ȷ����һֱ���������������
				{
					failcnt = 0;
					failcnt1 ++;					
		    	V82_BackCode= 0xff; //��ȡ ����
				}
				else
				{
					V82_BackCode= 0xfF; //��ȡ ����
					EepRecord_Erase();
					failcnt1 = 0;
				}
			}
		}
		else
		{ // ��ȡ�ɹ�
			failcnt = 0;
		}
	}
} 

void V82UartReadRecord ( void )	//*pbuf--���������ݴ���ĵ�ַ��num-----0/��һ����1/��һ��, ����ֵ----00/�޼�¼��01/��һ����02/�м��¼��03/���һ��
{
	V82_BackCode= 0x00;
	if ( RcdOutline.RecodeNum > 0 )
	{		
		if ( V82_PC_TO_mcuCode == 0x00 )	
		{
			//��ȡ��һ����¼
			CurRdRecordNum = 1;
		}
		else if ( V82_PC_TO_mcuCode == 0x01 )
		{
			if ( CurRdRecordNum < RcdOutline.RecodeNum )
			{
				//��ȡ��һ����¼
				CurRdRecordNum++;
			}
			else
			{
				CurRdRecordNum = RcdOutline.RecodeNum;
			}
		}		
		
		if ( (CurRdRecordNum == 1) && (CurRdRecordNum < RcdOutline.RecodeNum) ) 
		{
			V82_BackCode= 0x01;
		}
		else if ( (CurRdRecordNum > 1) && (CurRdRecordNum < RcdOutline.RecodeNum) )
		{
			V82_BackCode= 0x02;
		}
		else
		{
			V82_BackCode= 0x03;
		}
		
		
		if ( CurRdRecordNum == 1 )
		{
			if ( RcdOutline.RecodeNum < RecordQuantity )
			{
				CurRdRecordAddr = E2PROM_RECORD_STA_ADDR;
			}
			else
			{
				CurRdRecordAddr = RcdOutline.CurRecordAddr;
			}
		}
		else
		{
			if ( RcdOutline.RecodeNum < RecordQuantity )
			{
				CurRdRecordAddr = (CurRdRecordNum -1) * E2PROM_RECORD_LEN + E2PROM_RECORD_STA_ADDR ;
			}
			else
			{
				if ( RcdOutline.CurRecordAddr + (CurRdRecordNum * E2PROM_RECORD_LEN) < E2PROM_RECORD_END_ADDR )
				{
					CurRdRecordAddr = ((CurRdRecordNum-1) * E2PROM_RECORD_LEN) + RcdOutline.CurRecordAddr + E2PROM_RECORD_STA_ADDR;
				}
				else
				{
					CurRdRecordAddr = (U16 )((( (I32)CurRdRecordNum - 1 - RecordQuantity) * E2PROM_RECORD_LEN) + RcdOutline.CurRecordAddr  + E2PROM_RECORD_STA_ADDR );
				}
			}
		}
		TwiDeal( EEPROM_ID, TWI_DEAL_READ, CurRdRecordAddr, sizeof(RecordVarCheck), (U8  *)&RecordVarCheck, UartReadRecord_1 );
	}	
}
 

void justReadRecord_zgf( void)
{  
	static U8  failcnt = 0;
	
	EepStatusJudge(); 
	if ( PackInfo.EepromState == 1 )
	{
		if ( RecordVarCheck.CheckSum != GetCheckSum_Byte( (U8  *)&RecordVarCheck, sizeof(RecordVarCheck) -1 ) )
		{
			if ( failcnt < 3)
			{
				failcnt++;
				TwiDeal( EEPROM_ID, TWI_DEAL_READ, RcdOutlineTemp.Outline.CurRecordAddr, sizeof(RecordVarCheck), (U8  *)&RecordVarCheck, UartReadRecord_1 );
			}
			else
			{
			}
		}
		else
		{ // ��ȡ�ɹ�
			failcnt = 0;
			if ( RecordVarCheck.RecordType ==rtPowerOff_e )
			{ 
				restult_read03=1;
			}
		}
	}
}
extern  U16 dsg_chg_chang_delays ,DsgTONotChg_chang_delays ;
U16 Record_state; // V82�� ��¼ ���� ״̬
U8   temp_soc;	//  ��ֹ SOC =0 �� һֱ��¼ 
void RecordBackup ( void )		//50ms event
{
	U32 re = 0;
	static U32  reb;
  U32 temp,temp2;
 
   if(SystemConfig2.val.PackConfigMap.unit.EnEEPRomBK ==1 )
	{
	   return;
	}
	
	
	if ( PackInfo.RSOC == 1000 )
	{
		re |= BV_L(crtSocfull_e);  // BV_L(a)  ((1UL<<a))		  //֧��32λ
	}
	else
	{
		re &= BVN_L(crtSocfull_e);
	}
	
	if(temp_soc != PackInfo.RSOC )
	{
		temp_soc=PackInfo.RSOC; //��� ������0 �ͻ� ֻ��¼һ��
		if ( PackInfo.RSOC == 0 )
		{
			re |= BV_L(crtSocempty_e);
		}
		else
		{
			re &= BVN_L(crtSocempty_e);
		}
	}
	
	if ( OV_r )
	{
		re |= BV_L(crtOv_e);
	}
	else
	{
		re &= BVN_L(crtOv_e);
	}
	
	if ( UV_r )
	{
		re |= BV_L(crtUv_e);
	}
	else
	{
		re &= BVN_L(crtUv_e);
	}
	
	if ( SC_r )
	{
		re |= BV_L(crtScd_e);
	}
	else
	{
		re &= BVN_L(crtScd_e);
	}
	
	if ( OCC_r )
	{
		re |= BV_L(crtOcc_e);
	}
	else
	{
		re &= BVN_L(crtOcc_e);
	}
	
	if ( OCD1_r )
	{
		re |= BV_L(crtOcd1_e);
	}
	else
	{
		re &= BVN_L(crtOcd1_e);
	}
	
	if ( OCD2_r )
	{
		re |= BV_L(crtOcd2_e);
	}
	else
	{
		re &= BVN_L(crtOcd2_e);
	}
	
	if ( OTC_r )
	{
		re |= BV_L(crtOtc_e);
	}
	else
	{
		re &= BVN_L(crtOtc_e);
	}
	
	if ( OTD_r )
	{
		re |= BV_L(crtOtd_e);
	}
	else
	{
		re &= BVN_L(crtOtd_e);
	}
	
	if ( UTC_r )
	{
		re |= BV_L(crtUtc_e);
	}
	else
	{
		re &= BVN_L(crtUtc_e);
	}

	

	if ( OPT_r )
	{
		re |= BV_L(crtOpt_e);
	}
	else
	{
		re &= BVN_L(crtOpt_e);
	}
	
	////////////////////////////////////////////// �ӳ�ŵ翪ʼ ///////////////////////////////////////////	

	if ( CHGING && dsg_chg_chang_delays >60) 
	{
	   if(WriteRecordzgf ==0)
     {
			  WriteRecordzgf=1;
		 		EepromRecordWrite(rtStratChg);
		 }			 
	}
	else
	{
	   if(WriteRecordzgf ==1)
     {
			  WriteRecordzgf=0;
		 		EepromRecordWrite(rtEndChg);
		 }
	}
	
	if ( DSGING )
	{
	   if(WriteRecordzgf ==0)
     {
			  WriteRecordzgf=2;
		 		EepromRecordWrite(rtStratDsg);
		 }			 
	}
	else
	{
	   if((WriteRecordzgf ==2)&&(DsgTONotChg_chang_delays >60))
     {
			 
			  WriteRecordzgf=0;
		 		EepromRecordWrite(rtEndDsg);
		 }
	}
	
 	//////////////////////////////////////////////zgf  �ӳ�ŵ翪ʼ ///////////////////////////////////////////	
   if(Record_state !=Protect_state )
	 {
	    EepromRecordWrite( rt_Protect_state );
		  Record_state=Protect_state;
	 }

 	//////////////////////////////////////////////zgf  �ӳ�ŵ翪ʼ ///////////////////////////////////////////	
  
	if ( WriteRecord & BV_L(crtKeyPowerOn_e) )
	{
		WriteRecord &= BVN_L(crtKeyPowerOn_e);
		EepromRecordWrite(rtKeyPowerOn_e);
	}
	
	if ( WriteRecord & BV_L(crtChargerPowerOn_e) )
	{
		WriteRecord &= BVN_L(crtChargerPowerOn_e);
		 // ���� ���� ���ϴ� �ػ�ʱ�� ���  ��� ����30���ӣ�SOC ����5% �������
 
		 //  �ڴ濪�� ֮ǰ ������ ��� û�йػ� ��¼��������
		 
		
		TwiDeal( EEPROM_ID, TWI_DEAL_READ, RcdOutlineTemp.Outline.CurRecordAddr, sizeof(RecordVarCheck), (U8  *)&RecordVarCheck, justReadRecord_zgf );
		if( restult_read03==0)
		{ 
			if( 			RcdOutlineTemp.Outline.CurRecordAddr > E2PROM_PAGESIZE )
			RcdOutlineTemp.Outline.CurRecordAddr -=E2PROM_PAGESIZE;
			TwiDeal( EEPROM_ID, TWI_DEAL_READ, RcdOutlineTemp.Outline.CurRecordAddr, sizeof(RecordVarCheck), (U8  *)&RecordVarCheck, justReadRecord_zgf );
    }
		if( restult_read03==0)
		{ 
						if( 			RcdOutlineTemp.Outline.CurRecordAddr > E2PROM_PAGESIZE )
			RcdOutlineTemp.Outline.CurRecordAddr -=E2PROM_PAGESIZE;
			TwiDeal( EEPROM_ID, TWI_DEAL_READ, RcdOutlineTemp.Outline.CurRecordAddr, sizeof(RecordVarCheck), (U8  *)&RecordVarCheck, justReadRecord_zgf );
    }
		
		if( restult_read03)
		{ 
			restult_read03=0;
			temp=RtcTime.Month;
			temp=temp*30;
			temp=temp+RtcTime.Date;
			temp=temp*24;
			temp=temp+RtcTime.Hour;
			temp=temp*60;	
			temp=temp+RtcTime.Minute;
			temp=temp*60;		
			temp=temp+RtcTime.Second;
			temp2=RecordVarCheck.Rtc.Month;
			temp2=temp2*30;
			temp2=temp2+RecordVarCheck.Rtc.Date;
			temp2=temp2*24;
			temp2=temp2+RecordVarCheck.Rtc.Hour;
			temp2=temp2*60;	
			temp2=temp2+RecordVarCheck.Rtc.Minute;
			temp2=temp2*60;		
			temp2=temp2+RecordVarCheck.Rtc.Second;
			
			if(temp > (temp2 +1800 ))
			{
		 // PowerOn_UpdateSoc_flag=1;
			}
		}
		
		EepromRecordWrite(rtChargerPowerOn_e);
		
	}
	
	if ( WriteRecord & BV_L(crtPowerOff_e) )
	{
		WriteRecord &= BVN_L(crtPowerOff_e);
		EepromRecordWrite(rtPowerOff_e);
	}
	
	if ( WriteRecord & BV_L(crtEepromErase_e) )
	{
		WriteRecord &= BVN_L(crtEepromErase_e);
		EepromRecordWrite(rtEepromErase_e);
	}
 
	if ( re != reb )
	{
		if ( ((re & BV_L(crtSocfull_e)) != 0) && ((reb&BV_L(crtSocfull_e)) == 0) )// ���ϴ� reb ��¼��һ��ʱ
		{
			EepromRecordWrite(rtSocfull_e);
		}
		
		if ( ((re & BV_L(crtSocempty_e)) != 0) && ((reb & BV_L(crtSocempty_e)) == 0) )
		{
			EepromRecordWrite(rtSocempty_e);
		}
		
		if ( ((re&BV_L(crtOv_e)) != 0) && ((reb&BV_L(crtOv_e)) == 0) )
		{
			EepromRecordWrite(rtOv_e);
		}
		else if ( ((re&BV_L(crtOv_e)) == 0) && ((reb&BV_L(crtOv_e)) != 0) )
		{
			EepromRecordWrite(rtOvr_e);
		}
		
		if ( ((re&BV_L(crtUv_e)) != 0) && ((reb&BV_L(crtUv_e)) == 0) )
		{
			EepromRecordWrite(rtUv_e);
		}
		else if ( ((re&BV_L(crtUv_e)) == 0) && ((reb&BV_L(crtUv_e)) != 0) )
		{
			EepromRecordWrite(rtUvr_e);
		}
		
		if ( ((re&BV_L(crtScd_e)) != 0) && ((reb&BV_L(crtScd_e)) == 0) )
		{
			EepromRecordWrite(rtScd_e);
		}
		else if ( ((re&BV_L(crtScd_e)) == 0) && ((reb&BV_L(crtScd_e)) != 0) )
		{
			EepromRecordWrite(rtScdr_e);
		}
		
		if ( ((re&BV_L(crtOcc_e)) != 0) && ((reb&BV_L(crtOcc_e)) == 0) )
		{
			EepromRecordWrite(rtOcc_e);
		}
		else if ( ((re&BV_L(crtOcc_e)) == 0) && ((reb&BV_L(crtOcc_e)) != 0) )
		{
			EepromRecordWrite(rtOccr_e);
		}
	
		if ( ((re&BV_L(crtOcd2_e)) != 0) && ((reb&BV_L(crtOcd2_e)) == 0) )
		{
			EepromRecordWrite(rtOcd2_e);
		}
		else if ( ((re&BV_L(crtOcd2_e)) == 0) && ((reb&BV_L(crtOcd2_e)) != 0) )
		{
			EepromRecordWrite(rtOcdr2_e);
		}
		
		if ( ((re&BV_L(crtOcd1_e)) != 0) && ((reb&BV_L(crtOcd1_e)) == 0) )
		{
			EepromRecordWrite(rtOcd1_e);
		}
		else if ( ((re&BV_L(crtOcd1_e)) == 0) && ((reb&BV_L(crtOcd1_e)) != 0) )
		{
			EepromRecordWrite(rtOcdr1_e);
		}
	
		if ( ((re&BV_L(crtOtc_e)) != 0) && ((reb&BV_L(crtOtc_e)) == 0) )
		{
			EepromRecordWrite(rtOtc_e);
		}
		else if ( ((re&BV_L(crtOtc_e)) == 0) && ((reb&BV_L(crtOtc_e)) != 0) )
		{
			EepromRecordWrite(rtOtcr_e);
		}
		
		if ( ((re&BV_L(crtOtd_e)) != 0) && ((reb&BV_L(crtOtc_e)) == 0) )
		{
			EepromRecordWrite(rtOtd_e);
		}
		else if ( ((re&BV_L(crtOtd_e)) == 0) && ((reb&BV_L(crtOtd_e)) != 0) )
		{
			EepromRecordWrite(rtOtdr_e);
		}
		
		if ( ((re&BV_L(crtUtc_e)) != 0) && ((reb&BV_L(crtUtc_e)) == 0) )
		{
			EepromRecordWrite(rtUtc_e);
		}
		else if ( ((re&BV_L(crtUtc_e)) == 0) && ((reb&BV_L(crtUtc_e)) != 0) )
		{
			EepromRecordWrite(rtUtcr_e);
		}
		
		if ( ((re&BV_L(crtUtd_e)) != 0) && ((reb&BV_L(crtUtd_e)) == 0) )
		{
			EepromRecordWrite(rtUtd_e);
		}
		else if ( ((re&BV_L(crtUtd_e)) == 0) && ((reb&BV_L(crtUtd_e)) != 0) )
		{
			EepromRecordWrite(rtUtdr_e);
		}
		
		if ( ((re&BV_L(crtPf_e)) != 0) && ((reb&BV_L(crtPf_e)) == 0) )
		{
			EepromRecordWrite(rtPf_e);
		}
		
		if ( ((re&BV_L(crtOpt_e)) != 0) && ((reb&BV_L(crtOpt_e)) == 0) )
		{
			EepromRecordWrite(rtOpt_e);
		}
		else if ( ((re&BV_L(crtOpt_e)) == 0) && ((reb&BV_L(crtOpt_e)) != 0) )
		{
			EepromRecordWrite(rtOptr_e);
		}
		reb = re;
	}
}
 