
#include "Include.h"
 
static tdsIapSoc   Iapsoc;
U8 learn_gas_2hour;//��Сʱ�ڲ����ظ�ѧϰ
U16  GetCheckSum(U8* pKval, U16 len)
{
	U16  result;
	result = 0;
	while( len )
	{
		result += *pKval;
		pKval += 1;
		len--;
	}
	return result;
}
 

void SaveToIap ( U16  addr, U8 *pDat, U16  len )
{
	U16  i;
	U16  temp[200];
	for(i=0;i<len ;i++)
	{
		if(i%2 ==0)
		{
		  temp[i/2]=*pDat <<8;
		}
		if(i%2 ==1)
		{
		  temp[i/2]=temp[i/2]+*pDat   ;
		}
		pDat++;
	}
 STMFLASH_Write(STM32FLASH_1024_ADDR+addr ,temp,len/2)	;  // ���� ֻ��д�� ���ֽ�
}
 void GetFromIap( U16  addr,U16  len, U8 *pBuf )
{
  U16  i,res=0;
	 	 
	for(i=0;i<len ;i++)
	{
		if(i%2 ==0)
		{
			res= STMFLASH_ReadHalfWord(STM32FLASH_1024_ADDR+ addr + i) ;	//��ȡ2���ֽ�. ��ַ������ 2��
		  *pBuf = (res>>8);
		}
		if(i%2 ==1)
		{
		   *pBuf =  (U8)res ;
		}
		pBuf++;
	}
}

/*
  У׼�������� ��ʼ��
*/
extern U16  	 	SOC_OCV[22*6+2];  //��ֹ30���Ӻ�����

U8 SaveSystemAndOffsetToIap ( void )
{
	tdsSystemConfig2  syscfg;
	U16   checksum_syscfg;
	tdsOffset  offset_tmp;
	U16   checksum_offset;
	U16   checksum_OCV;
	I16   soc_occcv[22*6+2];
	U8    allcapacity[CAPCA_NOS];
	U16   checksum;
	// IapPageErase( SystemAndOffset_IAP_ADDR );
	
	//����У׼����
	Offset_K.CheckSum = GetCheckSum( (U8 *)&Offset_K.Kval, sizeof(Offset_K.Kval) );
	SaveToIap(OFFSET_K_ADDR, (U8 *)&Offset_K, sizeof(Offset_K) );
	
	GetFromIap( OFFSET_K_ADDR, sizeof(offset_tmp), (U8 *) &offset_tmp );
	checksum_offset = GetCheckSum( (U8*) &offset_tmp.Kval, sizeof(offset_tmp.Kval) );

	//����ϵͳ����
	SystemConfig2.CheckSum = GetCheckSum( (U8 *)&SystemConfig2.val, sizeof(SystemConfig2.val) );
	SaveToIap(SYSTEMCONFIG_ADDR, (U8 *)&SystemConfig2, sizeof(SystemConfig2));

	GetFromIap(SYSTEMCONFIG_ADDR, sizeof(syscfg), (U8 *)&syscfg);
	checksum_syscfg = GetCheckSum( (U8 *)&syscfg.val, sizeof(syscfg.val));
	
	if((checksum_offset==Offset_K.CheckSum)&&(checksum_syscfg == syscfg.CheckSum))
	{
		
	}
	else
	{
		return 0;
	}
	
	
	//����SOV����
	checksum_OCV = GetCheckSum( (U8*) &SOC_OCV, sizeof(SOC_OCV)-4 );
	SOC_OCV[22*6+0]=checksum_OCV;
	SOC_OCV[22*6+1]=checksum_OCV;
	SaveToIap(SOC_SOV_ADDR, (U8 *) &SOC_OCV, sizeof(SOC_OCV));
	
	MemorySet((U8*) &soc_occcv , 0, sizeof(SOC_OCV) );
	GetFromIap( SOC_SOV_ADDR, sizeof(soc_occcv),  (U8*) &soc_occcv);
	checksum_OCV = GetCheckSum( (U8*) &soc_occcv, sizeof(soc_occcv)-4 );
	if ( ( soc_occcv[22*6+1] == checksum_OCV ) && ( soc_occcv[22*6+1] != 0 ) && ( soc_occcv[22*6+1] != 0xff ) )
	{
	}
	else
	{
		return 0;	
	}
	

	// ����  �¶� SOC ��ѹ ʱ������ allcapacity

	checksum = GetCheckSum( (U8*) &TempSocVolt_capacity, sizeof(TempSocVolt_capacity));
	MemoryCopy( (U8 *)&allcapacity,  (U8*)&TempSocVolt_capacity, sizeof(TempSocVolt_capacity));
	allcapacity[CAPCA_NOS-4]=checksum/256;
	allcapacity[CAPCA_NOS-3]=checksum%256;
	allcapacity[CAPCA_NOS-2] = 0x5A;
	allcapacity[CAPCA_NOS-1] = 0x5B;
	SaveToIap(CAPAPITY_ADDR, (U8 *) &allcapacity, sizeof(allcapacity));

	MemorySet((U8*) &allcapacity , 0, sizeof(allcapacity) );
	GetFromIap( CAPAPITY_ADDR, sizeof(allcapacity),  (U8*) &allcapacity);
	checksum = GetCheckSum( (U8*) &allcapacity, sizeof(allcapacity)-4 );	
	if ( 	(allcapacity[CAPCA_NOS-4] == (U8)(checksum/256)) 
		&& 	(allcapacity[CAPCA_NOS-3] == (U8)(checksum%256))  
		&&	(allcapacity[CAPCA_NOS-2] == 0X5A ) 
		&& 	(allcapacity[CAPCA_NOS-1] == 0x5B ) )
	{
		
	}
	else
	{
		return 0;	
	}
	
	return 1;	
}


U8 Savev82SystemToIap ( void )
{
	V82system_COMM  V82system_tmp;
	U16   checksum;
	
	V82system.CheckSum = GetCheckSum( (U8 *)&V82system, sizeof(V82system_tmp ) -2);
	SaveToIap(V82SYSCONFIG_ADDR, (U8 *) &V82system, sizeof(V82system_tmp));

	GetFromIap( V82SYSCONFIG_ADDR, sizeof(V82system_tmp), (U8 *) &V82system_tmp );
	checksum = GetCheckSum( (U8*) &V82system_tmp, sizeof(V82system_tmp)-2 );
	if (checksum == V82system_tmp.CheckSum) 
	{
		return 1;
	}
	return 0;	
}

/*
    
  Iap����  ����

*/
U8 SaveSocToIap ( void ) //  ��һ�� 2021.9.25  ֮ǰ���� BUG  ��δ
{
		if(PackInfo.FCC !=0)
		{
			Iapsoc.val.IFCC =  PackInfo.FCC;
			Iapsoc.val.IRC = PackInfo.RC;
			Iapsoc.val.IRSOC = PackInfo.RSOC;
			Iapsoc.val.ICYCLECOUNT = PackInfo.CycleCount;
			Iapsoc.val.IDsgCycleCount = DsgCycleCount;
			Iapsoc.val.IFCCCount = FCCCount;
			Iapsoc.val.IVdq = VDQ_p;
			Iapsoc.val.Have_gas_Learnflag = learn_gas_2hour;
			Iapsoc.val.ISOH = PackInfo.SOH;
			Iapsoc.CheckSum = GetCheckSum( (U8 *)&Iapsoc.val, sizeof(Iapsoc.val) );
			SaveToIap( SOC_IAP_ADDR, (U8 *)&Iapsoc, sizeof(Iapsoc) );
			GetFromIap( SOC_IAP_ADDR, sizeof(Iapsoc), (U8 *)&Iapsoc );
			if ( Iapsoc.CheckSum == ( GetCheckSum((U8 *)&Iapsoc.val,sizeof(Iapsoc.val) ) ) )
			{
				return 1;
			}
			else
			{
			}
		}
	return 0;	
}
/*
    
  Iap����  ��ȡ

*/
void GetSocFromIap ( void )
{
 
	PackInfo.FCC = 0;
	PackInfo.RC = 0;
	PackInfo.RSOC = 0;
	PackInfo.CycleCount = 0;
	DsgCycleCount = 0;
	FCCCount = 0;
	
	GetFromIap( SOC_IAP_ADDR, sizeof(Iapsoc), (U8 *)&Iapsoc.val );
	if ( Iapsoc.CheckSum == ( GetCheckSum((U8 *)&Iapsoc.val,sizeof(Iapsoc.val) ) ) )
	{
		PackInfo.FCC = Iapsoc.val.IFCC;
		PackInfo.RC = Iapsoc.val.IRC;
		PackInfo.RSOC = Iapsoc.val.IRSOC;
		PackInfo.CycleCount = Iapsoc.val.ICYCLECOUNT;
		DsgCycleCount = Iapsoc.val.IDsgCycleCount;
		FCCCount = Iapsoc.val.IFCCCount;
		VDQ_p = Iapsoc.val.IVdq;
		learn_gas_2hour = Iapsoc.val.Have_gas_Learnflag;
		PackInfo.SOH = Iapsoc.val.ISOH;
	}
 
}

