

#include "include.h"


U8 GetCheckSum_Byte(U8*pKval, U8 len)
{
	U8 result;
	result = 0;
	while( len )
	{
		result += *pKval;
		pKval += 1;
		len--;
	}
	return result;
}
/*******************************************************************************
Function: MemoryCopy()
Description:
Input:	source--ԴMemoryָ��
		target---Ŀ��Memoryָ��
		length---��Ҫ���������ݳ���(Byres)
Output: 
Others:
*******************************************************************************/
void MemoryCopy(U8   *target, U8   *source, U16 length)
{
	U16 i;
	for(i=0; i<length; i++)
	{
		*target = *source;
		target++;
		source++;
	}
}

/*******************************************************************************
Function: MemoryCmp()
Description:
Input:	source--ԴMemoryָ��
		target---Ŀ��Memoryָ��
		length---��Ҫ �Ƚϵ����ݳ���(Byres)
Output: 
Others:
*******************************************************************************/
U8   MemoryCmp(U8   *source, U8   *target, U16 length)
{
	U8 i,res=0;
	
	for(i=0; i<length; i++)
	{
	 if(*target  != *source)	
	 {
		 res=1;
	   break;
	 }		 
		target++;
		source++; 
	}
return res;
}
 			
/*******************************************************************************
Function: MemorySet()
Description:
Input:	pt--memoryָ��
		setval---��Ҫ��ֵ������
		length---��Ҫ��ֵ��memory����(Byres)
Output: 
Others:
*******************************************************************************/
void MemorySet(U8   *pt, U8 setval, U16 length)
{
	U16 i;
	for(i=0; i<length; i++)
	{
		*pt = setval;
		pt++;
	}
}


U8 V82_CalibCurrent(U8 *pp)
{
	I16 exCurrent;
	U8  ress;
	if( pp[0]==1 )		//�ŵ����kֵУ׼ 
	{
		exCurrent = (pp[2] << 8) | \
		(pp[1]);
		Calibrate_Current( exCurrent );
		
		if ( SaveSystemAndOffsetToIap() )
		{
			ress=1;
		 
		}
		else
		{
				ress=0;
		}	
	}
	else if( pp[0]==2)
	{
 
		Calibrate_CurrentZero( 0 );
		
		if ( SaveSystemAndOffsetToIap() )
		{
			ress=1;
		 
		}
		else
		{
				ress=0;
		}	
	}
	else 	ress=0;;
	
	return ress;
}

 



