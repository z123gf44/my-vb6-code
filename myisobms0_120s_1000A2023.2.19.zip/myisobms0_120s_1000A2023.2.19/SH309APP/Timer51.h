#ifndef __TIMER_H__
#define __TIMER_H__
#include "C51_TYPE.h"
typedef volatile struct
{
	struct 
	{
		U8 ms_1		:1;
		U8 ms_10		:1;
		U8 ms_50		:1;
		U8 ms_300		:1;
		U8 ms_500		:1;
		U8 ms_1000		:1;
	}flag;
	struct
	{
		U8 ms_10;		 
		U8 ms_50;
		U16 ms_300;
		U16 ms_500;
		U16 ms_1000;
	}cnt;	
}tdsTimerBuf;

extern tdsTimerBuf  TimerBuf;

void timer_1msinit(void);

 
void Timer0Process( void );

void NoComTimeAcc ( void );		//50ms event
void NoCurrentTimeAcc ( void );	//1000ms event

extern U32   AdcAd_Temp[6];
extern U16   AdcAdAcc_Temp[6];
extern void  just_call_bluname(void);
#endif
