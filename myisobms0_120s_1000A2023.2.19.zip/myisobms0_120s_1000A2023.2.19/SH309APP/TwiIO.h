#ifndef	_TWI_IO_H
#define	_TWI_IO_H
#include "C51_TYPE.H" 
  #include "io.h"

#define AFE_ID		0x34
#define E2PROM_ID	0xA0
  

//IO��������
//#define SDA_IN()  {GPIOB->CRL&=0X0FFFFFFF;GPIOB->CRH|= ((unsigned int)8<<28);}
//#define SDA_OUT() {GPIOB->CRL&=0X0FFFFFFF;GPIOB->CRH|= ((unsigned int)3<<28);}

#define SDA_IN()   GPIO_SetPinDir(GPIO_PTA2, GPIO_Direction_Input)
#define SDA_OUT()  GPIO_SetPinDir(GPIO_PTA2, GPIO_Direction_Output)

#define SCL_IN()  GPIO_SetPinDir(GPIO_PTA3, GPIO_Direction_Input)
#define SCL_OUT() GPIO_SetPinDir(GPIO_PTA3, GPIO_Direction_Output)

//#define SCL_IN()  {GPIOB->CRL&=0XF0FFFFFF;GPIOB->CRH|=0X08000000;}
//#define SCL_OUT() {GPIOB->CRL&=0XF0FFFFFF;GPIOB->CRH|=0X03000000;}

#define READ_SCL        GPIO_ReadPin(GPIO_PTA3) //���̵��� 
#define READ_SDA        GPIO_ReadPin(GPIO_PTA2) //���̵���
//IIC���в�������
#define IIC_SDAH        (GPIO_SetPin(GPIO_PTA2))  //���̵���
#define IIC_SDAL        (GPIO_ClrPin(GPIO_PTA2)) 	
#define IIC_SCLH        (GPIO_SetPin(GPIO_PTA3))  //���̵���
#define IIC_SCLL        (GPIO_ClrPin(GPIO_PTA3)) 	
 
U8 TwiRead(U8 SlaveID, U16    RdAddr, U8 Length, U8    *RdBuf);
U8 TwiWrite(U8 SlaveID, U16    WrAddr, U8 Length, U8    *WrBuf);
U8 CRC8cal(U8 *p, U8 counter);
typedef enum
{
	TWI_IDLE = 0,
	TWI_BUSY = 1,
}tdeTwiBusyState;

typedef enum
{
	TWI_DEAL_WRITE = 0,
	TWI_DEAL_READ = 1,
}tdeTwiRwState;

typedef enum
{
	TWI_RW_WORKING = 0,
	TWI_RW_SUCCESS = 1,
	TWI_RW_FAIL = 2,
}tdeTwiWorkState;
typedef volatile struct
{
	struct
	{
		tdeTwiBusyState busy		:1;		//0=??,1=???
		tdeTwiRwState rw			:1;		//0=?????,1=?????
		tdeTwiWorkState state		:2;		//00=???,01=????,02=????
		 U8  reserved	:4;		
	}status;
 void (*Result)();				//???????????
}tdsTwiRw ;
extern tdsTwiRw TwiRwBuf_pOut;
#endif
