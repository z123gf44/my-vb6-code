


#ifndef __GASGAUGE_H__
#define __GASGAUGE_H__
#include "C51_TYPE.h"
void InitGasGauge(void);
void GaugeManage(void);
void SOC_OCV_calibration(void);	
#ifndef	_GLOBAL_GASGAUGE_
	extern U32    DsgCycleCount;			//Discharge capacity statistics, for update CycleCount
	extern U32    FCCCount;				//The effective discharge capacity statistics, for updating FCC
	extern U8 PowerOn_UpdateSoc_flag;
	extern U8 CellVolt_UpdateSoc_flag;
#endif

#endif
