

#ifndef __CALIBRATE_H__
#define __CALIBRATE_H__
#include "C51_TYPE.h"

typedef union
{
	 struct
	 {
		 U16  cellvol		:1;
		 U16  packvol		:1;
		 U16  temp1			:1;
		 U16  temp2			:1;
		 U16  temp3			:1;
		 U16  temp4			:1;
		 U16  temp5			:1;
		 U16  temp6			:1;
		 U16  temp7			:1;
		 U16  temp8			:1;
		 U16  temp9			:1;
		 U16  current		:1;
		 U16  currentzero	:1;
		 U16  rtc			:1;
		 U16  Reserved2bit	:2;
	 }unit;
	 U16  word;
}tduCalibbit;

typedef struct
{
	struct _tag_k
	{
		I16 		CurrentZero;
		I16 		Current;	
	} Kval;
	U16 	CheckSum;		//У��ͣ�������֤
}tdsOffset;

#ifndef _GLOBAL_CALIBRATE_
	extern tdsOffset   Offset_K;
	extern tdsOffset const Offset_k_default;
#endif
void IAP_upgrade(void);
void Offset_K_Init ( void );
void V82_SYSCONFIG_Init ( void );
void SOC_OCV_ROM_Init ( void );
//U8 SaveOffsetToIap ( void );
void Calibrate_PackVol ( U32 ExPackVolVal );
void Calibrate_CellVol ( U16  ExCellVolVal );
void Calibrate_Current ( I16  exCurrent );
void Calibrate_CurrentZero ( I16  exCurrentZero );
void Calibrate_temperature ( I16  exTemp, U8 num );
void UpdateCalStatus ( void );

#endif
