#ifndef __UPSUART_H
#define __UPSUART_H
#include "C51_TYPE.h"

//  1	1	1	1	1	2	LENID/2	 2	1
// SOI	VER	ADR	CID1 	CID2	LENGTH	INFO	CHKSUM	EOI



typedef volatile union
{
	U16 LENGTH;
	struct {
				
				U16 LENID:12;
				U16 LLCSUM:4;
			}towbyte;
}stLENGTH;

void  get_ups_uart(U8 RecvData);
void ups_handle(void);
void sent_ups_uart( void); 
void sc_cns_add(void);

void  set_poweron(void);
void  set_poweroff(void);
void  key_power(void);

#endif
