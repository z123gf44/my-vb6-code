#include "Com.h"
#include "IAP_ISP.h"
#include "System.h"
 
U8 TempSocVolt_capacity[4*27];
extern U16  Protect_state;		
extern V82Realdata_COMM     V82Realdata;
/*
U8 Temp_capacity[4*10];
U8 Soc_capacity[4*6];
U8 Volt_capacity[4*7];

U8 const Temp_FLASH_capacity[] =                        
{  //-20+40��                                70
		20,		30,		40,		50,		60,		70,		80,		90,		100,		110,
		100,	100,	100,	100,	100,	100,	100,	100,	000,		000,
		000,	20,		40,		100,	100,	100,	80,		20,		000,		000,
		000,	30,		50,		80,		100,	100,	80,		40,		20,			000,	
}
U8 const Soc_FLASH_capacity[] =                        
{  //                        
		10,		20,		40,		60,		80,		90,		
		80,		100,	100,	100,	100,	100,	
		20,		80,		100,	100,	80,		20,
		20,		50,		80,		100,	100,	100,		
}
U8 const Volt_FLASH_capacity[] =                        
{  //2.70v/2,                              
		130		140,	145,		155,		165,		175,		185,	
		80,		90,		100,		100,		100,		100,		000,	
		10,		30,		100,		100,		100,		50,			000,	
		10,		30,		80,			100,		100,		100,		80,		
}
*/
U8 const ALL_FLASH_capacity[] =
{ 
 0,56,10,20,
 20,102,0,0,
 30,102,20,60,
 40,102,40,100,
 50,100,100,100,
 60,100,100,100,
 70,100,100,100,
 80,100,90,100,
 90,100,40,80,
 100,98,0,50,
 160,98,0,0,
 10,3,3,3,
 20,3,3,3,
 40,3,3,3,
 60,3,3,3,
 80,3,3,3,
 90,3,3,3,
 120,3,3,3,
 135,100,20,10,
 140,100,30,100,
 145,100,100,100,
 155,100,100,100,
 165,100,100,100,
 175,100,50,100,
 178,100,20,100,
 185,0,0,100,
 250,0,0,100,
};

				 
void CAPCAITY_ROM_Init ( void )
{
	U8    allcapacity[CAPCA_NOS];
	U16   checksum;
	
	MemorySet((U8*) &allcapacity , 0, sizeof(allcapacity) );
	GetFromIap( CAPAPITY_ADDR, sizeof(allcapacity),  (U8*) &allcapacity);
	checksum = GetCheckSum( (U8*) &allcapacity, sizeof(allcapacity)-4 );	
	if ( (allcapacity[CAPCA_NOS-4] == (U8)(checksum/256)) 
		&& 	(allcapacity[CAPCA_NOS-3] == (U8)(checksum%256))  
		&&	(allcapacity[CAPCA_NOS-2] == 0X5A ) 
		&& 	(allcapacity[CAPCA_NOS-1] == 0x5B ))
	{
		MemoryCopy( (U8 *)&TempSocVolt_capacity, (U8*) &allcapacity, sizeof(TempSocVolt_capacity) );
	}
	else
	{
		checksum = GetCheckSum( (U8*) &ALL_FLASH_capacity, sizeof(ALL_FLASH_capacity));
		MemoryCopy( (U8 *)&allcapacity,  (U8*)&ALL_FLASH_capacity, sizeof(ALL_FLASH_capacity));
		MemoryCopy( (U8 *)&TempSocVolt_capacity,  (U8*)&ALL_FLASH_capacity, sizeof(TempSocVolt_capacity));
		allcapacity[CAPCA_NOS-4]=checksum/256;
		allcapacity[CAPCA_NOS-3]=checksum%256;
		allcapacity[CAPCA_NOS-2] = 0x5A;
		allcapacity[CAPCA_NOS-1] = 0x5B;
		SaveToIap(CAPAPITY_ADDR, (U8 *) &allcapacity, sizeof(allcapacity));
	}
}

/*��߳���ѹmaxIV=58.4V	
���������maxIA=24A	
�ŵ��������maxOA=83A

#define Request_MAXIV  5840
#define Request_MAXIA  2400
#define Request_MAXOA  8300
*/


void Capcaity_Calcu ( U16 *maxiv,U16 *maxia,U16 *maxoa,U8 *charge_onoffbit,U8 *discharge_onoffbit )
{
	U8  i;
	U16 SSSS=0;
	static U8 OV_prohibit = 0,UV_prohibit = 0; // �澯���ֹ��/�ŵ�  ֱ�� �зŵ� �г��
	static U8 ch_second  ; // �澯���ֹ��/�ŵ�  ֱ�� �зŵ� �г��
	U16 rq_maxiv = 200;
	U16 rq_maxia = 200;
	U16 rq_maxoa = 200;
	U16 tempdata;
	U16 tempiv,tempia,tempoa;
	I16 itempdata1,itempdata2;
	*charge_onoffbit = 0;
	*discharge_onoffbit = 0;

	for(i=0;i<10;i++)
	{
		if( PackInfo.MinCellTemp <= TempSocVolt_capacity[4*(i)+4])
		{	SSSS+=i;
			if(i==0)
			{
				tempiv = TempSocVolt_capacity[4*(i)+5];
				tempia = TempSocVolt_capacity[4*(i)+6];
				tempoa = TempSocVolt_capacity[4*(i)+7];
			}
			else
			{
				if( TempSocVolt_capacity[4*(i)+4] != TempSocVolt_capacity[4*(i-1)+4])
				{
					itempdata1 = TempSocVolt_capacity[4*(i)+4] ;
					itempdata1 = itempdata1- TempSocVolt_capacity[4*(i-1)+4];
					itempdata2 = PackInfo.MinCellTemp; 
					itempdata2 = itempdata2- TempSocVolt_capacity[4*(i-1)+4];
					itempdata2= itempdata2*100/itempdata1;  //�ܱ仯 ��/100
					
					itempdata1 = TempSocVolt_capacity[4*(i)+5];
					itempdata1 = itempdata1 - TempSocVolt_capacity[4*(i-1)+5];
				    itempdata1 =itempdata1 *itempdata2 /100;
					tempiv = TempSocVolt_capacity[4*(i-1)+5] +itempdata1;
					
					itempdata1 = TempSocVolt_capacity[4*(i)+6];
					itempdata1 = itempdata1 - TempSocVolt_capacity[4*(i-1)+6];
					itempdata1 =itempdata1 *itempdata2 /100;
					tempia = TempSocVolt_capacity[4*(i-1)+6] +itempdata1;	
					
 					itempdata1 = TempSocVolt_capacity[4*(i)+7];
					itempdata1 = itempdata1 - TempSocVolt_capacity[4*(i-1)+7];
					itempdata1 =itempdata1 *itempdata2 /100;
					tempoa = TempSocVolt_capacity[4*(i-1)+7] +itempdata1;
				}
				else
				{
					tempiv = TempSocVolt_capacity[4*(i)+5];
					tempia = TempSocVolt_capacity[4*(i)+6];
					tempoa = TempSocVolt_capacity[4*(i)+7];
				}
			}
			if(rq_maxiv >tempiv)
			{
				rq_maxiv = tempiv;
			}
			if(rq_maxia >tempia)
			{
				rq_maxia = tempia;
			}	
			if(rq_maxoa >tempoa)
			{
				rq_maxoa = tempoa;
			}
			break ; 
		}
	}
	
	for(i=0;i<10;i++)
	{
		if( PackInfo.MaxCellTemp <= TempSocVolt_capacity[4*(i)+4])
		{	SSSS+=i*10;
			if(i==0)
			{
				tempiv = TempSocVolt_capacity[4*(i)+5];
				tempia = TempSocVolt_capacity[4*(i)+6];
				tempoa = TempSocVolt_capacity[4*(i)+7];
			}
			else
			{
				if( TempSocVolt_capacity[4*(i)+4] != TempSocVolt_capacity[4*(i-1)+4])
				{
					itempdata1 = TempSocVolt_capacity[4*(i)+4] ;
					itempdata1 = itempdata1- TempSocVolt_capacity[4*(i-1)+4];
					
					itempdata2 = PackInfo.MinCellTemp; 
					itempdata2 = itempdata2- TempSocVolt_capacity[4*(i-1)+4];
					itempdata2= itempdata2*100/itempdata1;  //�ܱ仯 ��/100
					
					itempdata1 = TempSocVolt_capacity[4*(i)+5];
					itempdata1 = itempdata1 - TempSocVolt_capacity[4*(i-1)+5];
				    itempdata1 =itempdata1 *itempdata2 /100;
					tempiv = TempSocVolt_capacity[4*(i-1)+5] +itempdata1;
					
					itempdata1 = TempSocVolt_capacity[4*(i)+6];
					itempdata1 = itempdata1 - TempSocVolt_capacity[4*(i-1)+6];
					itempdata1 =itempdata1 *itempdata2 /100;
					tempia = TempSocVolt_capacity[4*(i-1)+6] +itempdata1;	
					
 					itempdata1 = TempSocVolt_capacity[4*(i)+7];
					itempdata1 = itempdata1 - TempSocVolt_capacity[4*(i-1)+7];
					itempdata1 =itempdata1 *itempdata2 /100;
					tempoa = TempSocVolt_capacity[4*(i-1)+7] +itempdata1;
				}
				else
				{
					tempiv = TempSocVolt_capacity[4*(i)+5];
					tempia = TempSocVolt_capacity[4*(i)+6];
					tempoa = TempSocVolt_capacity[4*(i)+7];
				}
			}
			if(rq_maxiv >tempiv)
			{
				rq_maxiv = tempiv;
			}
			if(rq_maxia >tempia)
			{
				rq_maxia = tempia;
			}	
			if(rq_maxoa >tempoa)
			{
				rq_maxoa = tempoa;
			}
			break ; 
		}	
	}
 
	//ZGFFGrq_maxiv =15;
	/*
	temp_soc =PackInfo.RSOC/10;
	for(i=0;i<7;i++)
	{
		if( temp_soc <= TempSocVolt_capacity[0*27+10+i])
		{
			if(rq_maxiv >TempSocVolt_capacity[1*27+10+i])
			{
				rq_maxiv = TempSocVolt_capacity[1*27+10+i];
			}
			if(rq_maxiv >TempSocVolt_capacity[2*27+10+i])
			{
				rq_maxia = TempSocVolt_capacity[2*27+10+i];
			}	
			if(rq_maxiv >TempSocVolt_capacity[3*27+10+i])
			{
				rq_maxoa = TempSocVolt_capacity[3*27+10+i];
			}
			break ; 
		}
	} 
	*/
	for(i=0;i<9;i++)// �ŵ�����С��ѹ
	{ 
		tempdata = TempSocVolt_capacity[4*(i)+72];
		tempdata =tempdata*20;
		if( V82Realdata.NUM_VUV < tempdata)
		{	SSSS+=i*100;
			if(i==0)
			{
				tempoa = TempSocVolt_capacity[4*(i)+75];
			}
			else
			{
				if( TempSocVolt_capacity[4*(i)+72] != TempSocVolt_capacity[4*(i-1)+72])
				{
					itempdata1 = TempSocVolt_capacity[4*(i)+72] ;
					itempdata1 = itempdata1- TempSocVolt_capacity[4*(i-1)+72];
					itempdata2 = TempSocVolt_capacity[4*(i-1)+72];
					itempdata2 = itempdata2*20;
					itempdata2 = itempdata2 - V82Realdata.NUM_VUV ; 
					itempdata2 = -itempdata2;
					itempdata2= itempdata2*100/itempdata1/20;  //�ܱ仯 ��/100
						

 					itempdata1 = TempSocVolt_capacity[4*(i)+75];
					itempdata1 = itempdata1 - TempSocVolt_capacity[4*(i-1)+75];
					itempdata1 =itempdata1 *itempdata2 /100;
					tempoa = TempSocVolt_capacity[4*(i-1)+75] +itempdata1;
				}
				else
				{
					tempoa = TempSocVolt_capacity[4*(i)+75];
				}
			}
			if(rq_maxoa >tempoa)
			{
				rq_maxoa = tempoa;
			}
			break ; 
		}
	}
	
	for(i=0;i<9;i++)// ���������ѹ
	{
		tempdata = TempSocVolt_capacity[4*(i)+72];
		tempdata =tempdata*20;
		if( V82Realdata.NUM_VOV < tempdata )
		{ 
			SSSS+=i*1000;
			if(i==0)
			{
				tempiv = TempSocVolt_capacity[4*(i)+73];
				tempia = TempSocVolt_capacity[4*(i)+74];
			}
			else
			{
				if( TempSocVolt_capacity[4*(i)+72] != TempSocVolt_capacity[4*(i-1)+72])
				{
					itempdata1 = TempSocVolt_capacity[4*(i)+72] ;
					itempdata1 = itempdata1- TempSocVolt_capacity[4*(i-1)+72];
					
					
					itempdata2 = TempSocVolt_capacity[4*(i-1)+72];
					itempdata2 = itempdata2*20;
					itempdata2 = itempdata2 - V82Realdata.NUM_VOV ; 
					itempdata2 = -itempdata2;
					itempdata2= itempdata2*100/itempdata1/20;  //�ܱ仯 ��/100
					
					
					itempdata1 = TempSocVolt_capacity[4*(i)+73];
					itempdata1 = itempdata1 - TempSocVolt_capacity[4*(i-1)+73];
				    itempdata1 =itempdata1 *itempdata2 /100;
					tempiv = TempSocVolt_capacity[4*(i-1)+73] +itempdata1;
					
					itempdata1 = TempSocVolt_capacity[4*(i)+74];
					itempdata1 = itempdata1 - TempSocVolt_capacity[4*(i-1)+74];
					itempdata1 =itempdata1 *itempdata2 /100;
					tempia = TempSocVolt_capacity[4*(i-1)+74] +itempdata1;	
					
				}
				else
				{
					tempiv = TempSocVolt_capacity[4*(i)+73];
					tempia = TempSocVolt_capacity[4*(i)+74];
				}
			}
			if(rq_maxiv >tempiv)
			{
				rq_maxiv = tempiv;
			}
			if(rq_maxia >tempia)
			{
				rq_maxia = tempia;
			}	
			break ; 
		}
	}
 
 
	
	if( (PackInfo.RSOC <9000))
	{
		OV_prohibit =0;
	}
		
	if(FC_p)
	{
		OV_prohibit =1;
	}
	
//	if(PackInfo.RSOC == 1000)
//	{
//		OV_prohibit =1;
//	}
	*charge_onoffbit = OV_prohibit;
	
	if(CHGING)
	{
		if(ch_second++ > 6)
		{
			ch_second = 0;
			UV_prohibit =0;
		}
	}
	if(FD_p)//����Ƿѹ����ֵ
	{
		UV_prohibit =1;
	}

	
	*discharge_onoffbit = UV_prohibit;
	
	if((PackInfo.MaxCellTemp) >= V82system.W_Tcell_H)      // ��о���¾���ֵ60��
	{
		*charge_onoffbit = 1;
		*discharge_onoffbit = 1;	
	}
	if((PackInfo.MinCellTemp) < V82system.W_Tcell_L)      // ��о���¾���ֵ-18��
	{
		*charge_onoffbit = 1;
		*discharge_onoffbit = 1;		
	}
 	if((V82Realdata.heat_Temp) >= V82system.W_Tfet_H)      // ���ʸ��¾���ֵ80��	0.0	0.0	0.0	
	{
		*charge_onoffbit = 1;
		*discharge_onoffbit = 1;	
	}	
	if((V82Realdata.heat_Temp) < V82system.W_Tfet_L)      // ���ʵ��¾���ֵ-38��	0.0	0.0	0.0	
	{
		*charge_onoffbit = 1;
		*discharge_onoffbit = 1;		
	}	
	if(PackInfo.Current >=0)
	{
		if(PackInfo.Current >= ((U32)V82system.W_CURR_C*10)) //����������ֵ19A   
		{
			*charge_onoffbit = 1;	
		}
	}
	if(PackInfo.Current <0)
	{
		if((-PackInfo.Current )>= ( (U32)V82system.W_CURR_D*10)) //�ŵ������130A			0.0
		{
			*discharge_onoffbit = 1;	
		}
	}

	*maxiv =  (U32)rq_maxiv* TempSocVolt_capacity[1]/10;
	*maxia = (U32)rq_maxia*TempSocVolt_capacity[2]/10;
	*maxoa = (U32)rq_maxoa*TempSocVolt_capacity[3]/10;

}

