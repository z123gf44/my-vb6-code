

#ifndef XL8812_H
#define XL8812_H


#include "XL881x.h"

#define CELL 1
#define AUX 2
#define STAT 3

//! Initialize the Register limits
//!@return void
void XL8812_init_reg_limits(uint8_t total_ic, //!< Number of ICs in the system
							 cell_asic *ic //!< A two dimensional array that will store the data
							 );

//! Helper Function to initialize the CFGR data structures
//!@return void						 
void XL8812_init_cfg(uint8_t total_ic, //!< Number of ICs in the system
                      cell_asic *ic //!< A two dimensional array that will store the data
					  );

//! Helper function to set appropriate bits in CFGR register based on bit function
//!@return void
void XL8812_set_cfgr(uint8_t nIC, //!< Current IC
                      cell_asic *ic,//!< A two dimensional array that will store the data 
					  bool refon, //!< the REFON bit
					  bool adcopt, //!< the ADCOPT bit
					  bool gpio[5],//!< the GPIO bits
					  bool dcc[12],//!< the DCC bits 
					  bool dcto[4],//!< the Dcto bits 
					  uint16_t uv, //!< the UV value
					  uint16_t  ov //!< the OV value
					  );
					  
				  
//! Helper function to turn the refon bit HIGH or LOW
//!@return void
void XL8812_set_cfgr_refon(uint8_t nIC, //!< Current IC
                            cell_asic *ic, //!< a two dimensional array that will store the data
                            bool refon); //!< the REFON bit
							
							
//! Helper function to turn the ADCOPT bit HIGH or LOW
//!@return void
void XL8812_set_cfgr_adcopt(uint8_t nIC,  //!< Current IC
                             cell_asic *ic, //!< a two dimensional array that will store the data 
                             bool adcopt); //!< the ADCOPT bit
 							 
//! Helper function to turn the GPIO bits HIGH or LOW
//!@return void
void XL8812_set_cfgr_gpio(uint8_t nIC, //!< Current IC
                           cell_asic *ic, //!< a two dimensional array that will store the data 
                           bool gpio[]); //!< the GPIO bits

//! Helper function to turn the DCC bits HIGH or LOW
//!@return void
void XL8812_set_cfgr_dis(uint8_t nIC, //!< Current IC
                          cell_asic *ic, //!< a two dimensional array that will store the data 
                          bool dcc[]); //!< the DCC bits
						  
//! Helper function to set uv field in CFGRA register
//!@return void
void XL8812_set_cfgr_uv(uint8_t nIC, //!< Current IC
                         cell_asic *ic, //!< a two dimensional array that will store the data 
                         uint16_t uv);  //!< the UV value

//! Helper function to set ov field in CFGRA register
//!@return void
void XL8812_set_cfgr_ov(uint8_t nIC, //!< Current IC
                         cell_asic *ic, //!< a two dimensional array that will store the data 
                         uint16_t ov); //!< the OV value

//! Write the XL8812 configuration register
//!@return void
void XL8812_wrcfg(uint8_t nIC, //!< The number of ICs being written
                   cell_asic *ic //!<  a two dimensional array of the configuration data that will be written
                  );

//! Reads configuration registers of a XL8812 
//!@return int8_t, PEC Status.
//! 0: Data read back has matching PEC
//!-1: Data read back has incorrect PEC
int8_t XL8812_rdcfg(uint8_t nIC, //!<  number of ICs 
                     cell_asic *ic //!<  a two dimensional array that the function stores the read configuration data
                    );

//! Starts cell voltage conversion
//!@return void
void XL8812_adcv(uint8_t MD, //!< ADC Conversion Mode
                  uint8_t DCP, //!<  Controls if Discharge is permitted during conversion
                  uint8_t CH //!<  Sets which Cell channels are converted
                 );	

//! Reads and parses the XL8812 cell voltage registers.
//!@return int8_t, PEC Status.
//! 0: No PEC error detected
//!-1: PEC error detected, retry read
uint8_t XL8812_rdcv(uint8_t reg, //!<  controls which cell voltage register is read back.
                     uint8_t total_ic, //!<  the number of ICs in the daisy chain(-1 only)
                     cell_asic *ic //!<  array of the parsed cell codes from lowest to highest.
                    );	

//! Start a GPIO and Vref2 Conversion
//!@return void
void XL8812_adax(uint8_t MD, //!< ADC Conversion Mode
				  uint8_t CHG //!< Sets which GPIO channels are converted
				  );

//! Reads and parses the XL8812 auxiliary registers.
//!@return  int8_t, PEC Status
//!  0: No PEC error detected
//! -1: PEC error detected, retry read
int8_t XL8812_rdaux(uint8_t reg, //!< controls which GPIO voltage register is read back
                     uint8_t nIC,  //!<  the number of ICs in the daisy chain
                     cell_asic *ic //!<  A two dimensional array of the parsed gpio voltage codes
                    );

//! Start a Status ADC Conversion
//!@return void
void XL8812_adstat(uint8_t MD, //!<  ADC Conversion Mode
				    uint8_t CHST //!<  Sets which Stat channels are converted
				    );
					
//! Reads and parses the XL8812 stat registers.
//!@return  int8_t, PEC Status
//! 0: No PEC error detected
//!-1: PEC error detected, retry read
int8_t XL8812_rdstat(uint8_t reg, //!< Determines which Stat  register is read back.
                      uint8_t total_ic,//!< the number of ICs in the system
                      cell_asic *ic//!<  Array of the parsed cell codes
                     );


//! Starts cell voltage  and GPIO 1&2 conversion
//!@return void
void XL8812_adcvax(uint8_t MD, //!<  ADC Conversion Mode
				    uint8_t DCP //!<  Controls if Discharge is permitted during conversion
				   );

//! Starts cell voltage and SOC conversion
//!@return void
void XL8812_adcvsc(uint8_t MD, //!<  ADC Conversion Mode
				    uint8_t DCP //!<  Controls if Discharge is permitted during conversion
				   );				   
					
//! Starts the Mux Decoder diagnostic self test
//! Running this command will start the Mux Decoder Diagnostic Self Test.
//! This test takes roughly 1ms to complete. The MUXFAIL bit will be updated.
//! The bit will be set to 1 for a failure and 0 if the test has been passed.
//!@return void
void XL8812_diagn(void);

//! Starts cell voltage self test conversion
//!@return void
void XL8812_cvst( uint8_t MD, //!<  ADC Conversion Mode
				  uint8_t ST //!<  Self Test Mode
				 );

//! Start an Auxiliary Register Self Test Conversion
//!@return void
void XL8812_axst(uint8_t MD, //!<  ADC Conversion Mode
				  uint8_t ST //!<  Sets if self test 1 or 2 is run
				 );				 

//! Start a Status Register Self Test Conversion
//!@return void
void XL8812_statst(uint8_t MD, //!< ADC Conversion Mode
				    uint8_t ST //!<  Sets if self test 1 or 2 is run
				   );

//!  Helper function that runs the ADC Self Tests
//!@return int16_t, error
//! Number of errors detected.
int16_t XL8812_run_cell_adc_st(uint8_t adc_reg, //!<  Type of register
                                uint8_t total_ic, //!< Number of ICs in the system 
                                cell_asic *ic, //!< a two dimensional array that will store the 
								uint8_t md, //!< ADC Mode
								bool adcopt //!<  the adcopt bit in the configuration register
								);
								
//! Starts cell voltage overlap conversion
//!@return void
void XL8812_adol( uint8_t MD, //!<  ADC Conversion Mode
				  uint8_t DCP //!<  Discharge permitted during conversion
				  );								

//! Helper Function that runs the ADC Overlap test
//!@return uint16_t, error
//! 0: Pass
//!-1: False, Error detected
uint16_t XL8812_run_adc_overlap(uint8_t total_ic,//!< Number of ICs in the system  
                                 cell_asic *ic //!< a two dimensional array that will store the 
								 );

//! Start an open wire Conversion
//!@return void
void XL8812_adow(uint8_t MD, //!< ADC Mode
				  uint8_t PUP, //!< Discharge Permit
				  uint8_t CH, //!< Cell selection
				  uint8_t DCP //!< Discharge Permit  
				 );

//! Helper function that runs the data sheet open wire algorithm for single cell detection
//!@return void
void XL8812_run_openwire_single(uint8_t total_ic,//!< Number of ICs in the system  
						         cell_asic *ic , //!< a two dimensional array that will store the  
						         uint8_t  N_CHANNELS	
										 );
								
//! Helper function that runs open wire for multiple cell and two consecutive cells detection
//!@return void
void XL8812_run_openwire_multi(uint8_t total_ic,//!< Number of ICs in the system  
						        cell_asic *ic , //!< a two dimensional array that will store the  
						        uint8_t  N_CHANNELS
										);

//! Start an GPIO Redundancy test
//!@return void
void XL8812_adaxd(uint8_t MD, //!<  ADC Conversion Mode
				   uint8_t CHG //!< Sets which GPIO channels are converted
				  );

//! Start a Status register redundancy test Conversion
//!@return void
void XL8812_adstatd(uint8_t MD, //!<  ADC Mode
				     uint8_t CHST //!<  Sets which Status channels are converted
				    );

//! Helper function that runs the ADC Digital Redundancy commands and checks output for errors
//!@return int16_t, error
int16_t XL8812_run_adc_redundancy_st(uint8_t adc_mode, //!< ADC Mode
                                      uint8_t adc_reg,  //!<  Type of register
                                      uint8_t total_ic, //!< Number of ICs in the system
                                      cell_asic *ic    //!< a two dimensional array that will store the data
									  );				  
						 
//! Sends the poll ADC command
//!@returns uint8_t, 1 byte read back after a pladc command. If the byte is not 0xFF ADC conversion has completed 
uint8_t XL8812_pladc(void);


//! This function will block operation until the ADC has finished it's conversion
//! @returns uint32_t, the approximate time it took for the ADC function to complete. 
uint32_t XL8812_pollAdc(void);						 
	
//! Clears the XL8812 cell voltage registers
//!@return void
void XL8812_clrcell(void);

//! Clears the XL8812 Auxiliary registers
//!@return void
void XL8812_clraux(void);

//! Clears the XL8812 Stat registers
//!@return void
void XL8812_clrstat(void);

//! Write the XL8812 PWM register
//!@return void
void XL8812_wrpwm(uint8_t nIC, //!<  number of ICs 
                   uint8_t pwmReg, //!< Select register
                   cell_asic *ic//!< A two dimensional array that the function stores the data in.
                  );

//! Reads pwm registers of a XL8812 daisy chain
//!   @return int8_t, PEC Status.
//!  0: Data read back has matching PEC
//! -1: Data read back has incorrect PEC
int8_t XL8812_rdpwm(uint8_t nIC, //!<  number of ICs 
                     uint8_t pwmReg, //!< Select register
                     cell_asic *ic //!< a two dimensional array that the function stores the read pwm data
                    );

//! Write the XL8812 Sctrl register
//!@return void
void XL8812_wrsctrl(uint8_t nIC, //!<  number of ICs in the daisy chain
                     uint8_t sctrl_reg, //!< Select register
                     cell_asic *ic //!< A two dimensional array of the data that will be written
                    );


//! Reads sctrl registers of a XL8812 daisy chain
//!   @return int8_t, PEC Status.
//!  0: Data read back has matching PEC
//! -1: Data read back has incorrect PEC
int8_t XL8812_rdsctrl(uint8_t nIC, //!< number of ICs in the daisy chain
                       uint8_t sctrl_reg, //!< Select register
                       cell_asic *ic //!<  a two dimensional array that the function stores the read pwm data
                      );
					  
//! Start Sctrl data communication
//! This command will start the sctrl pulse communication over the spins
//!@return void
void XL8812_stsctrl(void);
					  
//! Clears the XL8812 Sctrl registers
//!@return void
void XL8812_clrsctrl(void);

//! Write the XL8812 COMM register
void XL8812_wrcomm(uint8_t total_ic, //!<  Number of ICs in the daisy chain
                    cell_asic *ic //!<  A two dimensional array of the comm data that will be written
                   );

//! Reads comm registers of a XL8812 daisy chain
//! @return int8_t, PEC Status.
//! 0: Data read back has matching PEC
//!-1: Data read back has incorrect PEC
int8_t XL8812_rdcomm(uint8_t total_ic, //!<  number of ICs in the daisy chain
                      cell_asic *ic //!<  Two dimensional array that the function stores the read comm data.
                     );

//! Issues a stcomm command and clocks data out of the COMM register 
//!@return void
void XL8812_stcomm(uint8_t len);

//! Helper function to set discharge bit in CFG register
//!@return void
void XL8812_set_discharge(int Cell, //!< The cell to be discharged
                           uint8_t total_ic, //!< number of ICs in the system
                           cell_asic *ic //!< a two dimensional array that will store the data
						   );

//! Clears all of the DCC bits in the configuration registers
//!@return void						 
void XL8812_clear_discharge(uint8_t total_ic, //!<  Number of ICs in the daisy chain
							 cell_asic *ic //!< a two dimensional array that will store the data
					        );

//! Looks up the result pattern for digital filter self test							
//! @returns returns the register data pattern for a given ADC MD and Self test
uint16_t XL8812_st_lookup(uint8_t MD, //!<  ADC Conversion Mode
						  uint8_t ST //!<  Self test number
						  );
						  
//!  Helper Function that counts overall PEC errors and register/IC PEC errors
//!@return void	
void XL8812_check_pec(uint8_t total_ic,//!< Number of ICs in the system  
                       uint8_t reg, //!<  Type of register
                       cell_asic *ic //!< a two dimensional array that will store the data
					   );

//!  Helper Function that resets the PEC error counters
//!@return void	
void XL8812_reset_crc_count(uint8_t total_ic, //!< Number of ICs in the system
                             cell_asic *ic //!< a two dimensional array that will store the data
							 );



#endif					 
