
/*
     SPI j�ӿ�������
*/
#include "XL881x_spidriver.h"
#include "xl_gpio.h"    



 
uint16_t  XL8820_CS_INDEX = DIR_B;

void Set_XL8812_DoubleDir(  uint16_t  DoubleDir)
{
    #if  EN_DOUBLE_DIR
           XL8820_CS_INDEX = DoubleDir;
		 #else
		       uint16_t  XL8820_CS_INDEX = DIR_B;
		 #endif
}

void mySPI_SetPackCS(SPI_Type *SPIx,SPI_PACKCSTypeDef SPI_PACKCSType)
{

				if(XL8820_CS_INDEX == DIR_A)
				{
					if(SPI_PACKCSType == SPI_PACK_CS_LOW)
						GPIO_ClrPin(GPIO_PTC6);
					else
						GPIO_SetPin(GPIO_PTC6); 		
				}
				else if(XL8820_CS_INDEX == DIR_B)
				{
					if(SPI_PACKCSType == SPI_PACK_CS_LOW)
						GPIO_ClrPin(GPIO_PTC7);
					else
						GPIO_SetPin(GPIO_PTC7);		
				}

				if(SPI_PACKCSType != SPI_PACK_CS_HIGHT )
					{
						/* SLAVE SPI */
						SPIx->MODE |= SPI_MODE_PACK_MASK;
					}
					else 
					{
						/* MASTER SPI */
						SPIx->MODE &= ~SPI_MODE_PACK_MASK;
					}	

}
void cs_low( void) 
{
    //
  mySPI_SetPackCS(SPI_COMM_PORT,SPI_PACK_CS_LOW);			//CS����

}

void cs_high(void)
{
   //
    mySPI_SetPackCS(SPI_COMM_PORT,SPI_PACK_CS_HIGHT);			//CS����
}

void delay_u(uint32_t micro)
{
   //
    Delay_us(micro);
}

void delay_m(uint32_t milli)
{
    //
     Delay_ms(milli);
}
 
/*
Writes an array of bytes out of the SPI port
*/
void spi_write_array(uint16_t len, // Option: Number of bytes to be written on the SPI port
                     uint8_t data[] //Array of bytes to be written on the SPI port
                    )
{
uint16_t i;

#if  EN_DOUBLE_DIR
					cs_low();
			delay_u(100); // 
				spi_read_byte(0xff);//Guarantees the isoSPI will be in ready mode
					cs_high();
					delay_u(1500); // Guarantees the XL881x will be in standby
		#endif	
		
		cs_low();
  for ( i= 0; i < len; i++)
  {
         SPIx_Comm_ReadWrite(SPI_COMM_PORT,(int8_t)data[i]);
  }
 cs_high();
	  #if  EN_DOUBLE_DIR
					delay_m(10); // Guarantees the XL881x will be in standby
		#endif	
}

/*
 Writes and read a set number of bytes using the SPI port.

*/

void spi_write_read(uint8_t tx_Data[],//array of data to be written on SPI port
                    uint8_t tx_len, //length of the tx data arry
                    uint8_t *rx_data,//Input: array that will store the data read by the SPI port
                    uint16_t rx_len //Option: number of bytes to be read from the SPI port
                   )
{
uint16_t i ;

#if  EN_DOUBLE_DIR
					cs_low();
				delay_u(100); // 
					spi_read_byte(0xff);//Guarantees the isoSPI will be in ready mode
					cs_high();
					delay_u(1500); // Guarantees the XL881x will be in standby
		#endif	
		
	cs_low();
			for (i= 0; i < tx_len; i++)
			{
							SPIx_Comm_ReadWrite(SPI_COMM_PORT,tx_Data[i]);
			}
			for ( i = 0; i < rx_len; i++)
			{
				rx_data[i] = (uint8_t)SPIx_Comm_ReadWrite(SPI_COMM_PORT,0xFF);
			}
	cs_high();
  #if  EN_DOUBLE_DIR
					delay_m(10); // Guarantees the XL881x will be in standby
		#endif	
}

uint8_t spi_read_byte(uint8_t tx_dat)
{
  uint8_t data;
cs_low();
        data = (uint8_t)SPIx_Comm_ReadWrite(SPI_COMM_PORT,0xFF);
 cs_high();
  return(data);
}

