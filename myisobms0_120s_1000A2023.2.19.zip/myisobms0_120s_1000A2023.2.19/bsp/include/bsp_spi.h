

/*================== Includes =============================================*/
#include "typedef.h"
#include "xl_spi.h"
#include "xl_sim.h"
#include "system_XL6600.h"
#include "xl_nvic.h"
 

/**
 * This structure contains variables relevant for the SPI driver.
 *
 */
typedef struct {
    uint8_t transmit_ongoing;         /*!< time in ms before the state machine processes the next state, e.g. in counts of 1ms    */
    uint8_t dummyByte_ongoing;        /*!< SPI dummy byte is currently transmitted */
    uint8_t counter;                  /*!< general purpose counter */
} SPI_STATE_s;

/*================== Constant and Variable Definitions ====================*/
#define MASTER_PCB_VERSION   2       
#define SPI_COMM_PORT   SPI0

/*================== Function Prototypes ==================================*/

/**
 * @brief  initializes the SPI module.
 *
 * This function initializes the SPI channels according to the configuration given as parameter.
 *
 * @param   *hspi      pointer to the spi configuration
 */
extern void SPIx_Init(uint32_t  baud_rate) ;

/**
 * @brief  callback SPI transmit and receive complete from SPI-Interrupt
 *
 * @param  hspi: pointer to SPI hardware handle
 */
//extern void HAL_SPI_TxRxCpltCallback(SPI_HandleType_s *hspi);
//
///**
// * @brief  callback SPI transmit complete from SPI-Interrupt
// *
// * @param  hspi:     pointer to SPI hardware handle
// */
//extern void HAL_SPI_TxCpltCallback(SPI_HandleType_s *hspi);

/**
 * @brief   transmits through SPI without receiving data.
 *
 * @param   *hspi       pointer to SPI hardware handle
 * @param   *pData      data to be sent
 * @param   Size        size of the data to be sent
 *
 * @return  E_OK if SPI transmission is OK, E_NOT_OK otherwise
 */
extern uint8_t SPIx_Transmit(SPI_Type *SPIx , uint8_t *pData, uint16_t Size);

/**
 * @brief   transmits and receives data through SPI.
 *
 * @param   *hspi         pointer to SPI hardware handle
 * @param   *pTxData      data to be sent
 * @param   *pRxData      data to be received
 * @param   Size          size of the data to be sent/received
 *
 * @return   E_OK if SPI transmission is OK, E_NOT_OK otherwise
 */
extern uint8_t SPIx_TransmitReceive(SPI_Type *SPIx, uint8_t *pTxData, uint8_t *pRxData, uint16_t Size);

/**
 * @brief sets Chip Select low to start SPI transmission.
 *
 * This function sets CS low in case CS is driven by software.
 *
 * @param   busID      selects which CS pin has to be set low
 */
extern void SPI_SetCS(uint8_t busID);

/**
 * @brief   sets Chip Select high to end SPI transmission.
 *
 * This function sets CS high in case CS is driven by software.
 * It is typically called in the callback routine of SPI transmission.
 *
 * @param   busID      selects which CS pin has to be set high
 */
extern void SPI_UnsetCS(uint8_t busID);


/**
 * @brief   gets the SPI transmit status.
 *
 * @return  retval  TRUE if transmission still ongoing, FALSE otherwise
 *
 */
extern uint8_t SPI_IsTransmitOngoing(void);


/**
 * @brief   sets the SPI transmit status.
 *
 */
extern void SPI_SetTransmitOngoing(void);


/**
 * @brief   clear the SPI transmit status.
 *
 */
extern void SPI_ClearTransmitOngoing(void);
uint8_t SPIx_Comm_ReadWrite(SPI_Type *SPIx,uint8_t data);
/*================== Function Implementations =============================*/



