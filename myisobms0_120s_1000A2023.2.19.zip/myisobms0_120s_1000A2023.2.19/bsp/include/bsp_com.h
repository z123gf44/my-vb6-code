
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>


#define TRUE    (1)
#define FALSE   (0)

/**
 * enum for standard return type
 */
typedef enum {
    E_OK        = 0,    /*!< ok     */
    E_NOT_OK    = 1     /*!< not ok */
} STD_RETURN_TYPE_e;



