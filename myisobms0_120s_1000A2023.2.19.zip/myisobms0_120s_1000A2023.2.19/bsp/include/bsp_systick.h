#include "xl6600.h"
#include "system_XL6600.h"

void Systick_Init(void);
void Delay_us(uint32_t nus);
void Delay_ms(uint32_t nms);
