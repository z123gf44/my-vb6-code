#include "xl6600.h"
#include "xl_uart.h"
#include "xl_nvic.h"
#include "xl_sim.h"
#include "system_xl6600.h"
 
typedef enum
{
    u_Ok,   ///< No error
    u_Error, ///< Non-specific error code
}en_result_t;

 
 
 en_result_t myUART_RecvByte(uint8_t *u8RxData);

void XL6600_UartDebug_Config(uint32_t baud_rate);

