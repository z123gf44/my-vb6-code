#include "bsp_com.h"
#include "bsp_spi.h"
#include "bsp_systick.h"
#include "xl_gpio.h"

/*================== Macros and Definitions ===============================*/

/*================== Constant and Variable Definitions ====================*/

/**
 * contains variables used by the SPI driver
 *
 */
static SPI_STATE_s spi_state = {
    .transmit_ongoing=FALSE,
    .dummyByte_ongoing=FALSE,
    .counter=0,
};

const uint8_t spi_cmdDummy[1]={0x00};

/*================== Function Prototypes ==================================*/
static void SPIx_BusClockEnable(SPI_Type *SPIx);
static void SPIx_Config(SPI_Type *SPIx,uint32_t baud_rate);
static void SPIx_Nvic_Cmd(SPI_Type *SPIx);

void SPI_Wait(void);
STD_RETURN_TYPE_e SPI_SendDummyByte(SPI_Type *SPIx,uint8_t Size);


/*================== Function Implementations =============================*/

/**
 * @brief SPIx_BusClockEnable
 * @param SPIx : SPI0/SPI1
 * @retval None
 */
static void SPIx_BusClockEnable(SPI_Type *SPIx) {
    if((SPIx!= SPI0)&&(SPIx!= SPI1))
	    return ;
    if(SPIx == SPI1)
    {
		SIM_SCGC_Cmd(SIM_SCGC_SPI1,ENABLE);
		SIM_PINSEL_SPI1(SPI1_PS_PTG4_PTG5_PTG6_PTG7);
    }
    else
    {
		SIM_SCGC_Cmd(SIM_SCGC_SPI0,ENABLE);
#if(MASTER_PCB_VERSION == 1)
		SIM_PINSEL_SPI0(SPI0_PS_PTB2_PTB3_PTB4_PTB5);
#elif(MASTER_PCB_VERSION == 2)
		SIM_PINSEL_SPI0(SPI0_PS_PTE0_PTE1_PTE2_PTE3);
#endif
    }
}

/**
 * @brief SPIx_BusClockEnable
 * @param SPIx : SPI0/SPI1
 * @retval None
 */
static void SPIx_Config(SPI_Type *SPIx,uint32_t  baud_rate){
    SPI_MsterInitTypeDef SPI_MasterStructure;
    if((SPIx!= SPI0)&&(SPIx!= SPI1))
	    return ;
    SPI_MasterStructure.SPI_SRL = SPI_SRL_NORMAL;
    SPI_MasterStructure.SPI_TMOD = SPI_TransmitAndReceive;
    SPI_MasterStructure.SPI_SCPOL = SPI_SCPOL_High;
    SPI_MasterStructure.SPI_SCPH =  SPI_SCPH_Start;
    SPI_MasterStructure.SPI_DFS = SPI_DataSize_8b;
    SPI_MasterStructure.SPI_SourceClk = Get_PeripheralClock();	
   SPI_MasterStructure.SPI_BAUDR = baud_rate;
    SPI_MasterStructure.SPI_NDF = 0;
    SPI_MasterStructure.SPI_RFT = 0;

    SPI_EnableCmd(SPIx, DISABLE);
    SPI_SetMode(SPIx, SPI_MODE_MASTER);
    SPI_SlaveEnableCmd(SPIx, ENABLE);
    SPI_MasterInit(SPIx, &SPI_MasterStructure);

    SPI_InterruptEn(SPIx, SPI_ReceiveFIFOUnderflowIT, DISABLE);
    SPI_InterruptEn(SPIx, SPI_ReceiveFIFOOverflowIT, DISABLE);
    SPI_InterruptEn(SPIx, SPI_TransmitFIFOOverflowIT, DISABLE);
    SPI_InterruptEn(SPIx, SPI_TransmitFIFOEmptyIT, DISABLE );
    SPI_InterruptEn(SPIx, SPI_ReceiveFIFOFullIT, DISABLE);
	  SPI_SetPackCS(SPIx,SPI_PACK_CS_HIGHT);
    SPI_EnableCmd(SPIx,ENABLE);
}

/**
 * @brief SPIÖÐ¶ÏÅäÖÃ
 * @retval None
 */
static void SPIx_Nvic_Cmd(SPI_Type *SPIx)
{
    NVIC_InitTypeDef NVIC_InitStructure;
    if(SPIx == SPI1)
    {
	    NVIC_InitStructure.NVIC_IRQChannel = SPI1_IRQn;
    }
    else
    {
	    NVIC_InitStructure.NVIC_IRQChannel = SPI0_IRQn;
    }
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=3 ;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

/**
 * @brief SPIx_Init
 * @param SPIx : SPI0/SPI1
 * @retval None
 */
void SPIx_Init(uint32_t  baud_rate) 
{
    SPIx_BusClockEnable(SPI0);
    SPIx_Nvic_Cmd(SPI0);
    SPIx_Config(SPI0,baud_rate);
}


/**
 * @brief SPIx_TxRxCpltCallback
 * @param SPIx : SPI0/SPI1
 * @retval None
 */
void SPIx_TxRxCpltCallback(SPI_Type *SPIx) {
    if((SPIx!=SPI0)&&(SPIx!=SPI1))
    return ;

    if (spi_state.dummyByte_ongoing == TRUE) {
	    spi_state.dummyByte_ongoing = FALSE;
    } else {
	    spi_state.transmit_ongoing = FALSE;
    }
    return;
}

/**
 * @brief SPIx_TxCpltCallback
 * @param SPIx : SPI0/SPI1
 * @retval None
 */
void  SPIx_TxCpltCallback(SPI_Type *SPIx) {
    if((SPIx!=SPI0)&&(SPIx!=SPI1))
    return ;
    if (spi_state.dummyByte_ongoing == TRUE) {
         spi_state.dummyByte_ongoing = FALSE;
     } else {
         spi_state.transmit_ongoing = FALSE;
     }
    return;
}


/**
 * @brief SPIx_Comm_ReadWrite
 * @param SPIx : SPI0/SPI1
 * @retval None
 */
uint8_t SPIx_Comm_ReadWrite(SPI_Type *SPIx,uint8_t data)
{
    uint8_t u8_SPIRecvData;
    while(SPI_GetStatus(SPIx ,SPI_TransmitFIFOEmptyStatus) == RESET);
    SPI_SendData(SPIx, data);
    while(SPI_GetStatus(SPIx ,SPI_ReceiveFIFONotEmptyStatus) == RESET);
    u8_SPIRecvData = SPI_ReceiveData(SPIx);
    return u8_SPIRecvData;
}

//STD_RETURN_TYPE_e SPIx_Transmit(SPI_Type *SPIx , uint8_t *pData, uint16_t Size) 
//{
//    uint8_t i;
//	
//	SPI_SetPackCS(SPIx,SPI_PACK_CS_LOW);		  	//CS���ͣ���ʼ׼���������������
//	
//	SPIx_Comm_ReadWrite(SPIx,pData[0]);
//	SPIx_Comm_ReadWrite(SPIx,pData[1]);
//	SPIx_Comm_ReadWrite(SPIx,pData[2]);
//	SPIx_Comm_ReadWrite(SPIx,pData[3]);		  		//���� 2 byte command + 2 byte PEC

//    for(i=4;i<Size;i++)								//�������ݲ�
//    {
//      SPIx_Comm_ReadWrite(SPIx, pData[i]);
//    }
//		
//	    SPI_SetPackCS(SPIx,SPI_PACK_CS_HIGHT);
//    return E_OK;
//}

//STD_RETURN_TYPE_e SPIx_TransmitReceive(SPI_Type *SPIx, uint8_t *pTxData, uint8_t *pRxData, uint16_t Size) 
//{
//		uint8_t i;
//		uint8_t *p_rd;

//		pRxData[0] = pTxData[0];					//2 byte cmd + 2 byte PECҲ����������Ļ�����
//		pRxData[1] = pTxData[1];
//		pRxData[2] = pTxData[2];
//		pRxData[3] = pTxData[3];
//		p_rd = &pRxData[4];


//		SPI_SetPackCS(SPIx,SPI_PACK_CS_LOW);			//CS���ͣ���ʼ׼���������������
//		SPIx_Comm_ReadWrite(SPIx,pTxData[0]);
//		SPIx_Comm_ReadWrite(SPIx,pTxData[1]);
//		SPIx_Comm_ReadWrite(SPIx,pTxData[2]);
//		SPIx_Comm_ReadWrite(SPIx,pTxData[3]);			//���� 2 byte command + 2 byte PEC

//		for(i= 4; i < Size; i++)						//�������ݲ�
//		{
//		*p_rd++ = SPIx_Comm_ReadWrite(SPIx,pTxData[i]);
//		}
//		SPI_SetPackCS(SPIx,SPI_PACK_CS_HIGHT);		//CS���ߣ�����ͨ��

//		return E_OK;
//}

/**
 * sends a dummy byte on SPI.
 *
 * @param   busID      selects which CS pin has to be set high
 * @param   *hspi      pointer to SPI hardware handle
 *
 * @return             E_OK if SPI transmission is OK, E_NOT_OK otherwise
 */
STD_RETURN_TYPE_e SPI_SendDummyByte(SPI_Type *SPIx,uint8_t Size) {
    uint8_t i;
    for(i=0;i<Size;i++)
    {
	while(SPI_GetStatus(SPIx ,SPI_TransmitFIFOEmptyStatus) == RESET);
	SPI_SendData(SPIx, *spi_cmdDummy);
    }
    return E_OK;
}



/**
 * waits a defined time.
 *
 */
void SPI_Wait(void) {
	//delay_ms(1);
}

/**
 * SPI_IsTransmitOngoing a defined time.
 *
 */
extern uint8_t  SPI_IsTransmitOngoing(void) {
    STD_RETURN_TYPE_e retval = FALSE;

      retval    =  spi_state.transmit_ongoing;

      return (retval);
}

/**
 * SPI_SetTransmitOngoing a defined time.
 *
 */
extern void SPI_SetTransmitOngoing(void) {
    spi_state.transmit_ongoing = TRUE;
}

/**
 * SPI_SetTransmitOngoing a defined time.
 *
 */
extern void SPI_ClearTransmitOngoing(void) {
    spi_state.transmit_ongoing = FALSE;
}
