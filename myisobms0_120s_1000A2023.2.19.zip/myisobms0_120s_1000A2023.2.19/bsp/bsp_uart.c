#include "bsp_uart.h"

/**
* @brief ����Debug�˿�
*/
UART_Type *Debug_Port;

#ifdef __GNUC__

#define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
#else
#define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)

#endif 

#ifdef USE_IAR


#else
#pragma import(__use_no_semihosting)             
//��׼����Ҫ��֧�ֺ���                 
struct __FILE 
{ 
    int handle; 
    
}; 

FILE __stdout;       
//����_sys_exit()�Ա���ʹ�ð�����ģʽ    
int _sys_exit(int x) 
{ 
    x = x; 
} 
//�ض���fputc���� 
/****************************************************************************************************************************************** 
* ��������: fputc()
* ����˵��: printf()ʹ�ô˺������ʵ�ʵĴ��ڴ�ӡ����
* ��    ��: int ch		Ҫ��ӡ���ַ�
*			FILE *f		�ļ����
* ��    ��: ��
* ע������: ��
******************************************************************************************************************************************/
int fputc(int ch, FILE *f)
    {
    	while(!UART_GetLineStatus(Debug_Port,UART_LSRTHREmpty));
    	UART_SendData(Debug_Port, (uint8_t) ch);
    	return ch;
    }
    /**
      * @brief  �ض���printf()������
      */
    int fgetc(FILE *f)
    {
    	return (int)UART_ReceiveData(Debug_Port);
    }

#endif 




/**
  * @brief  Debug�˿�����
  * @param  UARTx: ѡ��UART����
	*		�����������ȡ�����ֵ:
  *			@arg UART0: UART0����
  *			@arg UART1: UART1����
  *			@arg UART2: UART2����
  * @retval None
  */
void XL6600_UartDebug_Config(uint32_t baud_rate)
{	
			UART_InitTypeDef UART_InitStructure;

//	NVIC_InitTypeDef NVIC_InitStructure;

//	SIM_PINSEL_UART1(UART1_PS_PTF3_PTF2);
	SIM_SCGC_Cmd(SIM_SCGC_UART1,ENABLE);
Debug_Port = UART1;
	UART_InitStructure.UART_SourceClk = Get_PeripheralClock();
	UART_InitStructure.UART_BaudRate = 9600;
	UART_InitStructure.UART_DataLength = UART_DataLength_8b;
	UART_InitStructure.UART_StopBits = UART_StopBits_1;
	UART_InitStructure.UART_Parity = UART_Parity_No;
	UART_Init(UART1, &UART_InitStructure);


#if 0   //���ڲ������ж�ģʽ  ������ѯģʽ��ȡ��������
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);

	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
	NVIC_InitStructure.NVIC_IRQChannel = UART1_IRQn;
	NVIC_Init(&NVIC_InitStructure);
	UART_EnableInterruptCmd(UART1, UART_RDataAvailableIntEN, ENABLE);
#endif

	UART_EnableCmd(UART1, ENABLE);
	
	
 

//	NVIC_InitTypeDef NVIC_InitStructure;

//	SIM_PINSEL_UART1(UART1_PS_PTF3_PTF2);
	SIM_SCGC_Cmd(SIM_SCGC_UART0,ENABLE);
Debug_Port = UART0;
	UART_InitStructure.UART_SourceClk = Get_PeripheralClock();
	UART_InitStructure.UART_BaudRate = 115200;
	UART_InitStructure.UART_DataLength = UART_DataLength_8b;
	UART_InitStructure.UART_StopBits = UART_StopBits_1;
	UART_InitStructure.UART_Parity = UART_Parity_No;
	UART_Init(UART0, &UART_InitStructure);


#if 0   //���ڲ������ж�ģʽ  ������ѯģʽ��ȡ��������
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);

	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
	NVIC_InitStructure.NVIC_IRQChannel = UART1_IRQn;
	NVIC_Init(&NVIC_InitStructure);
	UART_EnableInterruptCmd(UART1, UART_RDataAvailableIntEN, ENABLE);
#endif

	UART_EnableCmd(UART0, ENABLE);
}

/**
 *******************************************************************************
 ** \brief UART receive byte.
 **
 ** \param [out] u8RxData                   Pointer to Rx data.
 **
 ** \retval Ok                              Receive data finished.
 ** \retval Error                           Don't receive data.
 **
 ******************************************************************************/
 en_result_t myUART_RecvByte(uint8_t *u8RxData)
{
	if(UART_GetLineStatus(UART1, UART_LSRDataReady))
	{
        *u8RxData = UART_ReceiveData(UART1);
        return  u_Ok;
	}
	else
	{

		return  u_Error;
	}
}





