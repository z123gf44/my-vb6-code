/**
  ******************************************************************************
  * @file     xl_can.h
  * @author   Kirk ,xu.wang
  * @version  5.0.5
  * @date     Thu Sep 15 16:45:17 2022
  * @brief    This file contains all the functions prototypes for the CAN 
  *           firmware library.
  ******************************************************************************
  * @attention
	*
  * 2019 by Chipways Communications,Inc. All Rights Reserved.
  * This software is supplied under the terms of a license
  * agreement or non-disclosure agreement with Chipways.
  * Passing on and copying of this document,and communication
  * of its contents is not permitted without prior written
  * authorization.
  *
  * <h2><center>&copy; COPYRIGHT 2019 Chipways</center></h2>
  ******************************************************************************
  */
	
/* Define to prevent recursive inclusion -------------------------------------*/	  
#ifndef XL_CAN_H
#define XL_CAN_H

#ifdef __cplusplus
extern "C" {
#endif
/* Includes ---------------------------------------------------------------*/
#include "XL6600.h"

#define XL_CAN_H_MAJOR_VERSION             1
#define XL_CAN_H_MINOR_VERSION             0
#define XL_CAN_H_PATCH_VERSION             2	
	
#if ((XL_CAN_H_MAJOR_VERSION != XL6600_H_MAJOR_VERSION) || \
     (XL_CAN_H_MINOR_VERSION != XL6600_H_MINOR_VERSION) || \
     (XL_CAN_H_PATCH_VERSION != XL6600_H_PATCH_VERSION))
        #error "xl_can.h Version Numbers of XL6600.h are different"
#endif	
/* Register define ------------------------------------------------------------*/
#pragma anon_unions /* added by neo, to support union function */

/* CANMOD Bit Fields */
#define CAN_CANMOD_RM_MASK                     0x1u
#define CAN_CANMOD_RM_SHIFT                    0
#define CAN_CANMOD_LOM_MASK                    0x2u
#define CAN_CANMOD_LOM_SHIFT                   1
#define CAN_CANMOD_STM_MASK                    0x4u
#define CAN_CANMOD_STM_SHIFT                   2
#define CAN_CANMOD_AFM_MASK                    0x8u
#define CAN_CANMOD_AFM_SHIFT                   3
#define CAN_CANMOD_SM_MASK                     0x10u
#define CAN_CANMOD_SM_SHIFT                    4
/* CANCMR Bit Fields */
#define CAN_CANCMR_TR_MASK                     0x1u
#define CAN_CANCMR_TR_SHIFT                    0
#define CAN_CANCMR_AT_MASK                     0x2u
#define CAN_CANCMR_AT_SHIFT                    1
#define CAN_CANCMR_RRB_MASK                    0x4u
#define CAN_CANCMR_RRB_SHIFT                   2
#define CAN_CANCMR_CDO_MASK                    0x8u
#define CAN_CANCMR_CDO_SHIFT                   3
#define CAN_CANCMR_SRR_MASK                    0x10u
#define CAN_CANCMR_SRR_SHIFT                   4
/* CANSR Bit Fields */
#define CAN_CANSR_RBS_MASK                     0x1u
#define CAN_CANSR_RBS_SHIFT                    0
#define CAN_CANSR_DOS_MASK                     0x2u
#define CAN_CANSR_DOS_SHIFT                    1
#define CAN_CANSR_TBS_MASK                     0x4u
#define CAN_CANSR_TBS_SHIFT                    2
#define CAN_CANSR_TCS_MASK                     0x8u
#define CAN_CANSR_TCS_SHIFT                    3
#define CAN_CANSR_RS_MASK                      0x10u
#define CAN_CANSR_RS_SHIFT                     4
#define CAN_CANSR_TS_MASK                      0x20u
#define CAN_CANSR_TS_SHIFT                     5
#define CAN_CANSR_ES_MASK                      0x40u
#define CAN_CANSR_ES_SHIFT                     6
#define CAN_CANSR_BS_MASK                      0x80u
#define CAN_CANSR_BS_SHIFT                     7
/* CANIR Bit Fields */
#define CAN_CANIR_RI_MASK                      0x1u
#define CAN_CANIR_RI_SHIFT                     0
#define CAN_CANIR_TI_MASK                      0x2u
#define CAN_CANIR_TI_SHIFT                     1
#define CAN_CANIR_EI_MASK                      0x4u
#define CAN_CANIR_EI_SHIFT                     2
#define CAN_CANIR_DOI_MASK                     0x8u
#define CAN_CANIR_DOI_SHIFT                    3
#define CAN_CANIR_WUI_MASK                     0x10u
#define CAN_CANIR_WUI_SHIFT                    4
#define CAN_CANIR_EPI_MASK                     0x20u
#define CAN_CANIR_EPI_SHIFT                    5
#define CAN_CANIR_ALI_MASK                     0x40u
#define CAN_CANIR_ALI_SHIFT                    6
#define CAN_CANIR_BEI_MASK                     0x80u
#define CAN_CANIR_BEI_SHIFT                    7
/* CANIER Bit Fields */
#define CAN_CANIER_RIE_MASK                    0x1u
#define CAN_CANIER_RIE_SHIFT                   0
#define CAN_CANIER_TIE_MASK                    0x2u
#define CAN_CANIER_TIE_SHIFT                   1
#define CAN_CANIER_EIE_MASK                    0x4u
#define CAN_CANIER_EIE_SHIFT                   2
#define CAN_CANIER_DOIE_MASK                   0x8u
#define CAN_CANIER_DOIE_SHIFT                  3
#define CAN_CANIER_WUIE_MASK                   0x10u
#define CAN_CANIER_WUIE_SHIFT                  4
#define CAN_CANIER_EPIE_MASK                   0x20u
#define CAN_CANIER_EPIE_SHIFT                  5
#define CAN_CANIER_ALIE_MASK                   0x40u
#define CAN_CANIER_ALIE_SHIFT                  6
#define CAN_CANIER_BEIE_MASK                   0x80u
#define CAN_CANIER_BEIE_SHIFT                  7
/* CANBTR0 Bit Fields */
#define CAN_CANBTR0_BRP_MASK                   0x3Fu
#define CAN_CANBTR0_BRP_SHIFT                  0
#define CAN_CANBTR0_SJW_MASK                   0xC0u
#define CAN_CANBTR0_SJW_SHIFT                  6
/* CANBTR1 Bit Fields */
#define CAN_CANBTR1_TSEG1_MASK                 0xFu
#define CAN_CANBTR1_TSEG1_SHIFT                0
#define CAN_CANBTR1_TSEG2_MASK                 0x70u
#define CAN_CANBTR1_TSEG2_SHIFT                4
#define CAN_CANBTR1_SAMP_MASK                  0x80u
#define CAN_CANBTR1_SAMP_SHIFT                 7
/* CANALC Bit Fields */
#define CAN_CANALC_ALC_MASK                    0x1Fu
#define CAN_CANALC_ALC_SHIFT                   0
/* CANECC Bit Fields */
#define CAN_CANECC_SEGMENT_MASK                0x1Fu
#define CAN_CANECC_SEGMENT_SHIFT               0
#define CAN_CANECC_DIR_MASK                    0x20u
#define CAN_CANECC_DIR_SHIFT                   5
#define CAN_CANECC_ERROR_MASK                  0xC0u
#define CAN_CANECC_ERROR_SHIFT                 6
/* CANEWLR Bit Fields */
#define CAN_CANEWLR_EWL_MASK                   0xFFu
#define CAN_CANEWLR_EWL_SHIFT                  0
/* CANRXERR Bit Fields */
#define CAN_CANRXERR_RXERR_MASK                0xFFu
#define CAN_CANRXERR_RXERR_SHIFT               0
/* CANTXERR Bit Fields */
#define CAN_CANTXERR_TXERR_MASK                0xFFu
#define CAN_CANTXERR_TXERR_SHIFT               0
/* CANTB Bit Fields */
#define CAN_CANTB_TX_MASK                      0xFFu
#define CAN_CANTB_TX_SHIFT                     0
/* CANRB Bit Fields */
#define CAN_CANRB_RX_MASK                      0xFFu
#define CAN_CANRB_RX_SHIFT                     0
/* CANACR Bit Fields */
#define CAN_CANACR_AC_MASK                     0xFFu
#define CAN_CANACR_AC_SHIFT                    0
/* CANAMR Bit Fields */
#define CAN_CANAMR_AM_MASK                     0xFFu
#define CAN_CANAMR_AM_SHIFT                    0
/* CANRMC Bit Fields */
#define CAN_CANRMC_RMC_MASK                    0x1Fu
#define CAN_CANRMC_RMC_SHIFT                   0
/* CANRBSA Bit Fields */
#define CAN_CANRBSA_RBSA_MASK                  0x3Fu
#define CAN_CANRBSA_RBSA_SHIFT                 0
/** CAN - Register Layout Typedef */
typedef struct {
  __IO uint32_t CANMOD;                            /**< CAN Mode Register, offset: 0x0 */
  __O  uint32_t CANCMR;                            /**< CAN Command Register, offset: 0x4 */
  __I  uint32_t CANSR;                             /**< CAN Status Register, offset: 0x8 */	
  __I  uint32_t CANIR;                             /**< CAN Interrupt Register, offset: 0xc */	
  __IO uint32_t CANIER;                            /**< CAN Interrupt Enable Register, offset: 0x10 */	
  __IO uint32_t RESERVED_0[1];                        
  __IO uint32_t CANBTR0;                           /**< CAN Bus Timing Register 0, offset: 0x18 */
  __IO uint32_t CANBTR1;                           /**< CAN Bus Timing Register 1, offset: 0x1c */
  __IO uint32_t RESERVED_1[1];                            /**< CAN Bus FD Timing Register 0, offset: 0x20 */	
  __IO uint32_t RESERVED_2[2];                    
  __I  uint32_t CANALC;                            /**< CAN Arbitration Lost Capture Register, offset: 0x2C */ 
  __I  uint32_t CANECC;                            /**< CAN Error Code Capture Register, offset: 0x30 */
  __IO uint32_t CANEWLR;                           /**< CAN Error Warning Limit Register, offset: 0x34 */
  __IO uint32_t CANRXERR;                          /**< CAN Receive Error Counter, offset: 0x38 */
  __IO uint32_t CANTXERR;                          /**< CAN Transmit Error Counter, offset: 0x3C */
  union 
	{		
		__O uint32_t CANTB[13];                        /**< CAN Transmit Buffer Register n, array offset: 0x48, array step: 0x4  */
		__I uint32_t CANRB[13];                        /**< CAN Receive Buffer Register n, array offset: 0x48, array step: 0x4  */
		struct
		{
			__IO uint32_t CANACR[4];                     /**< CAN Identifier Acceptance code Register n, array offset: 0x48, array step: 0x4  */
			__IO uint32_t CANAMR[4];                     /**< CAN Identifier Acceptance mask Register n, array offset: 0x58, array step: 0x4  */
			uint32_t RESERVED_3[5];	
		}CANAR; 
	};	
  __I  uint32_t CANRMC;                            /**< CAN Receive Message Counter Register, offset: 0x74*/
	   uint32_t CANRBSA;						                 /** 0x78*/
  __IO  uint32_t RESERVED_3[1];                    /**0x7C */	
	uint32_t RESERVED_4[8];	
	struct
	{
		__IO uint32_t CANACR1[4];                     /**< CAN Identifier Acceptance code Register n, array offset: 0xA0, array step: 0x4  */
		__IO uint32_t CANAMR1[4];                     /**< CAN Identifier Acceptance mask Register n, array offset: 0xB0, array step: 0x4  */
	}CANAR1; 

} CAN_Type;
extern CAN_Type* 		CAN;


/** @addtogroup XL6600_StdPeriph_Driver
  * @{
  */

/** @addtogroup CAN 
  * @{
  */

/* Exported types ------------------------------------------------------------*/ 

/**
 * @brief CAN �������ͳ�ʼ���ṹ��
 */
typedef struct
{
	uint8_t CAN_ErrorWarningLimit ;     			/*!< error warning limit. */
	uint8_t CAN_ReceiveErrorCount ;    			/*!< receive error count */
	uint8_t CAN_TranmitErrorCount ;     			/*!< transmit error count */	
}CAN_ErrorSettingDef;

/**
 * @brief CAN ��ʼ���ṹ��
 */
typedef struct
{
	uint32_t CAN_SJW;     		            			/*!< Synchronization Jump Width. */
	uint32_t CAN_BRP;					              	/*!< Baud Rate Prescaler. */
	uint32_t CAN_SAMP;				             		/*!< Sampling. */
	uint32_t CAN_TSEG2;				            		/*!< Time Segment 2. */
	uint32_t CAN_TSEG1;					            	/*!< Time Segment 1. */
}CAN_InitTypeDef;

typedef enum{
	can_fram_filterEN = 0,
	can_fram_noFilterEN
}CAN_FramFilterDef;

/**
 * @brief CAN ��׼֡���˲���ʼ���ṹ��
 */
typedef struct{
	uint32_t CAN_FiltMode;
	
	//�˲�ͨ��0
	uint32_t CHANNEL0_CAN_IDAR;		    	            		/*!< CAN��ʶ�� + һλԶ�̴������� */
	uint32_t CHANNEL0_CAN_IDMR;		    	           			/*!< CAN�������� + һλԶ�̴������� */
	uint32_t CHANNEL0_CAN_RTR;
	CAN_FramFilterDef CHANNEL0_CAN_RTRMR;
	uint16_t CHANNEL0_CAN_DataAR;
	uint16_t CHANNEL0_CAN_DataMR;
	
	//�˲�ͨ��1
	uint32_t CHANNEL1_CAN_IDAR;		    	            		
	uint32_t CHANNEL1_CAN_IDMR;		    	           		
	uint32_t CHANNEL1_CAN_RTR;
	CAN_FramFilterDef CHANNEL1_CAN_RTRMR;
	uint16_t CHANNEL1_CAN_DataAR;
	uint16_t CHANNEL1_CAN_DataMR;
}CAN_SFSingleFilterDef;
/**
 * @brief CAN ��չ֡���˲���ʼ���ṹ��
 */
typedef struct{
	uint32_t CAN_FiltMode;
	
	//�˲�ͨ��0
	uint32_t CHANNEL0_CAN_IDAR;		    	            		/*!< CAN��ʶ�� + һλԶ�̴������� */
	uint32_t CHANNEL0_CAN_IDMR;		    	           			/*!< CAN�������� + һλԶ�̴������� */
	uint32_t CHANNEL0_CAN_RTR;
	CAN_FramFilterDef CHANNEL0_CAN_RTRMR;
	
	//�˲�ͨ��1
	uint32_t CHANNEL1_CAN_IDAR;		    	            	
	uint32_t CHANNEL1_CAN_IDMR;		    	           			
	uint32_t CHANNEL1_CAN_RTR;
	CAN_FramFilterDef CHANNEL1_CAN_RTRMR;
}CAN_ExtFSingleFilterDef;
/**
 * @brief CAN ��׼֡˫�˲���ʼ���ṹ��
 */
typedef struct{
	uint32_t CAN_FiltMode;
	
	//�˲�ͨ��0
	uint32_t CHANNEL0_CAN_IDAR;		    	            		/*!< CAN��ʶ�� + һλԶ�̴������� */
	uint32_t CHANNEL0_CAN_IDMR;		    	           			/*!< CAN�������� + һλԶ�̴������� */
	uint32_t CHANNEL0_CAN_RTR;
	CAN_FramFilterDef CHANNEL0_CAN_RTRMR;
	uint32_t CHANNEL0_CAN_DIDAR;
	uint32_t CHANNEL0_CAN_DIDMR;
	uint32_t CHANNEL0_CAN_DRTR;
	CAN_FramFilterDef CHANNEL0_CAN_DRTRMR;
	uint8_t  CHANNEL0_CAN_DataAR;
	uint8_t  CHANNEL0_CAN_DataMR;
	
	//�˲�ͨ��1
	uint32_t CHANNEL1_CAN_IDAR;		    	            		
	uint32_t CHANNEL1_CAN_IDMR;		    	           			
	uint32_t CHANNEL1_CAN_RTR;
	CAN_FramFilterDef CHANNEL1_CAN_RTRMR;
	uint32_t CHANNEL1_CAN_DIDAR;
	uint32_t CHANNEL1_CAN_DIDMR;
	uint32_t CHANNEL1_CAN_DRTR;
	CAN_FramFilterDef CHANNEL1_CAN_DRTRMR;
	uint8_t  CHANNEL1_CAN_DataAR;
	uint8_t  CHANNEL1_CAN_DataMR;
}CAN_SFDualFilterDef;
/**
 * @brief CAN ��չ֡˫�˲���ʼ���ṹ��
 */
typedef struct{
	uint32_t CAN_FiltMode;
	
	//�˲�ͨ��0
	uint32_t CHANNEL0_CAN_IDAR;		    	            		/*!< CAN��ʶ�� + һλԶ�̴������� */
	uint32_t CHANNEL0_CAN_IDMR;		    	           			/*!< CAN�������� + һλԶ�̴������� */
	uint32_t CHANNEL0_CAN_DIDAR;
	uint32_t CHANNEL0_CAN_DIDMR;
	
	//�˲�ͨ��1
	uint32_t CHANNEL1_CAN_IDAR;		    	            		
	uint32_t CHANNEL1_CAN_IDMR;		    	           	
	uint32_t CHANNEL1_CAN_DIDAR;
	uint32_t CHANNEL1_CAN_DIDMR;
}CAN_ExtFDualFilterDef;
/**
 * @brief CAN �Զ����˲���ʼ���ṹ��
 */
typedef struct{
	uint32_t CAN_FiltMode;
	
	//�˲�ͨ��0
	uint8_t CHANNEL0_CAN_AR0;		    	            		/*!< �Ĵ���AR0��ֵ */
	uint8_t CHANNEL0_CAN_MR0;		    	           			/*!< �Ĵ���MR0��ֵ */
	uint8_t CHANNEL0_CAN_AR1;		    	            		/*!< �Ĵ���AR1��ֵ */
	uint8_t CHANNEL0_CAN_MR1;		    	           			/*!< �Ĵ���MR1��ֵ */
	uint8_t CHANNEL0_CAN_AR2;		    	            		/*!< �Ĵ���AR2��ֵ */
	uint8_t CHANNEL0_CAN_MR2;		    	           			/*!< �Ĵ���MR2��ֵ */
	uint8_t CHANNEL0_CAN_AR3;		    	            		/*!< �Ĵ���AR3��ֵ */
	uint8_t CHANNEL0_CAN_MR3;		    	           			/*!< �Ĵ���MR3��ֵ */
	
	//�˲�ͨ��1
	uint8_t CHANNEL1_CAN_AR0;		    	            		
	uint8_t CHANNEL1_CAN_MR0;		    	           			
	uint8_t CHANNEL1_CAN_AR1;		    	            		
	uint8_t CHANNEL1_CAN_MR1;		    	           			
	uint8_t CHANNEL1_CAN_AR2;		    	            		
	uint8_t CHANNEL1_CAN_MR2;		    	           			
	uint8_t CHANNEL1_CAN_AR3;		    	            		
	uint8_t CHANNEL1_CAN_MR3;		    	           			
}CAN_CustomerFilterDef;

typedef enum{
	CAN_SFDualFilterType = 0,						/*!< ��׼֡˫�˲� */
	CAN_SFSingleFilterType = 1,				/*!< ��׼֡���˲� */
	CAN_ExtFDualFilterType = 2,						/*!< ��չ֡˫�˲� */
	CAN_ExtFSingleFilterType = 3,					/*!< ��չ֡���˲� */
	CAN_CustomerSingleFilterType = 5,				/*!< �û����嵥�˲� */
	CAN_CustomerDualFilterType = 6,				/*!< �û�����˫�˲� */
}CAN_FiltTypeEnum;

/**
 * @brief CAN �˲���ʼ���ṹ��
 */
typedef struct
{
	union{
		CAN_ExtFDualFilterDef 	CAN_ExtFDualFilter;
		CAN_SFDualFilterDef	CAN_SFDualFilter;
		CAN_ExtFSingleFilterDef	CAN_ExtFSingleFilter;
		CAN_SFSingleFilterDef	CAN_SFSingleFilter;
		CAN_CustomerFilterDef	CAN_CustomerFilterDef;
	};
}CAN_FilterDef, *CAN_FilterConfigPtr;

/** 
  * @brief  CAN ���ͽ�����Ϣ��ʼ���ṹ��
  */
typedef struct
{
  uint32_t CAN_ID;                        /*!< Specifies the standard identifier(11 bits) or extended identifier(29 bits). */
  uint32_t CAN_FDBRS;                      /*!< Set bit rate switch, Only exist in FD mode.  */
  uint32_t CAN_FDESI;                      /*!< Set error state indicator, Only exist in FD mode.  */	
  uint32_t CAN_FF;                         /*!< Specifies Frame format for the message that will be received.  */
  uint32_t CAN_RTR;                        /*!< Specifies the type of frame for the received message.  */
  uint32_t CAN_DLC;                        /*!< Specifies the length of the frame that will be received.
                                                This parameter can be a value between 0 to 8 */
  uint8_t CAN_Data[64];                   /*!< Contains the data to be received. It ranges from 0 to 63. */
                                             
} CAN_MsgTypeDef, *CAN_MsgConfigPtr;

/* Exported constants --------------------------------------------------------*/
/** @defgroup CAN_Exported_Constants CANģ��ʹ�ò�������
  * @{
  */

/**  
	* @defgroup CAN_Mode_List CANģʽ����
  * @{
  */	
#define CAN_NORMALMODE                   0			/*!< Normal operation. */
#define CAN_RESETMODE                    1			/*!< Reset Mode. */	
#define CAN_LISTENONLYMODE               2			/*!< Listen Only Mode. */
#define CAN_SELFTESTMODE                 3			/*!< Self Test Mode. */
#define CAN_SLEEPMODE                    4			/*!< Sleep Mode. */
/** 
  * @} 
  */
	
/** 
	* @defgroup CAN_synchronisation_jump_width CANͬ����ת���ȶ���
  * @{
  */	
#define CAN_SJW_1tq                 	((uint8_t)0x00)  /*!< 1 time quantum */
#define CAN_SJW_2tq                 	((uint8_t)0x01)  /*!< 2 time quantum */
#define CAN_SJW_3tq                 	((uint8_t)0x02)  /*!< 3 time quantum */
#define CAN_SJW_4tq                 	((uint8_t)0x03)  /*!< 4 time quantum */
/** 
  * @} 
  */
	
/** 
	* @defgroup CAN_Sample_Times  CAN����ʱ�䶨��
  * @{
  */	
#define CAN_SAMPLE_1                	((uint8_t)0x00) /*!< One sample per bit. */
#define CAN_SAMPLE_3                	((uint8_t)0x01) /*!< Three sample per bit */
/** 
  * @} 
  */

/** 
	* @defgroup CAN_TSEG1_Select CANʱ���2����
  * @{
  */
#define CAN_TSEG1_1tq                 ((uint8_t)0x00)  /*!< 1 time quantum */	
#define CAN_TSEG1_2tq                 ((uint8_t)0x01)  /*!< 2 time quantum */	
#define CAN_TSEG1_3tq                 ((uint8_t)0x02)  /*!< 3 time quantum */		
#define CAN_TSEG1_4tq                 ((uint8_t)0x03)  /*!< 4 time quantum */
#define CAN_TSEG1_5tq                 ((uint8_t)0x04)  /*!< 5 time quantum */
#define CAN_TSEG1_6tq                 ((uint8_t)0x05)  /*!< 6 time quantum */
#define CAN_TSEG1_7tq                 ((uint8_t)0x06)  /*!< 7 time quantum */
#define CAN_TSEG1_8tq                 ((uint8_t)0x07)  /*!< 8 time quantum */
#define CAN_TSEG1_9tq                 ((uint8_t)0x08)  /*!< 9 time quantum */
#define CAN_TSEG1_10tq                ((uint8_t)0x09)  /*!< 10 time quantum */
#define CAN_TSEG1_11tq                ((uint8_t)0x0A)  /*!< 11 time quantum */
#define CAN_TSEG1_12tq                ((uint8_t)0x0B)  /*!< 12 time quantum */
#define CAN_TSEG1_13tq                ((uint8_t)0x0C)  /*!< 13 time quantum */
#define CAN_TSEG1_14tq                ((uint8_t)0x0D)  /*!< 14 time quantum */
#define CAN_TSEG1_15tq                ((uint8_t)0x0E)  /*!< 15 time quantum */
#define CAN_TSEG1_16tq                ((uint8_t)0x0F)  /*!< 16 time quantum */
/** 
  * @} 
  */
	
/** 
	* @defgroup CAN_TSEG2_Select CANʱ���1����
  * @{
  */
#define CAN_TSEG2_1tq                 ((uint8_t)0x00)  /*!< 1 time quantum */  //Nemo cmt
#define CAN_TSEG2_2tq                 ((uint8_t)0x01)  /*!< 2 time quantum */
#define CAN_TSEG2_3tq                 ((uint8_t)0x02)  /*!< 3 time quantum */
#define CAN_TSEG2_4tq                 ((uint8_t)0x03)  /*!< 4 time quantum */
#define CAN_TSEG2_5tq                 ((uint8_t)0x04)  /*!< 5 time quantum */
#define CAN_TSEG2_6tq                 ((uint8_t)0x05)  /*!< 6 time quantum */
#define CAN_TSEG2_7tq                 ((uint8_t)0x06)  /*!< 7 time quantum */
#define CAN_TSEG2_8tq                 ((uint8_t)0x07)  /*!< 8 time quantum */
/** 
  * @} 
  */
	
/** 
	* @defgroup CAN_Filter_Scale  CAN�˲�ѡ����
  * @{
  */
#define CAN_Dual_Filter              	((uint8_t)0x00) /*!< Two 16-bit filters */
#define CAN_Single_Filter            	((uint8_t)0x01) /*!< One 32-bit filter */
/** 
  * @} 
  */
	
/** 
	* @defgroup CAN_FDM_FRAME  CANFD֡����
  * @{
  */	
#define CAN_FDM_NOMFrame             	((uint8_t)0x00) /*!< Normal Frame in FD mode  */
#define CAN_FDM_FDFrame              	((uint8_t)0x01) /*!< FD Frame in FD mode  */
/** 
  * @} 
  */
	
/** 
	* @defgroup CAN_BRS_Enable CAN������ת��
  * @{
  */	
#define CAN_BRS_DISABLE              	((uint8_t)0x00) /*!< same bit rate*/
#define CAN_BRS_ENABLE               	((uint8_t)0x01) /*!< switch bit rate */
/** 
  * @} 
  */
	
	
/** 
	* @defgroup CAN_ESI_Define CAN������
  * @{
  */		
#define CAN_ESI_ACTIVE              	((uint8_t)0x00) /*!< Error active */
#define CAN_ESI_PASSIVE             	((uint8_t)0x01) /*!< Error passive */
/** 
  * @} 
  */

/** 
	* @defgroup CAN_FRAME_FORMAT CAN֡�ṹ����
  * @{
  */	
#define CAN_Standard_Frame           	((uint8_t)0x00) /*!< Standard Frame Format (SFF) */
#define CAN_Extended_Frame           	((uint8_t)0x01) /*!< Extended Frame Format (EFF) */
/** 
  * @} 
  */
	
/** 
	* @defgroup CAN_REMOTE_TYPE CAN֡�ṹ����
  * @{
  */	
#define CAN_RTR_Data                 	((uint8_t)0x00)  /*!< Data frame */
#define CAN_RTR_Remote               	((uint8_t)0x01)  /*!< Remote frame */
/** 
  * @} 
  */
	
/** 
	* @defgroup CAN_DATA_LENGTH CAN���ݳ���
  * @{
  */
#define CAN_DLC_DATASIZE0            	((uint8_t)0x00)  /*!< 0 data bytes */
#define CAN_DLC_DATASIZE1            	((uint8_t)0x01)  /*!< 1 data bytes */
#define CAN_DLC_DATASIZE2            	((uint8_t)0x02)  /*!< 2 data bytes */
#define CAN_DLC_DATASIZE3            	((uint8_t)0x03)  /*!< 3 data bytes */
#define CAN_DLC_DATASIZE4            	((uint8_t)0x04)  /*!< 4 data bytes */
#define CAN_DLC_DATASIZE5            	((uint8_t)0x05)  /*!< 5 data bytes */
#define CAN_DLC_DATASIZE6            	((uint8_t)0x06)  /*!< 6 data bytes */
#define CAN_DLC_DATASIZE7            	((uint8_t)0x07)  /*!< 7 data bytes */
#define CAN_DLC_DATASIZE8            	((uint8_t)0x08)  /*!< 8 data bytes */
#define CAN_DLC_DATASIZE12           	((uint8_t)0x09)  /*!< 12 data bytes */
#define CAN_DLC_DATASIZE16           	((uint8_t)0x0A)  /*!< 16 data bytes */
#define CAN_DLC_DATASIZE20           	((uint8_t)0x0B)  /*!< 20 data bytes */
#define CAN_DLC_DATASIZE24           	((uint8_t)0x0C)  /*!< 24 data bytes */
#define CAN_DLC_DATASIZE32           	((uint8_t)0x0D)  /*!< 32 data bytes */
#define CAN_DLC_DATASIZE48           	((uint8_t)0x0E)  /*!< 48 data bytes */
#define CAN_DLC_DATASIZE64           	((uint8_t)0x0F)  /*!< 64 data bytes */
/** 
  * @} 
  */

/** 
	* @defgroup CAN_Bus_Error CAN��������
  * @{
  */
typedef enum
{
  CAN_BusErrorType = 0x00,             /*!< bus error type */
  CAN_BusErrorDirection  = 0x01,       /*!< bus error directiom */
  CAN_BusErrorPosition = 0x02          /*!< bus error position */
}CAN_BusErrorCaptureDef;
/** 
  * @} 
  */

/** 
	* @defgroup CAN Command_Set CAN ��������
  * @{
  */
#define CAN_TransmissionRequest	 		0x01   	      		/*!< transmit request cmd */
#define	CAN_AbortTransmission				0x02             	/*!< abort transmission cmd */                   
#define	CAN_ReleaseReceiveBuffer		0x04	          	/*!< release receive buffer cmd */
#define	CAN_ClearDataOverrun				0x08             	/*!< clear data overrun cmd */
#define	CAN_SelfReceptionRequest		0x10             	/*!< self reception request */
/** 
  * @} 
  */	

/** 
	* @defgroup CAN_Status_SR  CAN״̬����
  * @{
  */
typedef enum {
	CAN_ReceiveBufferStatus= 0,          /*!< Receive Buffer Status */
	CAN_DataOverrunStatus,               /*!< Data Overrun Status */
	CAN_TransBufferStatus,               /*!< Transmit Buffer Status */
	CAN_TransCompleteStatus,             /*!< transmit Complete status */
	CAN_ReceiveStatus,                   /*!< Receive Status */
	CAN_TransmitStatus,                  /*!< Transmit Status */
	CAN_ErrorStatus,                     /*!< Error Status */
	CAN_BusStatus	                       /*!< Bus Status */
} CAN_StatusTypeDef;
/** 
  * @} 
  */

/** 
	* @defgroup CAN_Interrupt_ID CAN�ж�ID
  * @{
  */
typedef enum {
	CAN_ReceiveInterrupt= 0,             /*!< Receive Interrupt ID*/
	CAN_TransmitInterrupt,               /*!< Transmit Interrupt ID*/
	CAN_ErrorWarningInterrupt,           /*!< Error Warning Interrupt ID */
	CAN_DataOverrunInterrupt,            /*!< Data Overrun Interrupt ID */
	CAN_WakeUpInterrupt,                 /*!< Wake-Up Interrupt ID */
	CAN_ErrorPassiveInterrupt,           /*!< Error Passive Interrupt ID */
	CAN_ArbitrationLostInterrupt,        /*!< Arbitration Lost Interrupt ID */
	CAN_BusErrorInterrupt                /*!< Bus Error Interrupt ID */
} CAN_InterruptFlgDef;
/** 
  * @} 
  */

/** 
	* @defgroup CAN_Interrupt_Enable CAN�ж�ʹ��
  * @{
  */
typedef enum {
	CAN_ReceiveInterruptEn= 0,            /*!< Receive Interrupt enable */
	CAN_TransmitInterruptEn,              /*!< Transmit Interrupt enable */
	CAN_ErrorWarningInterruptEn,          /*!< Error Warning Interrupt enable */
	CAN_DataOverrunInterruptEn,           /*!< Data Overrun Interrupt enable */
	CAN_WakeUpInterruptEn,                /*!< Wake-Up Interrupt enable */
	CAN_ErrorPassiveInterruptEn,          /*!< Error Passive Interrupt enable */
	CAN_ArbitrationLostInterruptEn,       /*!< Arbitration Lost Interrupt enable */
	CAN_BusErrorInterruptEn               /*!< Bus Error Interrupt enable */	
} CAN_InterruptEnDef;
/** 
  * @} 
  */

/**
	* @}
	*/


/* Exported macro ------------------------------------------------------------*/
/* Exported functions --------------------------------------------------------*/ 
void CAN_DeInit(CAN_Type* CANx);
void CAN_Init(CAN_Type* CANx, const CAN_InitTypeDef* CAN_InitStruct);
ErrorStatus CAN_FilterConfig(CAN_Type* CANx, const CAN_FilterDef* CAN_FilterStruct,CAN_FiltTypeEnum CAN_FiltType);
void CAN_LoadTransmitData(CAN_Type *CANx, const CAN_MsgTypeDef* TxMessage);
void CAN_ReceiveData(CAN_Type *CANx, CAN_MsgTypeDef* RxMessage);
void CAN_SetMode(CAN_Type *CANx, uint8_t CAN_ModeType);
void CAN_WakeUp(CAN_Type *CANx);
void CAN_SetCmd(CAN_Type *CANx, uint8_t CAN_CommandType);
void CAN_ClearReceiveInterrupt(CAN_Type *CANx);
FlagStatus CAN_GetStatus(const CAN_Type *CANx, CAN_StatusTypeDef CAN_StatusType);
ITStatus CAN_GetInterruptFlg(const CAN_Type *CANx, CAN_InterruptFlgDef CAN_InterruptFlg);
void CAN_InterruptEn(CAN_Type *CANx, CAN_InterruptEnDef CAN_Interrupt, FunctionalState NewState);
uint8_t CAN_ArbitrationLostCap(const CAN_Type *CANx);
uint8_t CAN_GetBusErrorType(const CAN_Type *CANx, CAN_BusErrorCaptureDef CAN_BusErrorCapture);
uint8_t CAN_GetReceiveErrorCounter(const CAN_Type *CANx);
uint8_t CAN_GetTransmitErrorCounter(const CAN_Type *CANx);
uint8_t CAN_GetReceiveMessageCounter(const CAN_Type *CANx);
void CAN_ErrorSettingModify(CAN_Type *CANx, const CAN_ErrorSettingDef *CAN_ErrorSetting);
uint32_t CAN_GetALLInterruptFlg(const CAN_Type *CANx);
uint32_t CAN_GetBufferStartAddr(const CAN_Type *CANx);
#ifdef __cplusplus
}
#endif

#endif   /*__XL_CAN_H__ */

/**
  * @}
  */

/**
  * @}
  */
