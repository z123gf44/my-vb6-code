#include "flash.h"
//#include "xl_flash.h"


FLASH_STATUS App_FlashEraseSector(const uint32_t targetaddress,const uint32_t time)
{
	uint32_t timeout = time;
	FLASH_STATUS errorstatus;
	errorstatus = FLASH_STATUS_SUCCESS;
	__disable_irq();
	if(FLASH_ERR_SUCCESS !=FLASH_EraseSector(targetaddress))  //��������
	{
		errorstatus = FLASH_ERR_INVALID_PARAM;
	}
	else
	{

		FLASH_LaunchCMD();	//����ִ��

		while(0u == FLASH_GetCmdFinshFlag())
		{
			timeout--;
			if(timeout<50)
			{
				break;
			}
		}
		if(timeout < 50)
		{
			errorstatus = FLASH_STATUS_TIMEOUT;
		}
		else
		{
			errorstatus=FLASH_CheckErrStatus();//flash����״̬��ȡ
		}
	}
	__enable_irq();
	return errorstatus;
}


FLASH_STATUS App_FlashEraseVerifySector(const uint32_t targetaddress,const uint32_t time)
{
	uint32_t timeout = time;
	FLASH_STATUS errorstatus;
	errorstatus = FLASH_STATUS_SUCCESS;
	__disable_irq();
	if(FLASH_ERR_SUCCESS !=FLASH_EraseVerifySector(targetaddress))  //����������У��
	{
		errorstatus = FLASH_ERR_INVALID_PARAM;
	}
	else
	{

		FLASH_LaunchCMD();	//����ִ��

		while(0u == FLASH_GetCmdFinshFlag())
		{
			timeout--;
			if(timeout<50)
			{
				break;
			}
		}
		if(timeout < 50)
		{
			errorstatus = FLASH_STATUS_TIMEOUT;
		}
		else
		{
			errorstatus=FLASH_CheckErrStatus();//flash����״̬��ȡ
		}
	}
	__enable_irq();
	return errorstatus;
}



FLASH_STATUS App_FlashWriteData(const uint32_t TargetAddress, const uint32_t DwData0, const uint32_t DwData1,const uint32_t time)
{
	uint32_t timeout = time;
	FLASH_STATUS errorstatus;
	errorstatus = FLASH_STATUS_SUCCESS;

	__disable_irq();
	if(FLASH_ERR_SUCCESS != FLASH_Program2LongWord( TargetAddress, DwData0, DwData1))//flashд8byte
	{
		errorstatus = FLASH_ERR_INVALID_PARAM;
	}
	else
	{

		FLASH_LaunchCMD();

		while(0u==FLASH_GetCmdFinshFlag())
		{
			timeout--;
			if(timeout<50)
			{
				break;
			}
		}

		if(timeout < 50)
		{
			errorstatus = FLASH_STATUS_TIMEOUT;
		}
		else
		{
			errorstatus=FLASH_CheckErrStatus();//flash����״̬��ȡ
		}
	}
	__enable_irq();
	return errorstatus;
}

uint64_t App_FlashReadData(uint32_t *TargetAddress)
{
	return FLASH_ReadLongWord(TargetAddress);//flash��8byte
}

FLASH_STATUS App_ChipErase(const uint32_t time)
{
	uint32_t timeout = time;
	FLASH_STATUS errorstatus;
	errorstatus = FLASH_STATUS_SUCCESS;
	__disable_irq();
	FLASH_EraseChip();


	FLASH_LaunchCMD();	//����ִ��

	while(0u == FLASH_GetCmdFinshFlag())
	{
		timeout--;
		if(timeout<50)
		{
			break;
		}
	}
	if(timeout < 50)
	{
		errorstatus = FLASH_STATUS_TIMEOUT;
	}
	else
	{
		errorstatus=FLASH_CheckErrStatus();//flash����״̬��ȡ
	}
	__enable_irq();
	return errorstatus;
}
