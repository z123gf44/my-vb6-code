 
#include "xl6600.h"
#include "system_XL6600.h"
#include "xl_uart.h"
#include "xl_sim.h"
#include "xl_ics.h"
#include "xl_gpio.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "xl_nvic.h"
#include "bsp_systick.h"
#include "bsp_uart.h"
#include "bsp_spi.h"
#include "XL8812_Demo.h"

#include "io.h"
 
#include "C51_TYPE.h"
#include "GasGauge.h"
#include "Timer51.h"
#include "com.h"
#include "upsuart.h"

#include "xl_wdog.h"
#define SPI_BAUD_RATE 1000000 


void init_PTC_TIME1mS (void) ;
	
/*
  50ms ADC GPIO5 ������ ���ڼ��� SOC
  200MS ADC һ��ȫ���ѹ ���¶�

*/

int32_t main (void) ;

int main(void) 
{
			uint8_t ledbit;
			SystemSetFEE(8000000, ICS_FLLFACTOR_1920, ICS_RDIV_1or32,ICS_RDIV2_5);
			Systick_Init();

//			GPIO_SetPinDir(GPIO_PTC6,GPIO_Direction_Output);
//			GPIO_SetPinDir(GPIO_PTC7,GPIO_Direction_Output);
//			GPIO_SetPin(GPIO_PTC6); 		
//			GPIO_SetPin(GPIO_PTC7); 		
			SPIx_Init(SPI_BAUD_RATE);
			XL6600_UartDebug_Config(115200);
			init_PTC_TIME1mS(); //����1MS ��ʱ�¼�
			demo_init();
	    bms_init();// ���ݳ�ʼ��

	
	while(1)
	{
			if(1==ledbit)
			{
				ledbit =0;
				LED_ON;
			}
			else
			{
				ledbit =1;
				LED_OFF;
			}
			InitGasGauge();	// ��ʼ��SOC
			Timer0Process(); // ÿms �����¼� 
			WDT_Clr(); //  ι��
			gzHandle();	//  ��������ͨѶ485 ����
			ups_handle();//  ��������ͨѶUPS����
	}

}


