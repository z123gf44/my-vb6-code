/**
  ******************************************************************************
  * @file     main.c
  * @author   software
  * @version  V3.0.0
  * @date     4-Jun-2019
  * @brief    This file provide function about pit firmware program 
  ******************************************************************************
  * @attention
	*
  * 2019 by Chipways Communications,Inc. All Rights Reserved.
  * This software is supplied under the terms of a license
  * agreement or non-disclosure agreement with Chipways.
  * Passing on and copying of this document,and communication
  * of its contents is not permitted without prior written
  * authorization.
  *
  * <h2><center>&copy; COPYRIGHT 2019 Chipways</center></h2>
  ******************************************************************************
  */
#include "xl_pit.h"
#include "xl_nvic.h"
#include "xl_gpio.h"
#include "xl_sim.h"
#include "xl_ics.h"
#include "system_XL6600.h"
#include <stdio.h>
 #include "Timer51.h" 
#define CLK_DIV_0 0
#define CLK_DIV_1 0
#define PIT0_COUNT 48000000
#define PIT1_COUNT 24000000


/**
 * @brief  PIT����
 */
static void PIT_Configuration(void)
{
	PIT_DeInit(); 

	PIT_Init((uint8_t)PIT_Channel0,PIT_Count_Mode,CLK_DIV_0); //set PIT[0] �û�����ģʽ 0��Ƶ
	PIT_InterruptEn((uint8_t)PIT_Channel0,ENABLE); //�ж�ʹ��
	PIT_SetLoadCount((uint8_t)PIT_Channel0,PIT0_COUNT); //���� 48000000   
	PIT_EnableCmd((uint8_t)PIT_Channel0,ENABLE );	 // ʹ�ܶ�ʱ��
}

/**
 * @brief  �ж�����
 */
static void NVIC_Configuration(void)
{
	NVIC_InitTypeDef NVIC_InitStructure;
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);  //
    
	NVIC_InitStructure.NVIC_IRQChannel = (uint8_t)PIT_CH0_IRQn;  //�ж�ͨ�����жϺ�->�жϺ���
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=3 ; //��ռ���ȼ�
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;	//�����ȼ�
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE; 	//ʹ���ж�
	NVIC_Init(&NVIC_InitStructure);
	
	NVIC_InitStructure.NVIC_IRQChannel = (uint8_t)PIT_CH1_IRQn;
	NVIC_Init(&NVIC_InitStructure); 
}

 
void init_PTC_TIME1mS (void) 
{
 
	
	SIM_SOPT0_BusClockDivide(BUSCLOCK_OUTPUT_DIVIDE_128);
	SIM_SOPT0_BusClockOutputCmd(ENABLE); //bus clock out
	
	SIM_SCGC_Cmd(SIM_SCGC_PIT,ENABLE); //PITģ��ʹ�� ϵͳ����ģ�� SCGC = 0x2
	NVIC_Configuration(); 
	PIT_Configuration(); //PIT ģ�����á���ʼ�� 2��PIT
}

/**
 * @brief  PIT�жϻص�����
 */
static void PIT_IRQ_Callback(PIT_Channel PIT_Channelx)
{
	if(PIT_Channelx == PIT_Channel0)
	{
		PIT_ClrInterrupt((uint8_t)PIT_Channel0); //���PIT�ж�
		GPIO_TogglePin(GPIO_PTH2);   //����
	}
	else
	{
	 // error
	}
}
/*lint -esym(765, PIT_CH0_IRQHandler) -esym(714, PIT_CH0_IRQHandler)*/
/**
 * @brief  PITͨ��0�жϴ�������
 */
U8  delay_sent_ms;
U8  delay_get_3ms;
static	U16  timssss;
 extern	U32 timecount  ; //ÿ���ϵ� ʱ������ ��λ���룬ƫ��1970��
tdsTimerBuf  TimerBuf;


void PIT_CH0_IRQHandler(void)
{
	PIT_IRQ_Callback(PIT_Channel0);
	  /* toggle selected led */
        timssss++;
        if(timssss >1000 )
        {
            timssss=0;
            timecount++;
        }
        
        TimerBuf.flag.ms_1 = 1;
        
        if(delay_get_3ms)delay_get_3ms--;
        if(	delay_sent_ms)delay_sent_ms--;
        
        if( ++TimerBuf.cnt.ms_50 >= 50 )
        {
            TimerBuf.flag.ms_50 = 1;
            TimerBuf.cnt.ms_50 = 0;
        }
        
        if( ++TimerBuf.cnt.ms_500 >= 500 )
        {
            TimerBuf.flag.ms_500 = 1;
            TimerBuf.cnt.ms_500 = 0;
        }
        
        #ifdef HAVE_LED_DIS			
        if( ++TimerBuf.cnt.ms_10 >= 2 )
        {
         if((led_time_alls==0)&&(led_time_alls2==0))   
            dis_5LED_SOC();
        }
        #endif
        
        if( ++TimerBuf.cnt.ms_1000 >= 1000 )
        {
            TimerBuf.flag.ms_1000 = 1;
            TimerBuf.cnt.ms_1000 = 0;
        }
}



