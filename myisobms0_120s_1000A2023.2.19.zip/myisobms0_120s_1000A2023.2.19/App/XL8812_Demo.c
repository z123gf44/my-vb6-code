#include "XL8812_Demo.h"
#include "bsp_systick.h"
#include "bsp_uart.h"
#include "XL881x.h"
#include "XL8812.h"
#include "XL881x_spidriver.h"
#include "C51_TYPE.h"
#include "com.h"
#include "bsp_uart.h"
void  delyssss(void)
{
	U8 ss;
	for(ss=0;ss<250;ss++)
	{
		ss--;
		ss++;
	}

}

void SerialPutChar(U8 C)
{
 
	delyssss();
		 
		usart_data_transmit(USART0,C);
		while(RESET == usart_flag_get(USART0, USART_FLAG_TBE));
}


void Serial_PutString(U8 *s)
{
 
	delyssss(  );
	delyssss(  );
    while (*s != '\0')
    {
        SerialPutChar(*s);
        s++;
    }
	delyssss();
	delyssss();
	delyssss();
	delyssss();
 
}

  #define    XL8812_DEMO_PRINTF     1
  #if               XL8812_DEMO_PRINTF
	#define    XL8812_demo_printf      printf

#else
   	#define  XL8812_demo_printf(fmt,arg...) 
#endif

#define ENABLED 1
#define DISABLED 0

void print_menu(void);
void print_cells( void);
void print_aux(void );
void print_stat(void);
void print_config(void);
void print_rxconfig(void);
void print_statsc(void);
void print_aux1(void);
void check_error(int error);

void   fuction_cells(void );
void   fuction_aux(void );
void   fuction_stat(void);
void   fuction_statsc(void);
void   fuction_aux1(void);
void   fuction_config(void);
void   fuction_rxconfig(void);
void   fuction_diagn(void);
void   fuction_MemorySelfTest(void);
void   fuction_ADC_Overlapselftest(void);
void   fuction_openwire_multi(void);
void   fuction_ADC_Redundancyselftest(void);


/* dev_scan_8812 */
uint8_t dev_scan_8812(uint8_t total_ic );
char get_char(void);
uint16_t XL8812_get_measure_Tcycle(uint8_t MD, uint8_t CH_or_GPIO, uint8_t ADCOPT);
void run_command(uint8_t cmd);
void measurement_loop(void);
int16_t    XL8812_Convert_MuxVoltages_to_Temperatures(uint32_t r_val);
/**********************************************************
  Setup Variables
  The following variables can be modified to
  configure the software.
***********************************************************/
//const uint8_t V82system.ICNum = 2;          //!< Number of ICs in the daisy chain  �����24

//ADC Command Configurations. SeeXL881x.h for options.
const uint8_t ADC_OPT = ADC_OPT_DISABLED; //!< ADC Mode option bit ADC Modes 8��ADC����ģʽ   
                                          // 0 -> Selects Modes 27kHz, 7kHz, 422Hz or 26Hz with MD[1:0] Bits in ADC Conversion Commands (Default)
                                          // 1 -> Selects Modes 14kHz, 3kHz, 1kHz or 2kHz with MD[1:0] Bits in ADC Conversion Commands
const uint8_t ADC_CONVERSION_MODE = MD_7KHZ_3KHZ; //!< ADC Mode �� ADC_OPT 

const uint8_t ADC_DCP = DCP_ENABLED; //!< Discharge Permitted   ���⣿

const uint8_t CELL_CH_TO_CONVERT = CELL_CH_ALL; //!< Channel Selection for ADC conversion

const uint8_t AUX_CH_TO_CONVERT = AUX_CH_ALL; //!< Channel Selection for ADC conversion

const uint8_t STAT_CH_TO_CONVERT = STAT_CH_ALL; //!< Channel Selection for ADC conversion

const uint8_t NO_OF_REG = REG_ALL; //!< Register Selection

const uint16_t MEASUREMENT_LOOP_TIME = 500; //!< Loop Time in milliseconds(ms)

//Under Voltage and Over Voltage Thresholds
const uint16_t OV_THRESHOLD = 41000; //!< Over voltage threshold ADC Code. LSB = 0.0001 ---(4.1V)
const uint16_t UV_THRESHOLD = 30000; //!< Under voltage threshold ADC Code. LSB = 0.0001 ---(3V)

//Loop Measurement Setup. These Variables are ENABLED or DISABLED. Remember ALL CAPS
const uint8_t WRITE_CONFIG = DISABLED; //!< Loop Measurement Setup
const uint8_t READ_CONFIG = DISABLED; //!< Loop Measurement Setup
const uint8_t MEASURE_CELL = ENABLED; //!< Loop Measurement Setup
const uint8_t MEASURE_AUX = DISABLED; //!< Loop Measurement Setup
const uint8_t MEASURE_STAT = DISABLED; //!< Loop Measurement Setup
const uint8_t PRINT_PEC = DISABLED; //!< Loop Measurement Setup
/************************************
  END SETUP
*************************************/

/******************************************************
 Global Battery Variables received from XL881x commands.
 These variables store the results from the XL8812
 register reads and the array lengths must be based
 on the number of ICs on the stack
 ******************************************************/
cell_asic bms_ic[10]; //!< Global Battery Variable
/*********************************************************
 Set the configuration bits. 
 Refer to the Configuration Register Group from data sheet. 
**********************************************************/
bool REFON = TRUE; //!< Reference Powered Up Bit

bool ADCOPT = FALSE; //!< ADC Mode option bit

bool gpioBits_a[5] = {TRUE,TRUE,TRUE,TRUE,TRUE}; //!< GPIO Pin Control // Gpio 1,2,3,4,5

uint16_t UV=UV_THRESHOLD; //!< Under-voltage Comparison Voltage

uint16_t OV=OV_THRESHOLD; //!< Over-voltage Comparison Voltage

bool dccBits_a[12] = {FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE}; //!< Discharge cell switch //Dcc 1,2,3,4,5,6,7,8,9,10,11,12

bool dctoBits[4] = {TRUE, FALSE, TRUE, FALSE}; //!< Discharge time value // Dcto 0,1,2,3 // Programed for 4 min 
/*Ensure that Dcto bits are set according to the required discharge time. Refer to the data sheet */

  uint16_t tCycle;

uint8_t  ScanNumDirB =0;          
uint8_t  ScanNumDirA =0;   	

void  Sacn_dev_fuction()
{
    		//��B�˿�ɨ��  XL8812������
		 Set_XL8812_DoubleDir(DIR_B);
		 wakeup_sleep(V82system.ICNum);
 #if  EN_DOUBLE_DIR	
		 ScanNumDirB=dev_scan_8812(V82system.ICNum) ;
	  	ScanNumDirA =  V82system.ICNum - ScanNumDirB;
			
		 	if(ScanNumDirB==V82system.ICNum)  
			{  
						Set_XL8812_DoubleDir(DIR_B);
						XL8812_demo_printf("DIR_B:%d\r\n",ScanNumDirB);
			}
		 else  if(ScanNumDirB==0)   
		 { 
				 Set_XL8812_DoubleDir(DIR_A);		
				 XL8812_demo_printf("DIR_A:%d\r\n",ScanNumDirA);
		 }
	    else if(ScanNumDirB<V82system.ICNum) // ɨ����С��ʵ�����ü�����Ŀ
			{
			      XL8812_demo_printf("DIR_B_num:%d -> DIR_A_num:%d\r\n",ScanNumDirB,ScanNumDirA); 
			}
		#else  
		      	ScanNumDirB=V82system.ICNum;
	#endif
}

void fuction_cells( )
{
int8_t error = 0;
if(ScanNumDirB==0 || ScanNumDirB==V82system.ICNum) //ɨ��Ϊ0 ��  ɨ��������ʵ�ʵ����ü�����Ŀ
		 {
					wakeup_sleep(V82system.ICNum);
					XL8812_adcv(ADC_CONVERSION_MODE,ADC_DCP,CELL_CH_TO_CONVERT); //CELL��ѹ���������·�

					tCycle=XL8812_get_measure_Tcycle(ADC_CONVERSION_MODE,CELL_CH_TO_CONVERT,ADCOPT);
					Delay_ms(tCycle);												//���������£��ӳ���Ҫ�����ӳ�δȷ��

					// Read Cell Voltage Registers
					wakeup_idle(V82system.ICNum);
					error = XL8812_rdcv(NO_OF_REG, V82system.ICNum,bms_ic); // CELL��ѹ��ȡ
					check_error(error);
		
		 }
		#if  EN_DOUBLE_DIR	
	else if(ScanNumDirB<V82system.ICNum) // ɨ����С��ʵ�����ü�����Ŀ
	{
	               	//�л�B�˿�
										Set_XL8812_DoubleDir(DIR_B);
										wakeup_sleep(ScanNumDirB);
										XL8812_adcv(ADC_CONVERSION_MODE,ADC_DCP,CELL_CH_TO_CONVERT); //CELL��ѹ���������·�

										tCycle=XL8812_get_measure_Tcycle(ADC_CONVERSION_MODE,CELL_CH_TO_CONVERT,ADCOPT);
										Delay_ms(tCycle);												//���������£��ӳ���Ҫ�����ӳ�δȷ��

										// Read Cell Voltage Registers
										wakeup_idle(ScanNumDirB);
										error = XL8812_rdcv(NO_OF_REG, ScanNumDirB,bms_ic); // CELL��ѹ��ȡ
										check_error(error);
					
				  	//�л�A�˿�
								ScanNumDirA =  V82system.ICNum-ScanNumDirB;
								Set_XL8812_DoubleDir(DIR_A);
							  wakeup_sleep(ScanNumDirA);
					
	              XL8812_adcv(ADC_CONVERSION_MODE,ADC_DCP,CELL_CH_TO_CONVERT); //CELL��ѹ���������·�

										tCycle=XL8812_get_measure_Tcycle(ADC_CONVERSION_MODE,CELL_CH_TO_CONVERT,ADCOPT);
										Delay_ms(tCycle);												//���������£��ӳ���Ҫ�����ӳ�δȷ��

										// Read Cell Voltage Registers
										wakeup_idle(ScanNumDirA);
										error = XL8812_rdcv(NO_OF_REG, ScanNumDirA,&bms_ic[ScanNumDirB]); // CELL��ѹ��ȡ
										check_error(error);
	}
	#endif
				print_cells();
}
void fuction_aux( )
{
int8_t error = 0;
	static U16 tCycle =0; ;
	static U8 convert_flag =0;
if(ScanNumDirB==0 || ScanNumDirB==V82system.ICNum) //ɨ��Ϊ0 ��  ɨ��������ʵ�ʵ����ü�����Ŀ
		 { 
  
			          if(convert_flag==0)
								{
				 
									wakeup_sleep(V82system.ICNum);
									XL8812_adax(ADC_CONVERSION_MODE, AUX_CH_TO_CONVERT);  //GPIO ��ѹ���������·�
									tCycle=XL8812_get_measure_Tcycle(ADC_CONVERSION_MODE,CELL_CH_TO_CONVERT,ADCOPT);	
									convert_flag =1;
								}
								else
								{ 
									if(tCycle==0)
									{
													// Read AUX Voltage Registers
										wakeup_idle(V82system.ICNum);
										error = XL8812_rdaux(NO_OF_REG,V82system.ICNum,bms_ic); // // GPIO��ѹ��ȡ
										check_error(error);
										wakeup_idle(V82system.ICNum);
										error = XL8812_rdaux(NO_OF_REG,V82system.ICNum,bms_ic); // // GPIO��ѹ��ȡ
										check_error(error);
									}
								}


			 
			          if(tCycle>10)
								{
								  tCycle=tCycle-10;
								}
								else
								{
								  tCycle=0;
								}


								
			}
	#if  EN_DOUBLE_DIR	
		else if(ScanNumDirB<V82system.ICNum) // ɨ����С��ʵ�����ü�����Ŀ
	 {
									//�л�B�˿�
								Set_XL8812_DoubleDir(DIR_B);
								wakeup_sleep(ScanNumDirB);

								XL8812_adax(ADC_CONVERSION_MODE, AUX_CH_TO_CONVERT);  //GPIO ��ѹ���������·�
								tCycle=XL8812_get_measure_Tcycle(ADC_CONVERSION_MODE,CELL_CH_TO_CONVERT,ADCOPT);
								Delay_ms(tCycle);												//���������£��ӳ���Ҫ�����ӳ�δȷ��

								// Read AUX Voltage Registers
								wakeup_idle(ScanNumDirB);
								error = XL8812_rdaux(NO_OF_REG,ScanNumDirB,bms_ic); // // GPIO��ѹ��ȡ
								check_error(error);

									//�л�A�˿�
								ScanNumDirA =  V82system.ICNum-ScanNumDirB;
								Set_XL8812_DoubleDir(DIR_A);
								wakeup_sleep(ScanNumDirA);
								XL8812_adax(ADC_CONVERSION_MODE, AUX_CH_TO_CONVERT);  //GPIO ��ѹ���������·�
								tCycle=XL8812_get_measure_Tcycle(ADC_CONVERSION_MODE,CELL_CH_TO_CONVERT,ADCOPT);
								Delay_ms(tCycle);												//���������£��ӳ���Ҫ�����ӳ�δȷ��

								// Read AUX Voltage Registers
								wakeup_idle(ScanNumDirA);
								error = XL8812_rdaux(NO_OF_REG,ScanNumDirA,&bms_ic[ScanNumDirB]); // // GPIO��ѹ��ȡ
								check_error(error);
							    
	}
	#endif
	     	//print_aux();
}
void fuction_stat() //�ڲ���������
{
  int8_t error = 0;
if(ScanNumDirB==0 || ScanNumDirB==V82system.ICNum) //ɨ��Ϊ0 ��  ɨ��������ʵ�ʵ����ü�����Ŀ
		{
									wakeup_sleep(V82system.ICNum);
									XL8812_adstat(ADC_CONVERSION_MODE, STAT_CH_TO_CONVERT);

									Delay_ms(150);												
									// Read Status registers
									wakeup_idle(V82system.ICNum);
									error = XL8812_rdstat(NO_OF_REG,V82system.ICNum,bms_ic); // 
									check_error(error);

		}
		
		#if  EN_DOUBLE_DIR	
		else if(ScanNumDirB<V82system.ICNum) // ɨ����С��ʵ�����ü�����Ŀ
		{
										//�л�B�˿�
										Set_XL8812_DoubleDir(DIR_B);
										wakeup_sleep(ScanNumDirB);

										XL8812_adstat(ADC_CONVERSION_MODE, STAT_CH_TO_CONVERT);

										Delay_ms(150);												
										// Read Status registers
										wakeup_idle(ScanNumDirB);
										error = XL8812_rdstat(NO_OF_REG,ScanNumDirB,bms_ic); // 
										check_error(error);


										//�л�A�˿�
										ScanNumDirA =  V82system.ICNum-ScanNumDirB;
										Set_XL8812_DoubleDir(DIR_A);
										wakeup_sleep(ScanNumDirA);
										XL8812_adstat(ADC_CONVERSION_MODE, STAT_CH_TO_CONVERT);

										Delay_ms(150);												
										// Read Status registers
										wakeup_idle(ScanNumDirA);
										error = XL8812_rdstat(NO_OF_REG,ScanNumDirA,&bms_ic[ScanNumDirB]); // 
										check_error(error);
		}
		#endif
											print_stat();
}
void fuction_statsc()
{
  int8_t error = 0;
 	if(ScanNumDirB==0 || ScanNumDirB==V82system.ICNum) //ɨ��Ϊ0 ��  ɨ��������ʵ�ʵ����ü�����Ŀ
				{
						wakeup_sleep(V82system.ICNum);
						XL8812_adcvsc(ADC_CONVERSION_MODE,ADC_DCP);
						
						tCycle=XL8812_get_measure_Tcycle(ADC_CONVERSION_MODE,CELL_CH_TO_CONVERT,ADCOPT);
						Delay_ms(100);			//���������£��ӳ���Ҫ�����ӳ�δȷ��
						wakeup_idle(V82system.ICNum);
						error = XL8812_rdcv(NO_OF_REG, V82system.ICNum,bms_ic); // Set to read back all cell voltage registers
						check_error(error);
		
						error = XL8812_rdstat(NO_OF_REG,V82system.ICNum,bms_ic); // 
						check_error(error);
		}
		#if  EN_DOUBLE_DIR	
		else if(ScanNumDirB<V82system.ICNum) // ɨ����С��ʵ�����ü�����Ŀ
		{
							//�л�B�˿�
							Set_XL8812_DoubleDir(DIR_B);
							wakeup_sleep(ScanNumDirB);
							XL8812_adcvsc(ADC_CONVERSION_MODE,ADC_DCP);

							tCycle=XL8812_get_measure_Tcycle(ADC_CONVERSION_MODE,CELL_CH_TO_CONVERT,ADCOPT);
							Delay_ms(100);			//���������£��ӳ���Ҫ�����ӳ�δȷ��
							wakeup_idle(ScanNumDirB);
							error = XL8812_rdcv(NO_OF_REG, ScanNumDirB,bms_ic); // Set to read back all cell voltage registers
							check_error(error);
							
							error = XL8812_rdstat(NO_OF_REG,ScanNumDirB,bms_ic); // 
							check_error(error);

							//�л�A�˿�
							ScanNumDirA =  V82system.ICNum-ScanNumDirB;
							Set_XL8812_DoubleDir(DIR_A);
							wakeup_sleep(ScanNumDirA);
							XL8812_adcvsc(ADC_CONVERSION_MODE,ADC_DCP);

							tCycle=XL8812_get_measure_Tcycle(ADC_CONVERSION_MODE,CELL_CH_TO_CONVERT,ADCOPT);
							Delay_ms(100);			//���������£��ӳ���Ҫ�����ӳ�δȷ��
							wakeup_idle(ScanNumDirA);
							error = XL8812_rdcv(NO_OF_REG, ScanNumDirA,&bms_ic[ScanNumDirB]); // Set to read back all cell voltage registers
							check_error(error);
							
							error = XL8812_rdstat(NO_OF_REG,ScanNumDirA,&bms_ic[ScanNumDirB]); // 
							check_error(error);			
		}
		#endif
					    print_cells();
							print_statsc();
}
void fuction_aux1()
{
         int8_t error = 0;
				if(ScanNumDirB==0 || ScanNumDirB==V82system.ICNum) //ɨ��Ϊ0 ��  ɨ��������ʵ�ʵ����ü�����Ŀ
				{
										wakeup_sleep(V82system.ICNum);
										XL8812_adcvax(ADC_CONVERSION_MODE,ADC_DCP);  // //CELL��ѹ���������GPIO ���������·�
										tCycle=XL8812_get_measure_Tcycle(ADC_CONVERSION_MODE,CELL_CH_TO_CONVERT,ADCOPT);
										Delay_ms(tCycle+6*V82system.ICNum);												//���������£��ӳ���Ҫ�����ӳ�δȷ��

										wakeup_idle(V82system.ICNum);
										error =XL8812_rdcv(NO_OF_REG, V82system.ICNum,bms_ic); // Set to read back all cell voltage registers
										check_error(error);
										error = XL8812_rdaux(NO_OF_REG,V82system.ICNum,bms_ic); // Set to read back all aux registers
										check_error(error);
										

					}
		#if  EN_DOUBLE_DIR	
				else if(ScanNumDirB<V82system.ICNum) // ɨ����С��ʵ�����ü�����Ŀ
				{
												//�л�B�˿�
												Set_XL8812_DoubleDir(DIR_B);
												wakeup_sleep(ScanNumDirB);
												
												XL8812_adcvax(ADC_CONVERSION_MODE,ADC_DCP);  // //CELL��ѹ���������GPIO ���������·�
												tCycle=XL8812_get_measure_Tcycle(ADC_CONVERSION_MODE,CELL_CH_TO_CONVERT,ADCOPT);
												Delay_ms(tCycle+6*ScanNumDirB);												//���������£��ӳ���Ҫ�����ӳ�δȷ��

												wakeup_idle(ScanNumDirB);
												error =XL8812_rdcv(NO_OF_REG, ScanNumDirB,bms_ic); // Set to read back all cell voltage registers
												check_error(error);
											 
												error = XL8812_rdaux(NO_OF_REG,ScanNumDirB,bms_ic); // Set to read back all aux registers
												check_error(error);

													//�л�A�˿�
												ScanNumDirA =  V82system.ICNum-ScanNumDirB;
												Set_XL8812_DoubleDir(DIR_A);
												wakeup_sleep(ScanNumDirA);
												XL8812_adcvax(ADC_CONVERSION_MODE,ADC_DCP);  // //CELL��ѹ���������GPIO ���������·�
												tCycle=XL8812_get_measure_Tcycle(ADC_CONVERSION_MODE,CELL_CH_TO_CONVERT,ADCOPT);
												Delay_ms(tCycle+6*ScanNumDirA);												//���������£��ӳ���Ҫ�����ӳ�δȷ��

												wakeup_idle(ScanNumDirA);
												error =XL8812_rdcv(NO_OF_REG, ScanNumDirA,&bms_ic[ScanNumDirB]); // Set to read back all cell voltage registers
												check_error(error);
							
												error = XL8812_rdaux(NO_OF_REG,ScanNumDirA,&bms_ic[ScanNumDirB]); // Set to read back all aux registers
												check_error(error);
				}
		#endif
									print_cells();    
									print_aux1();
}
void fuction_config()
{
 //  int8_t error = 0;
   if(ScanNumDirB==0 || ScanNumDirB==V82system.ICNum) //ɨ��Ϊ0 ��  ɨ��������ʵ�ʵ����ü�����Ŀ
		 {
	     	  wakeup_sleep(V82system.ICNum);
					XL8812_wrcfg(V82system.ICNum,bms_ic);  //д���üĴ���			
				}
				#if  EN_DOUBLE_DIR	
				else if(ScanNumDirB<V82system.ICNum) // ɨ����С��ʵ�����ü�����Ŀ
				{
					  //�л�B�˿�
							Set_XL8812_DoubleDir(DIR_B);
							wakeup_sleep(ScanNumDirB);
							XL8812_wrcfg(ScanNumDirB,bms_ic);  //д���üĴ���

          	//�л�A�˿�
							Set_XL8812_DoubleDir(DIR_A);
							wakeup_sleep(ScanNumDirA);
							XL8812_wrcfg(ScanNumDirA,&bms_ic[ScanNumDirB]);  //д���üĴ���
				}
				#endif
				print_config();
}
void fuction_rxconfig()
{
         int8_t error = 0;
    	  if(ScanNumDirB==0 || ScanNumDirB==V82system.ICNum) //ɨ��Ϊ0 ��  ɨ��������ʵ�ʵ����ü�����Ŀ
		  {
							wakeup_sleep(V82system.ICNum);
							error = XL8812_rdcfg(V82system.ICNum,bms_ic); // ��ȡ���üĴ���
							check_error(error);
				}
				#if  EN_DOUBLE_DIR	
				else if(ScanNumDirB<V82system.ICNum) // ɨ����С��ʵ�����ü�����Ŀ
				{
										//�л�B�˿�
										Set_XL8812_DoubleDir(DIR_B);
										wakeup_sleep(ScanNumDirB);
										error = XL8812_rdcfg(ScanNumDirB,bms_ic); // ��ȡ���üĴ���
										check_error(error);

										//�л�A�˿�
										Set_XL8812_DoubleDir(DIR_A);
										wakeup_sleep(ScanNumDirA);
										error = XL8812_rdcfg(ScanNumDirA,&bms_ic[ScanNumDirB]); // ��ȡ���üĴ���
										check_error(error);
				}
				#endif
				print_rxconfig();
}
void fuction_diagn()
{
    int8_t error = 0;
    if(ScanNumDirB==0 || ScanNumDirB==V82system.ICNum) //ɨ��Ϊ0 ��  ɨ��������ʵ�ʵ����ü�����Ŀ
		 {
										wakeup_sleep(V82system.ICNum);
										XL8812_diagn();
										Delay_ms(2);
										wakeup_idle(V82system.ICNum);
										error = XL8812_rdstat(NO_OF_REG,V82system.ICNum,bms_ic); // Set to read back all aux registers
										check_error(error);			
				}
				#if  EN_DOUBLE_DIR	
				else if(ScanNumDirB<V82system.ICNum) // ɨ����С��ʵ�����ü�����Ŀ
				{
				           	//�л�B�˿�
										Set_XL8812_DoubleDir(DIR_B);
										wakeup_sleep(ScanNumDirB);
										XL8812_diagn();
										Delay_ms(3);
										wakeup_idle(ScanNumDirB);
										error = XL8812_rdstat(NO_OF_REG,ScanNumDirB,bms_ic); // Set to read back all aux registers
										check_error(error);


	                 //�л�A�˿�
										Set_XL8812_DoubleDir(DIR_A);
										wakeup_sleep(ScanNumDirA);
										XL8812_diagn();
										Delay_ms(3);
										wakeup_idle(ScanNumDirA);
										error = XL8812_rdstat(NO_OF_REG,ScanNumDirA,&bms_ic[ScanNumDirB]); // Set to read back all aux registers
										check_error(error);
						}
		#endif	
		  XL8812_demo_printf("DIAGN  conversion completed in: ");
			for (int ic = 0; ic<V82system.ICNum; ic++)
										{ 
													error = 0;
													XL8812_demo_printf(" IC %d:",ic+1);
													if (bms_ic[ic].stat.mux_fail[0] != 0) error++;

													if (error==0) XL8812_demo_printf("Mux Test: PASS  [mux_fail:%d]\r\n",error);
													else                  XL8812_demo_printf("Mux Test: FAIL :  [mux_fail:%d]\r\n",error);
							    }
}

void fuction_MemorySelfTest()
{
      int8_t error= 0;
    if(ScanNumDirB==0 || ScanNumDirB==V82system.ICNum) //ɨ��Ϊ0 ��  ɨ��������ʵ�ʵ����ü�����Ŀ
		 {
							wakeup_sleep(V82system.ICNum);
						error = XL8812_run_cell_adc_st(CELL,V82system.ICNum,bms_ic, ADC_CONVERSION_MODE, ADCOPT);
						
						XL8812_demo_printf("%d",error);
						XL8812_demo_printf(" : errors detected in Digital Filter and CELL Memory \n");

						wakeup_sleep(V82system.ICNum);
						error = XL8812_run_cell_adc_st(AUX,V82system.ICNum, bms_ic, ADC_CONVERSION_MODE, ADCOPT);
						XL8812_demo_printf("%d",error);
						XL8812_demo_printf(" : errors detected in Digital Filter and AUX Memory \n");

						wakeup_sleep(V82system.ICNum);
						error = XL8812_run_cell_adc_st(STAT,V82system.ICNum, bms_ic, ADC_CONVERSION_MODE, ADCOPT);
						XL8812_demo_printf("%d",error);
						XL8812_demo_printf(" : errors detected in Digital Filter and STAT Memory \n");
		}
		#if  EN_DOUBLE_DIR	
		else if(ScanNumDirB<V82system.ICNum) // ɨ����С��ʵ�����ü�����Ŀ
			{
								//�л�B�˿�
								Set_XL8812_DoubleDir(DIR_B);
								wakeup_sleep(ScanNumDirB);    
              	error = XL8812_run_cell_adc_st(CELL,ScanNumDirB,bms_ic, ADC_CONVERSION_MODE, ADCOPT);

								XL8812_demo_printf("DIR_B:%d",error);
								XL8812_demo_printf(" : errors detected in Digital Filter and CELL Memory \n");

								wakeup_sleep(ScanNumDirB);
								error = XL8812_run_cell_adc_st(AUX,ScanNumDirB, bms_ic, ADC_CONVERSION_MODE, ADCOPT);
								XL8812_demo_printf("DIR_B:%d",error);
								XL8812_demo_printf(" : errors detected in Digital Filter and AUX Memory \n");

								wakeup_sleep(ScanNumDirB);
								error = XL8812_run_cell_adc_st(STAT,ScanNumDirB, bms_ic, ADC_CONVERSION_MODE, ADCOPT);
								XL8812_demo_printf("DIR_B:%d",error);
								XL8812_demo_printf(" : errors detected in Digital Filter and STAT Memory \n");
								
								//�л�A�˿�
								Set_XL8812_DoubleDir(DIR_A);
								wakeup_sleep(ScanNumDirA);
								error = XL8812_run_cell_adc_st(CELL,ScanNumDirA,&bms_ic[ScanNumDirB], ADC_CONVERSION_MODE, ADCOPT);

								XL8812_demo_printf("DIR_A:%d",error);
								XL8812_demo_printf(" : errors detected in Digital Filter and CELL Memory \n");

								wakeup_sleep(ScanNumDirB);
								error = XL8812_run_cell_adc_st(AUX,ScanNumDirA, &bms_ic[ScanNumDirB], ADC_CONVERSION_MODE, ADCOPT);
								XL8812_demo_printf("DIR_A:%d",error);
								XL8812_demo_printf(" : errors detected in Digital Filter and AUX Memory \n");

								wakeup_sleep(ScanNumDirB);
								error = XL8812_run_cell_adc_st(STAT,ScanNumDirA, &bms_ic[ScanNumDirB], ADC_CONVERSION_MODE, ADCOPT);
								XL8812_demo_printf("DIR_A:%d",error);
								XL8812_demo_printf(" : errors detected in Digital Filter and STAT Memory \n");
			}
			#endif
}

void   fuction_ADC_Overlapselftest()
{
     int8_t error = 0;
    if(ScanNumDirB==0 || ScanNumDirB==V82system.ICNum) //ɨ��Ϊ0 ��  ɨ��������ʵ�ʵ����ü�����Ŀ
		 {
						wakeup_sleep(V82system.ICNum);
						error = (int8_t)XL8812_run_adc_overlap(V82system.ICNum,bms_ic); //��������
						
						//  ��ӡ��Ϣ
						for (int ic = 0; ic<V82system.ICNum; ic++)
						{
					      	XL8812_demo_printf("%d,%d\r\n",bms_ic[ic].cells.c_codes[6],bms_ic[ic].cells.c_codes[7]);
						}
						if (error==0) XL8812_demo_printf("\r\nOverlap Test: PASS ");
						else XL8812_demo_printf("\r\nOverlap Test: FAIL");
		}
		
		#if  EN_DOUBLE_DIR	
		else if(ScanNumDirB<V82system.ICNum) // ɨ����С��ʵ�����ü�����Ŀ
		{
								//�л�B�˿�
							Set_XL8812_DoubleDir(DIR_B);
							wakeup_sleep(ScanNumDirB);    
							error = (int8_t)XL8812_run_adc_overlap(ScanNumDirB,bms_ic); //��������
							
								//  ��ӡ��Ϣ
							for (int ic = 0; ic<ScanNumDirB; ic++)
							{
							          XL8812_demo_printf("\r\nDIR_B:%d,%d",bms_ic[ic].cells.c_codes[6],bms_ic[ic].cells.c_codes[7]);
							}
							if (error==0) XL8812_demo_printf("\r\nOverlap Test: PASS ");
							else XL8812_demo_printf("\r\nOverlap Test: FAIL");
								
             	//�л�A�˿�
							Set_XL8812_DoubleDir(DIR_A);
							wakeup_sleep(ScanNumDirA);
							error = (int8_t)XL8812_run_adc_overlap(ScanNumDirA,&bms_ic[ScanNumDirB]); //��������
							
							//  ��ӡ��Ϣ
							for (int ic = ScanNumDirA; ic<V82system.ICNum; ic++)
							{
							    XL8812_demo_printf("\r\nDIR_A:%d,%d",bms_ic[ic].cells.c_codes[6],bms_ic[ic].cells.c_codes[7]);
							}
							if (error==0) XL8812_demo_printf("\r\nOverlap Test: PASS ");
							else XL8812_demo_printf("\r\nOverlap Test: FAIL");
		}
     #endif  
}

void    fuction_ADC_Redundancyselftest()
{
    int8_t error = 0;
    if(ScanNumDirB==0 || ScanNumDirB==V82system.ICNum) //ɨ��Ϊ0 ��  ɨ��������ʵ�ʵ����ü�����Ŀ
		 {
				wakeup_sleep(V82system.ICNum);
      error = XL8812_run_adc_redundancy_st(ADC_CONVERSION_MODE,AUX,V82system.ICNum, bms_ic);
      XL8812_demo_printf("%d",error);
      XL8812_demo_printf(" : errors detected in AUX Measurement \n");

      wakeup_sleep(V82system.ICNum);
      error = XL8812_run_adc_redundancy_st(ADC_CONVERSION_MODE,STAT,V82system.ICNum, bms_ic);
       XL8812_demo_printf("%d",error);
       XL8812_demo_printf(" : errors detected in STAT Measurement \n");
		}
		
		#if  EN_DOUBLE_DIR	
		else if(ScanNumDirB<V82system.ICNum) // ɨ����С��ʵ�����ü�����Ŀ
		{
							//�л�B�˿�
						Set_XL8812_DoubleDir(DIR_B);
						wakeup_sleep(ScanNumDirB);    

						error = XL8812_run_adc_redundancy_st(ADC_CONVERSION_MODE,AUX,ScanNumDirB, bms_ic);
						XL8812_demo_printf("\r\nDIR_B:%d",error);
						XL8812_demo_printf(" : errors detected in AUX Measurement \n");

						wakeup_sleep(ScanNumDirB);
						error = XL8812_run_adc_redundancy_st(ADC_CONVERSION_MODE,STAT,ScanNumDirB, bms_ic);
						XL8812_demo_printf("\r\nDIR_B:%d",error);
						XL8812_demo_printf(" : errors detected in STAT Measurement \n");
						
							//�л�A�˿�
						Set_XL8812_DoubleDir(DIR_A);
						wakeup_sleep(ScanNumDirA);    

						error = XL8812_run_adc_redundancy_st(ADC_CONVERSION_MODE,AUX,ScanNumDirA, &bms_ic[ScanNumDirB]);
						XL8812_demo_printf("\r\nDIR_A:%d",error);
						XL8812_demo_printf(" : errors detected in AUX Measurement \n");

						wakeup_sleep(ScanNumDirA);
						error = XL8812_run_adc_redundancy_st(ADC_CONVERSION_MODE,STAT,ScanNumDirA, &bms_ic[ScanNumDirB]);
						XL8812_demo_printf("\r\nDIR_A:%d",error);
						XL8812_demo_printf(" : errors detected in STAT Measurement \n");
		}
     #endif  

}
void fuction_openwire_multi()
{
 
    if(ScanNumDirB==0 || ScanNumDirB==V82system.ICNum) //ɨ��Ϊ0 ��  ɨ��������ʵ�ʵ����ü�����Ŀ
		 {
						wakeup_sleep(V82system.ICNum);         
             XL8812_run_openwire_multi(V82system.ICNum, bms_ic,bms_ic[0].ic_reg.cell_channels);
		}
		#if  EN_DOUBLE_DIR	
		else if(ScanNumDirB<V82system.ICNum) // ɨ����С��ʵ�����ü�����Ŀ
		{
						//�л�B�˿�
					Set_XL8812_DoubleDir(DIR_B);
					wakeup_sleep(ScanNumDirB);    
					XL8812_run_openwire_multi(ScanNumDirB, bms_ic,bms_ic[0].ic_reg.cell_channels);

       	//�л�A�˿�
					Set_XL8812_DoubleDir(DIR_A);
					wakeup_sleep(ScanNumDirA);
					XL8812_run_openwire_multi(ScanNumDirA, &bms_ic[ScanNumDirB],bms_ic[ScanNumDirB].ic_reg.cell_channels);
		} 
#endif		
}

void  fuction_ClrallADCmeasurementReg()
{
//      int8_t error = 0;
   if(ScanNumDirB==0 || ScanNumDirB==V82system.ICNum) //ɨ��Ϊ0 ��  ɨ��������ʵ�ʵ����ü�����Ŀ
		 {
										wakeup_sleep(V82system.ICNum);
										XL8812_clrcell();
										XL8812_clraux();
										XL8812_clrstat();
										XL8812_demo_printf("All Registers Cleared");

				}
	#if  EN_DOUBLE_DIR	
				else if(ScanNumDirB<V82system.ICNum) // ɨ����С��ʵ�����ü�����Ŀ
				{
									//�л�B�˿�
									Set_XL8812_DoubleDir(DIR_B);
									wakeup_sleep(ScanNumDirB);
									XL8812_clrcell();
									XL8812_clraux();
									XL8812_clrstat();

									//�л�A�˿�
									Set_XL8812_DoubleDir(DIR_A);
									wakeup_sleep(ScanNumDirA);
									XL8812_clrcell();
									XL8812_clraux();
									XL8812_clrstat();
				}
		#endif
//					fuction_cells();		 
//					fuction_aux();
//					fuction_stat();
}
/*!*********************************
  \brief For Loop Measurement
 @return void
***********************************/
void measurement_loop()
{
//  int8_t error = 0;
  if (WRITE_CONFIG == ENABLED)
  {
     fuction_config();
  }

  if (READ_CONFIG == ENABLED)
  {
     fuction_rxconfig();
  }

  if (MEASURE_CELL == ENABLED)
  {
       fuction_cells();
  }

  if (MEASURE_AUX == ENABLED)
  {
       fuction_aux( );//GPIO  ��ѹ����ָ�� 0x04
  }

  if (MEASURE_STAT == ENABLED)
  {
      fuction_stat();//�ڲ���������
  }
  if (PRINT_PEC == ENABLED)
  {
    
  }
}



/*!*********************************
  \brief Prints the main menu
 @return void
***********************************/
void print_menu()
{
  XL8812_demo_printf("Please enter command: \r\n");
}

/*!******************************************************************************
 \brief Prints the configuration data that is going to be written to the XL8812
 to the serial port.
 @return void
 ********************************************************************************/
void print_config()
{
  int cfg_pec;

  XL8812_demo_printf("Written Configuration:\r\n ");
  for (int current_ic = 0; current_ic<V82system.ICNum; current_ic++)
  {
		XL8812_demo_printf("  IC%d:",current_ic+1);
		XL8812_demo_printf("0x%02x",bms_ic[current_ic].config.tx_data[0]);
		XL8812_demo_printf(",0x%02x",bms_ic[current_ic].config.tx_data[1]);
		XL8812_demo_printf(",0x%02x",bms_ic[current_ic].config.tx_data[2]);
		XL8812_demo_printf(",0x%02x",bms_ic[current_ic].config.tx_data[3]);
		XL8812_demo_printf(",0x%02x",bms_ic[current_ic].config.tx_data[4]);
		XL8812_demo_printf(",0x%02x",bms_ic[current_ic].config.tx_data[5]);
		XL8812_demo_printf(", Calculated PEC: ");
    cfg_pec = pec15_calc(6,&bms_ic[current_ic].config.tx_data[0]);
    XL8812_demo_printf("0x%02x",(uint8_t)(cfg_pec>>8));
   	XL8812_demo_printf(",0x%02x",(uint8_t)(cfg_pec&0xff));
		XL8812_demo_printf("\r\n");
  }
}

/*!*****************************************************************
 \brief Prints the configuration data that was read back from the
 XL8812 to the serial port.
  @return void
 *******************************************************************/
void print_rxconfig()
{
  XL8812_demo_printf("Received Configuration:\r\n ");
  for (int current_ic=0; current_ic<V82system.ICNum; current_ic++)
  {
    XL8812_demo_printf("  IC%d:",current_ic+1);
		XL8812_demo_printf("0x%02x",bms_ic[current_ic].config.rx_data[0]);
		XL8812_demo_printf(",0x%02x",bms_ic[current_ic].config.rx_data[1]);
		XL8812_demo_printf(",0x%02x",bms_ic[current_ic].config.rx_data[2]);
		XL8812_demo_printf(",0x%02x",bms_ic[current_ic].config.rx_data[3]);
		XL8812_demo_printf(",0x%02x",bms_ic[current_ic].config.rx_data[4]);
		XL8812_demo_printf(",0x%02x",bms_ic[current_ic].config.rx_data[5]);
	
    XL8812_demo_printf(", Received PEC: 0x");
    XL8812_demo_printf("0x%02x",bms_ic[current_ic].config.rx_data[6]);
		XL8812_demo_printf(",0x%02x",bms_ic[current_ic].config.rx_data[7]);
		XL8812_demo_printf("\r\n");
  }
}

/*!************************************************************
  \brief Prints cell voltage to the serial port
   @return void
 *************************************************************/
void print_cells( )
{
int current_ic;
int i;
   for ( current_ic= 0 ; current_ic < V82system.ICNum; current_ic++)
  {
       XL8812_demo_printf(" IC%d:  \r\n",current_ic+1);
      for (i=0; i<bms_ic[0].ic_reg.cell_channels; i++)
      {
				XL8812_demo_printf("C%d:",i+1);
				XL8812_demo_printf("%d ,",bms_ic[current_ic].cells.c_codes[i]);    
      }
			XL8812_demo_printf("\r\n");
  }
}

/*!****************************************************************************
  \brief Prints GPIO voltage codes and Vref2 voltage code onto the serial port
 @return void
 *****************************************************************************/
void print_aux( )
{
int current_ic ;
int i;
uint32_t  Vref2,multi_result,temp;
  for (current_ic=0 ; current_ic < V82system.ICNum; current_ic++)
  {
  
       XL8812_demo_printf("  \r\nIC%d:\r\n",current_ic+1);
      for (i=0; i < 5; i++)
      {
        XL8812_demo_printf(" GPIO-%d:",i+1);
       	XL8812_demo_printf(" %d,",bms_ic[current_ic].aux.a_codes[i]);    
      }
      XL8812_demo_printf(" Vref2:");
  	  XL8812_demo_printf(" %d,\r\n",bms_ic[current_ic].aux.a_codes[5]);    
     for (i=0; i < 3; i++)
      {
        Vref2=bms_ic[current_ic].aux.a_codes[5];
				temp=bms_ic[current_ic].aux.a_codes[i];
				multi_result = temp * 10000;									//R*V�ĳ˻�
				
				if(Vref2==temp)  	temp = Vref2 -500;	  //��ֹ����Ϊ 0 
		  	temp = (uint32_t) (multi_result/(Vref2-temp));                  
       	XL8812_demo_printf(" GPIO-%d: %d   ",i+1,(int16_t)(XL8812_Convert_MuxVoltages_to_Temperatures(temp)));          //����ֵ��Ϊ���룬���������¶�ֵ
      }
    }
 
			XL8812_demo_printf("\r\n");
  
}

/*!****************************************************************************
  \brief Prints GPIO voltage codes (GPIO 1 & 2)
 @return void
 *****************************************************************************/
void print_aux1( )
{
//int i;
int current_ic ;
  for (current_ic=0 ; current_ic < V82system.ICNum; current_ic++)
  {
    
      XL8812_demo_printf("  \r\nIC%d:\r\n",current_ic+1);
      for (int i=0; i < 2; i++)
      {
				 XL8812_demo_printf(" GPIO-%d:",i+1);
       	XL8812_demo_printf(" %d,",bms_ic[current_ic].aux.a_codes[i]);    
       
      }
			XL8812_demo_printf("\r\n");
  }
}

/*!****************************************************************************
  \brief Prints Status voltage codes and Vref2 voltage code onto the serial port
 @return void
 *****************************************************************************/
void print_stat()
{
   double ITMP;
	 uint8_t current_ic ;
  for (current_ic=0 ; current_ic < V82system.ICNum; current_ic++)
  {
     XL8812_demo_printf("  \r\nIC%d:",current_ic+1);
    XL8812_demo_printf(" SC:");
		XL8812_demo_printf(" %.4f , ",bms_ic[current_ic].stat.stat_codes[0]*0.0001*20);    
  
    XL8812_demo_printf(" Itemp:");
    ITMP = (double)((bms_ic[current_ic].stat.stat_codes[1] * (0.0001 / 0.0068)) - 273);   //Internal Die Temperature(��C) = ITMP ? (100 ��V / 7.5mV)��C - 273��C
   	XL8812_demo_printf(" %.4f , ",ITMP);    

    XL8812_demo_printf(" VregA:");
		XL8812_demo_printf(" %.4f , ",bms_ic[current_ic].stat.stat_codes[2]*0.0001);    
			
    XL8812_demo_printf(" VregD:");
		XL8812_demo_printf(" %.4f , ",bms_ic[current_ic].stat.stat_codes[3]*0.0001);    
    XL8812_demo_printf("\r\n");
    XL8812_demo_printf(" Flags:");
  	XL8812_demo_printf(" %02x , ",bms_ic[current_ic].stat.flags[0]);    
    XL8812_demo_printf("  %02x , ",bms_ic[current_ic].stat.flags[1]);    
    XL8812_demo_printf("  %02x  ",bms_ic[current_ic].stat.flags[2]);  
    XL8812_demo_printf("   Mux fail flag:");

		XL8812_demo_printf("  %02x  ",bms_ic[current_ic].stat.mux_fail[0]);  
		
   XL8812_demo_printf("   THSD:");
   XL8812_demo_printf("0x%02x",bms_ic[current_ic].stat.thsd[0]);
  	XL8812_demo_printf("\r\n");
}
}
/*!****************************************************************************
  \brief Prints Status voltage codes for SC onto the serial port
 @return void
 *****************************************************************************/
void print_statsc()
{
 for (int current_ic =0 ; current_ic < V82system.ICNum; current_ic++)
  {
    	XL8812_demo_printf(" IC%d:",current_ic+1);
      XL8812_demo_printf("SC:");
      XL8812_demo_printf("%04f,",bms_ic[current_ic].stat.stat_codes[0]*0.0001*20);
  }

}


/*!************************************************************
  \brief Function to check error flag and print PEC error message
  @return void
 *************************************************************/ 
void check_error(int error)
{
  if (error != 0)
  {
      XL8812_demo_printf("\r\nA PEC error was detected in the received data\r\n");
  }
}

/*!************************************************************
 \brief Read a command from the serial port
 @return char 
 *************************************************************/
char get_char()
{
  char  getData;
  while (myUART_RecvByte(&getData)==u_Error);
  return  getData;
}

/*******************************************************************************************************
********************************************************************************************************
********************************************************************************************************
********************************************************************************************************/
uint16_t XL8812_get_measure_Tcycle(uint8_t MD, uint8_t CH_or_GPIO, uint8_t ADCOPT)
{
    uint16_t retVal = XL8812_MEAS_ALL_NORMAL_TCYCLE;  /* default */
    if((CH_or_GPIO == CELL_CH_ALL)&&(ADCOPT == ADC_OPT_ENABLED))       		//����ͨ����ADCOPT = 1
	{
		switch(MD)
		{
		case MD_422HZ_1KHZ:
			retVal = XL8812_MEAS_ALL_1KHZ_TCYCLE;
			break;
		case MD_27KHZ_14KHZ:
			retVal = XL8812_MEAS_ALL_14KHZ_TCYCLE;
			break;
		case MD_7KHZ_3KHZ:
			retVal = XL8812_MEAS_ALL_3KHZ_TCYCLE;
			break;
		case MD_26HZ_2KHZ:
			retVal = XL8812_MEAS_ALL_2KHZ_TCYCLE;
			break;		
		}
    }
	else if((CH_or_GPIO == CELL_CH_ALL)&&(ADCOPT == ADC_OPT_DISABLED))		//����ͨ����ADCOPT = 0
	{
		switch(MD)
		{
		case MD_422HZ_1KHZ:
			retVal = XL8812_MEAS_ALL_422HZ_TCYCLE;
			break;
		case MD_27KHZ_14KHZ:
			retVal = XL8812_MEAS_ALL_FAST_TCYCLE;
			break;
		case MD_7KHZ_3KHZ:
			retVal = XL8812_MEAS_ALL_NORMAL_TCYCLE;
			break;
		case MD_26HZ_2KHZ:
			retVal = XL8812_MEAS_ALL_FILTERED_TCYCLE;
			break;		
		}	
	}
	else if(ADCOPT == ADC_OPT_ENABLED)										//˫ͨ����ADCOPT = 1
    {
		switch(MD)
		{
		case MD_422HZ_1KHZ:
			retVal = XL8812_MEAS_SINGLE_1KHZ_TCYCLE;
			break;
		case MD_27KHZ_14KHZ:
			retVal = XL8812_MEAS_SINGLE_14KHZ_TCYCLE;
			break;
		case MD_7KHZ_3KHZ:
			retVal = XL8812_MEAS_SINGLE_3KHZ_TCYCLE;
			break;
		case MD_26HZ_2KHZ:
			retVal = XL8812_MEAS_SINGLE_2KHZ_TCYCLE;
			break;		
		}

    }else																	//˫ͨ����ADCOPT = 0
    {
		switch(MD)
		{
		case MD_422HZ_1KHZ:
			retVal = XL8812_MEAS_SINGLE_422HZ_TCYCLE;
			break;
		case MD_27KHZ_14KHZ:
			retVal = XL8812_MEAS_SINGLE_FAST_TCYCLE;
			break;
		case MD_7KHZ_3KHZ:
			retVal = XL8812_MEAS_SINGLE_NORMAL_TCYCLE;
			break;
		case MD_26HZ_2KHZ:
			retVal = XL8812_MEAS_SINGLE_FILTERED_TCYCLE;
			break;		
		}   
    }

    return retVal;
}

/***************************************************
                  XL8812   ɨ�輶����Ŀ
***************************************************/
/* dev_scan_8812 */
uint8_t  dev_scan_8812(uint8_t total_ic//Number of ICs in the system
                 )
{
	const uint8_t BYTES_IN_REG = 8;
	uint8_t cmd[4];
	uint8_t data[8*MAX_XL8812_IC];
	int8_t pec_error = 0;
	uint16_t cmd_pec;
	uint16_t data_pec;
	uint16_t received_pec;
	uint8_t current_byte;
  uint8_t current_ic;
	uint8_t  dev_scan_8812_num=0;
		
	cmd[0] = 0x00;
	cmd[1] = 0x02;
	cmd_pec = pec15_calc(2, cmd);
	cmd[2] = (uint8_t)(cmd_pec >> 8);
	cmd[3] = (uint8_t)(cmd_pec);
	
	spi_write_read(cmd, 4, data, (BYTES_IN_REG*total_ic));         //Transmits the command and reads the configuration data of all ICs on the daisy chain into rx_data[] array
                                   
	for (current_ic = 0; current_ic < total_ic; current_ic++) //Executes for each XL881x in the daisy chain and packs the data
	{										
	  	received_pec = (data[(current_ic*8)+6]<<8) + data[(current_ic*8)+7];
		 data_pec = pec15_calc(6, &data[current_ic*8]);
			if (received_pec != data_pec)
			{
				break ;
			}
			else
			{
				 dev_scan_8812_num++;
			}
	}
	
	return( dev_scan_8812_num);
}


/*
        GPIO  ��ѹֵ ת�����¶�
*/

const int32_t Temperature_table[206][2]={
    {-55,961580},{-54,903048},{-53,844516},{-52,785984},{-51,727452},
    {-50,668920},{-49,629390},{-48,589860},{-47,550330},{-46,510800},
    {-45,471270},{-44,444228},{-43,417186},{-42,390144},{-41,363102},
    {-40,336060},{-39,317334},{-38,298608},{-37,279882},{-36,261156},
    {-35,242430},{-34,229306},{-33,216182},{-32,203058},{-31,189934},
    {-30,176810},{-29,167512},{-28,158214},{-27,148916},{-26,139618},
    {-25,130320},{-24,123660},{-23,117000},{-22,110340},{-21,103680},
    {-20,97020},{-19,92199},{-18,87380},{-17,82561},{-16,77742},
    {-15,72923},{-14,69402},{-13,65880},{-12,62358},{-11,58836},
    {-10,55314},{-9,52717},{-8,50119},{-7,47521},{-6,44923},
    {-5,42325},{-4,40389},{-3,38456},{-2,36523},{-1,34590},
    {0,  32657 },  {1, 31204 },   {2, 29753 },   {3,  28302},   {4,26851},
    {5, 25400 },   {6,  24299},   {7, 23201 },   {8, 22103 },   {9, 21005 },
    {10, 19907},   {11, 19068 },   {12, 18230},   {13, 17392},   {14,16554 },
    {15, 15716},{16, 15070},{17, 14426},{18,13782 },{19, 13138},
    {20, 12494},{21, 11996},{22, 11497},{23,10998 },{24, 10499},
    {25, 10000},{26, 9611},{27, 9222},{28, 8833},{29, 8444},
    {30, 8055},{31,7748 },{32, 7443},{33, 7138},{34, 6833},
    {35, 6528},{36, 6366},{37,6105 },{38, 5844},{39, 5583},
    {40, 5322},{41, 5129},{42, 4937},{43, 4746},{44,4555 },
    {45, 4364},{46, 4210},{47, 4057},{48, 3904},{49, 3751},
    {50, 3598},{51, 3474},{52, 3351},{53, 3228},{54, 3105},
    {55, 2982},{56, 2883},{57, 2783},{58, 2683},{59, 2583},
    {60, 2483},{61, 2402},{62, 2321},{63, 2240},{64, 2159},
    {65, 2078},{66, 2012},{67, 1946},{68, 1880},{69, 1814},
    {70, 1748},{71, 1693},{72, 1638},{73, 1584},{74, 1530},
    {75, 1476},{76, 1432},{77, 1387},{78, 1342},{79, 1297},
    {80, 1252},{81, 1215},{82, 1178},{83, 1141},{84, 1104},
    {85, 1067},{86, 1036},{87, 1005},{88, 974},{89, 943},
    {90, 912},{91, 887},{92, 861},{93, 835},{94, 809},
    {95, 783},{96,762 },{97, 740},{98, 718},{99, 696},
    {100,674},{101,655},{102,637},{103,619},{104,601},
    {105,583},{106,567},{107,551},{108,536},{109,521},
    {110,506},{111,493},{112,480},{113,467},{114,454},
    {115,441},{116,429},{117,418},{118,407},{119,396},
    {120,385},{121,375},{122,365},{123,355},{124,346},
    {125,337},{126,328},{127,320},{128,312},{129,304},
    {130,296},{131,289},{132,282},{133,275},{134,268},
    {135,261},{136,255},{137,249},{138,243},{139,237},
    {140,231},{141,225},{142,219},{143,214},{144,209},
    {145,204},{146,199},{147,194},{148,190},{149,186},
    {150,182}
};


/*================== Function Implementations =============================*/
int16_t    XL8812_Convert_MuxVoltages_to_Temperatures(uint32_t r_val) {
	uint8_t low_b = 0;
	uint8_t high_b = (uint8_t)(sizeof(Temperature_table)/sizeof(Temperature_table[0]));
	uint8_t mid = (uint8_t)(sizeof(Temperature_table)/sizeof(Temperature_table[0])/2);
	
	while(low_b <= high_b)
	{
		if ((Temperature_table[mid][1] >= r_val) && (r_val > Temperature_table[mid+1][1]))
		{
			return (int16_t)Temperature_table[mid][0];
		}
		else if(r_val >= Temperature_table[0][1])
		{
			return (int16_t)Temperature_table[0][0];		//����-55��C
		}
		else if ( r_val <= (Temperature_table[ (sizeof(Temperature_table) / sizeof(Temperature_table[0])) - 1][1]))
		{
			return (int16_t)Temperature_table[sizeof(Temperature_table) / sizeof(Temperature_table[0]) - 1][0];		//����150��C
		}
		else if ( r_val > Temperature_table[mid + 1][1] )
		{
			high_b = mid - 1;
			mid = (low_b + high_b) / 2;
		}
		else
		{
			low_b = mid + 1;
			mid = (low_b + high_b) / 2;
		}
	}
}

 






/*!**********************************************************************
 \brief  Initializes hardware and variables
 @return void
 ***********************************************************************/
void demo_init()
{
		XL8812_init_cfg(V82system.ICNum, bms_ic);//��ʼ�� bms_ic �ṹ�����
		XL8812_init_reg_limits(V82system.ICNum,bms_ic);//���ò��� ֧������о������GPIO ������״̬�Ĵ�������
		 
		for (uint8_t current_ic = 0; current_ic<V82system.ICNum;current_ic++) 
		{
					XL8812_set_cfgr(current_ic,bms_ic,REFON,ADCOPT,gpioBits_a,dccBits_a, dctoBits, UV, OV);//���üĴ��� A ����(����:����ģʽ�����⿪�ص�)
		}

		XL8812_demo_printf("*******************     V82system.ICNum:%d      ************************ \r\n",V82system.ICNum);
		 Set_XL8812_DoubleDir(DIR_B);
		 Delay_ms(2);
		wakeup_sleep(V82system.ICNum);
		 ScanNumDirB=dev_scan_8812(V82system.ICNum) ;//ɨ�� B ������ XL8812 �豸���������ʵ�ʼ�����
		XL8812_demo_printf("***DIR_B_PORT-->dev_scan_num:%d      ************************ \r\n",ScanNumDirB);

		print_menu();
	
//		XL8812_demo_printf("***cell_asic:%d Byte   ************************ \r\n",sizeof(cell_asic));
}

/*!*****************************************
 \brief Executes the user command
 @return void
*******************************************/
void run_command(uint8_t cmd)
{
  const uint8_t STREG=0;
  int8_t error = 0;
  uint32_t conv_time = 0;
  uint32_t user_command;
  int8_t readIC=0;
  char input = 0;
 Sacn_dev_fuction();
  switch (cmd)
  {
    case 0X01: // Write and Read Configuration Register д���üĴ���->�����ö��Ĵ�������ӡ��д��Ϣ
						for(uint8_t i=0;i<12;i++)
						{
					      	dccBits_a[i] = FALSE;
						}
						for (uint8_t current_ic = 0; current_ic<V82system.ICNum;current_ic++) 
						{
						    XL8812_set_cfgr(current_ic,bms_ic,REFON,ADCOPT,gpioBits_a,dccBits_a, dctoBits, UV, OV);
						} 
						 fuction_config();//д�����üĴ��� A
						 fuction_rxconfig();//�ض����üĴ��� A
      break;

    case 0X02: // Read Configuration Register
            fuction_rxconfig();//�ض����üĴ��� A
      break;

    case 0X03: // Start Cell ADC Measurement &   Read Cell Voltage Registers
		        fuction_cells();//	��о�ɼ����������ÿ����ѹ������ʾ 10 ����ֵ��(Ĭ�����òɼ� 12 ��)	 
   break;

    case 0X04:     // Start GPIO ADC Measurement &  Read AUX Voltage Registers
		        fuction_aux();//1��GPIO �����������Ӧ��ѹֵ������ʾ 10 ����ֵ��(Ĭ�����òɼ� 5 · GPIO)2��GPIO1-3 ������ѹת���������Ӧ���¶�ֵ��
		          AfeCadcProcess(   );
      break;

    case 0X05: // Start Status ADC Measurement �ڲ���������
		        fuction_stat();
      break;

    case 0X06:// Start Combined Cell Voltage and GPIO1, GPIO2 Conversion  ��о��ѹ�� GPIO1,GPIO2 ��������������ʾ 10 ����ֵ
          fuction_aux1();
      break;
      
    case 0X07: //Start Combined Cell Voltage and Sum of cells ��о��ѹ����ѹ���������������ֵ��
   		XL8812_demo_printf("Combined Cell Voltage conversion completed in:");
	      fuction_statsc();
      break;
      
    case 0X08: // Loop Measurements without data-log output  �����趨�� CELL ������ѭ���ɼ����������ÿ����ѹֵ
      XL8812_demo_printf("transmit 'E0' to quit");
       fuction_config();
      while (input != 0xE0) // ��ֹѭ������������˳�ѭ�� 0XE0 ָ��
      {
			     if( myUART_RecvByte(&input)==u_Ok);
              measurement_loop();
              Delay_ms(MEASUREMENT_LOOP_TIME);
      }
      print_menu();
      break;

     case 0X09: // Run the Mux Decoder Self Test  �������������������Լ첢����Լ���
		  fuction_diagn();
      break;

    case 0X0A:  // Run the ADC/Memory Self Test  //��У�鹦��   �����˲������洢����GPIO �Լ첢����Լ���
     fuction_MemorySelfTest();
     break;
      
    case 0X0B: // Run ADC Overlap self test // ADC ������⣬�����������ѹֵ
		 fuction_ADC_Overlapselftest();
     break;

    case 0X0C: // Run ADC Redundancy self test //��ѹ�����Ⲣ���������
	  	fuction_ADC_Redundancyselftest();
      break;

    case 0X0D: // Open Wire test for multiple cell and two consecutive cells detection���߼�Ⲣ���������Ϣ
          fuction_openwire_multi();
      break;

    case 0X0E: // Enable a discharge transistor �������Ⲣ������üĴ��� A ��Ϣ
			for(uint8_t i=0;i<12;i++)
			{
					 dccBits_a[i] = TRUE;
			}
      for (uint8_t current_ic = 0; current_ic<V82system.ICNum;current_ic++) 
      {
        XL8812_set_cfgr(current_ic,bms_ic,REFON,ADCOPT,gpioBits_a,dccBits_a, dctoBits, UV, OV);
      } 
       fuction_config();
		   fuction_rxconfig();
      break;
      
    case 0X0F: // Clear all discharge transistors �رվ��Ⲣ������üĴ��� A ��Ϣ
       XL8812_clear_discharge(V82system.ICNum,bms_ic);
				for(uint8_t i=0;i<12;i++)
			{
					 dccBits_a[i] = FALSE;
			}
       fuction_config();
		   fuction_rxconfig();
      break;

    case 0X10: // Clear all ADC measurement registers ������в����Ĵ���
		      fuction_ClrallADCmeasurementReg();
      break;
 
     default:
         XL8812_demo_printf("Incorrect Option");
      break;
  }
}
