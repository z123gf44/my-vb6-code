

//ADC�����ڲ�ͬģʽ�µ�ȫͨ������ת��ʱ��
#define XL8812_MEAS_ALL_FILTERED_TCYCLE      262
#define XL8812_MEAS_ALL_422HZ_TCYCLE             100
#define XL8812_MEAS_ALL_1KHZ_TCYCLE               60
#define XL8812_MEAS_ALL_2KHZ_TCYCLE               50
#define XL8812_MEAS_ALL_3KHZ_TCYCLE               30
#define XL8812_MEAS_ALL_NORMAL_TCYCLE        10
#define XL8812_MEAS_ALL_14KHZ_TCYCLE            9
#define XL8812_MEAS_ALL_FAST_TCYCLE               9

//ADC�����ڲ�ͬģʽ�µ�˫ͨ������ת��ʱ��
#define XL8812_MEAS_SINGLE_FILTERED_TCYCLE   	35
#define XL8812_MEAS_SINGLE_422HZ_TCYCLE   	    5
#define XL8812_MEAS_SINGLE_1KHZ_TCYCLE   	 	3
#define XL8812_MEAS_SINGLE_2KHZ_TCYCLE   	    2
#define XL8812_MEAS_SINGLE_3KHZ_TCYCLE   		1
#define XL8812_MEAS_SINGLE_NORMAL_TCYCLE     	1
#define XL8812_MEAS_SINGLE_14KHZ_TCYCLE   		1
#define XL8812_MEAS_SINGLE_FAST_TCYCLE       	1

	

void demo_init(void);
void XL8812demo(void);
